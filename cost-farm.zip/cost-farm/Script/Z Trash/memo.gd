

func 0():
	var item
	global
	inventory
	inventory_data
	inventory_tile
	shop
	shop _low
	eat
