

func 0():
	var item
	global
	inventory
	inventory_data
	shop