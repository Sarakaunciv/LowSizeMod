extends Node2D

@onready var ready_delay: Timer = $ready_delay
@onready var button: Control = $button

signal ready0()
var current_scene
func _ready() -> void:
	AsdaInventory.set_money.connect(update0)
	AsdaInventory.health_0.connect(die0)
	AsdaInventory.dept0.connect(spawn_dept_enemy)
	current_scene = get_node("..")
	
	ready_delay.timeout.connect(ready1)
	ready_delay.wait_time = 0.1
	ready_delay.one_shot = true
	ready_delay.start()
	
	inventory_data_load()
	update0()
	inventory_tile_build()
	for del0 in button.find_children("*"):
		if del0 is Button:
			del0.focus_mode = Control.FOCUS_NONE

func ready1():
	ready0.emit()

var dept_enemy = load("res://Script/Main/Enemy/dept_enemy.tscn")
var del0dept
func spawn_dept_enemy():
	AsasManager.get_knife0()
	AsasManager.get_shield0()
	if AsdaInventory.dept_low != 0:
		del0dept = dept_enemy.instantiate()
		del0dept.tier = 1
		add_dept_enemy()
	if AsdaInventory.dept_mid != 0:
		del0dept = dept_enemy.instantiate()
		del0dept.tier = 2
		add_dept_enemy()
	if AsdaInventory.dept_high != 0:
		del0dept = dept_enemy.instantiate()
		del0dept.tier = 3
		add_dept_enemy()
	if AsdaInventory.dept_max != 0:
		del0dept = dept_enemy.instantiate()
		del0dept.tier = 4
		add_dept_enemy()
func add_dept_enemy():
	call_deferred("add_child", del0dept)
	del0dept.position = Vector2(960, 540)

var inventory_data = load("res://Script/Main/inventory_data.tscn")
func inventory_data_load():
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		var data = ResourceLoader.load("res://Scene/SaveScene/inv.tres") as zzzz_resource
		for del0 in data.inv:
			var del0inv = del0.instantiate()
			call_deferred("add_child", del0inv)
	else:
		var del0inv = inventory_data.instantiate()
		call_deferred("add_child", del0inv)

@onready var inventory_tile_0: Node2D = $inventory_tile_0
var inventory_tile = load("res://Script/UI/inventory_tile.tscn")
func inventory_tile_build():
	for del0x in range(20):
		for del0y in range(3):
			var del0tile = inventory_tile.instantiate()
			del0tile.item_id = 1 + del0x + (del0y * 20)
			inventory_tile_0.call_deferred("add_child", del0tile)
			del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)

@onready var inv_page_label: Label = $button/inv/ColorRect/inv_page_label
signal set_inv_page()
var inv_page: int = 1
func _on_inv_next_pressed() -> void:
	inv_page += 1
	update1()
func _on_inv_prev_pressed() -> void:
	inv_page -= 1
	update1()
func update1():
	if inv_page > 2:
		inv_page = 2
	elif inv_page < 1:
		inv_page = 1
	inv_page_label.text = str(inv_page)
	set_inv_page.emit()

var is_dept: bool = false
func _on_dept_pressed() -> void:
	if is_dept == false:
		is_dept = true
	else:
		is_dept = false
	update0()

@onready var money_low_label: Label = $money/money_low/Label
@onready var money_mid_label: Label = $money/money_mid/Label
@onready var money_high_label: Label = $money/money_high/Label
@onready var money_max_label: Label = $money/money_max/Label
@onready var dept_label: Label = $button/dept/Label
func update0():
	if is_dept == false:
		money_low_label.text = str(AsdaInventory.money_low)
		money_mid_label.text = str(AsdaInventory.money_mid)
		money_high_label.text = str(AsdaInventory.money_high)
		money_max_label.text = str(AsdaInventory.money_max)
		dept_label.text = str("Dept off")
	else:
		AsdaInventory.get_dept()
		money_low_label.text = str(AsdaInventory.dept_low)
		money_mid_label.text = str(AsdaInventory.dept_mid)
		money_high_label.text = str(AsdaInventory.dept_high)
		money_max_label.text = str(AsdaInventory.dept_max)
		dept_label.text = str("Dept on")

func die0():
	get_tree().change_scene_to_file("res://Scene/die_menu.tscn")

func _on_location_pressed() -> void:
	if AsasManager.location_prevent == 0:
		get_tree().change_scene_to_file("res://Scene/location_menu.tscn")

func _on_tree_exiting() -> void:
	var data = zzzz_resource.new()
	match current_scene.scene_id:
		AaaaGlobal.id_scene_farm:
			var farm_tile_0 = get_tree().get_nodes_in_group("farm_tile")
			for del0 in farm_tile_0:
				var farm_tile_pack = PackedScene.new()
				farm_tile_pack.pack(del0)
				data.farm_tile_0.append(farm_tile_pack)
			ResourceSaver.save(data, "res://Scene/SaveScene/farm.tres")
		AaaaGlobal.id_scene_river:
			var river_tile_0 = get_tree().get_nodes_in_group("river_tile")
			for del0 in river_tile_0:
				var river_tile_pack = PackedScene.new()
				river_tile_pack.pack(del0)
				data.river_tile_0.append(river_tile_pack)
			ResourceSaver.save(data, "res://Scene/SaveScene/river.tres")
