extends Node2D

var item_id: int = 0

func _ready() -> void:
	edge_hover.z_index = 8
	label.z_index = 8
	update0()
	update1(0)

@onready var content: Sprite2D = $size/content
@onready var content2: Sprite2D = $size/content2
func update0():
	match item_id:
		AaaaGlobal.id_karat:
			content.region_rect.position = AaaaGlobal.atlas_karat_inv
			AsdaInventory.set_karat.connect(update1)
			content2.visible = false
		AaaaGlobal.id_karat_seed:
			content.region_rect.position = AaaaGlobal.atlas_karat_seed_inv
			AsdaInventory.set_karat_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0
		AaaaGlobal.id_tamaso:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_inv
			AsdaInventory.set_tamaso.connect(update1)
			content2.visible = false
		AaaaGlobal.id_tamaso_seed:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_seed_inv
			AsdaInventory.set_tamaso_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0
		AaaaGlobal.id_fert_speed_low:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_low.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_low_inv
		AaaaGlobal.id_fert_speed_mid:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_mid.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_mid_inv
		AaaaGlobal.id_fert_speed_high:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_high.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_high_inv
		AaaaGlobal.id_fert_speed_max:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_max.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_max_inv
		AaaaGlobal.id_fert_size_low:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_low.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_low_inv
		AaaaGlobal.id_fert_size_mid:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_mid.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_mid_inv
		AaaaGlobal.id_fert_size_high:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_high.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_high_inv
		AaaaGlobal.id_fert_size_max:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_max.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_max_inv

func update1(del0):
	match item_id:
		AaaaGlobal.id_karat:
			update2(AsdaInventory.karat)
		AaaaGlobal.id_karat_seed:
			update2(AsdaInventory.karat_seed)
		AaaaGlobal.id_tamaso:
			update2(AsdaInventory.tamaso)
		AaaaGlobal.id_tamaso_seed:
			update2(AsdaInventory.tamaso_seed)
		AaaaGlobal.id_fert_speed_low:
			update2(AsdaInventory.fert_speed_low)
		AaaaGlobal.id_fert_speed_mid:
			update2(AsdaInventory.fert_speed_mid)
		AaaaGlobal.id_fert_speed_high:
			update2(AsdaInventory.fert_speed_high)
		AaaaGlobal.id_fert_speed_max:
			update2(AsdaInventory.fert_speed_max)
		AaaaGlobal.id_fert_size_low:
			update2(AsdaInventory.fert_size_low)
		AaaaGlobal.id_fert_size_mid:
			update2(AsdaInventory.fert_size_mid)
		AaaaGlobal.id_fert_size_high:
			update2(AsdaInventory.fert_size_high)
		AaaaGlobal.id_fert_size_max:
			update2(AsdaInventory.fert_size_max)

@onready var label: Label = $ColorRect/Label
var del0count: int = 0
func update2(del0):
	if del0 >= 1000 and del0count != 4:
		del0 = int(del0) / 1000.0
		del0count += 1
		update2(del0)
		return
	else:
		label.text = str(del0)
		match del0count:
			1:
				label.text += str("K")
			2:
				label.text += str("M")
			3:
				label.text += str("B")
			4:
				label.text += str("T")
		del0count = 0

func _on_button_pressed() -> void:
	AsasManager.equal_hold_item_id(item_id)

@onready var edge_hover: Sprite2D = $size/edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
