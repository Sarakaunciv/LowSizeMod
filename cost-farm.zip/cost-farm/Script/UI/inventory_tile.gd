extends Node2D

var item_id: int = 0

func _ready() -> void:
	update0()
	update1(0)

@onready var content: Sprite2D = $size/content
func update0():
	match item_id:
		AaaaGlobal.id_karat:
			content.region_rect.position = AaaaGlobal.atlas_karat_inv
			AsdaInventory.set_karat.connect(update1)
		AaaaGlobal.id_karat_seed:
			content.region_rect.position = AaaaGlobal.atlas_karat_seed_inv
			AsdaInventory.set_karat_seed.connect(update1)
		AaaaGlobal.id_tamaso:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_inv
			AsdaInventory.set_tamaso.connect(update1)
		AaaaGlobal.id_tamaso_seed:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_seed_inv
			AsdaInventory.set_tamaso_seed.connect(update1)

@onready var label: Label = $ColorRect/Label
func update1(del0):
	match item_id:
		AaaaGlobal.id_karat:
			label.text = str(float(AsdaInventory.karat) / 1000)
		AaaaGlobal.id_karat_seed:
			label.text = str(AsdaInventory.karat_seed)
		AaaaGlobal.id_tamaso:
			label.text = str(float(AsdaInventory.tamaso) / 1000)
		AaaaGlobal.id_tamaso_seed:
			label.text = str(AsdaInventory.tamaso_seed)

func _on_button_pressed() -> void:
	match item_id:
		AaaaGlobal.id_karat:
			AsasManager.hold_item_id = item_id
		AaaaGlobal.id_karat_seed:
			AsasManager.hold_item_id = item_id
		AaaaGlobal.id_tamaso:
			AsasManager.hold_item_id = item_id
		AaaaGlobal.id_tamaso_seed:
			AsasManager.hold_item_id = item_id
