extends Node2D

@onready var button: Button = $Button
var item_id: int = 0
var page: int = 1
var user_interface
func _ready() -> void:
	user_interface = get_node("../..")
	user_interface.set_inv_page.connect(update0)
	edge_hover.z_index = 8
	label.z_index = 8
	update0()
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

@onready var content: Sprite2D = $size/content
@onready var content2: Sprite2D = $size/content2
func update0():
	item_id += (user_interface.inv_page - page) * AaaaGlobal.inventory_page
	page += user_interface.inv_page - page
	content.region_rect.position = AaaaGlobal.atlas_dirt_select
	content2.visible = false
	update2(0)
	match item_id:
# plant ################################################################
		AaaaGlobal.id_karat:
			content.region_rect.position = AaaaGlobal.atlas_karat_inv
			AsdaInventory.set_karat.connect(update1)
			content2.visible = false
		AaaaGlobal.id_karat_seed:
			content.region_rect.position = AaaaGlobal.atlas_karat_seed_inv
			AsdaInventory.set_karat_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0
		AaaaGlobal.id_tamaso:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_inv
			AsdaInventory.set_tamaso.connect(update1)
			content2.visible = false
		AaaaGlobal.id_tamaso_seed:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_seed_inv
			AsdaInventory.set_tamaso_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0
# fert ################################################################
		AaaaGlobal.id_fert_speed_low:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_low.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_low_inv
		AaaaGlobal.id_fert_speed_mid:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_mid.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_mid_inv
		AaaaGlobal.id_fert_speed_high:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_high.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_high_inv
		AaaaGlobal.id_fert_speed_max:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_max.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_max_inv
		AaaaGlobal.id_fert_size_low:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_low.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_low_inv
		AaaaGlobal.id_fert_size_mid:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_mid.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_mid_inv
		AaaaGlobal.id_fert_size_high:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_high.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_high_inv
		AaaaGlobal.id_fert_size_max:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_max.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_fert_max_inv
# ect ################################################################
		AaaaGlobal.id_shovel:
			content.region_rect.position = AaaaGlobal.atlas_shovel_inv
			AsdaInventory.set_shovel.connect(update1)
			content2.visible = false
		AaaaGlobal.id_axe:
			content.region_rect.position = AaaaGlobal.atlas_axe_inv
			AsdaInventory.set_axe.connect(update1)
			content2.visible = false
		AaaaGlobal.id_wood:
			content.region_rect.position = AaaaGlobal.atlas_wood_inv
			AsdaInventory.set_wood.connect(update1)
			content2.visible = false
# mineral ################################################################
		AaaaGlobal.id_stone:
			content.region_rect.position = AaaaGlobal.atlas_stone_inv
			AsdaInventory.set_stone.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese:
			content.region_rect.position = AaaaGlobal.atlas_cese_inv
			AsdaInventory.set_cese.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese_pick:
			content.region_rect.position = AaaaGlobal.atlas_cese_pick_inv
			AsdaInventory.set_cese_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese_knife:
			content.region_rect.position = AaaaGlobal.atlas_cese_knife_inv
			AsdaInventory.set_cese_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese_shield:
			content.region_rect.position = AaaaGlobal.atlas_cese_shield_inv
			AsdaInventory.set_cese_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_inv
			AsdaInventory.set_lowaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_pick_inv
			AsdaInventory.set_lowaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_knife_inv
			AsdaInventory.set_lowaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_shield_inv
			AsdaInventory.set_lowaral_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena:
			content.region_rect.position = AaaaGlobal.atlas_iena_inv
			AsdaInventory.set_iena.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena_pick:
			content.region_rect.position = AaaaGlobal.atlas_iena_pick_inv
			AsdaInventory.set_iena_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena_knife:
			content.region_rect.position = AaaaGlobal.atlas_iena_knife_inv
			AsdaInventory.set_iena_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena_shield:
			content.region_rect.position = AaaaGlobal.atlas_iena_shield_inv
			AsdaInventory.set_iena_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral:
			content.region_rect.position = AaaaGlobal.atlas_midaral_inv
			AsdaInventory.set_midaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_midaral_pick_inv
			AsdaInventory.set_midaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_midaral_knife_inv
			AsdaInventory.set_midaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_midaral_shield_inv
			AsdaInventory.set_midaral_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize:
			content.region_rect.position = AaaaGlobal.atlas_graize_inv
			AsdaInventory.set_graize.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize_pick:
			content.region_rect.position = AaaaGlobal.atlas_graize_pick_inv
			AsdaInventory.set_graize_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize_knife:
			content.region_rect.position = AaaaGlobal.atlas_graize_knife_inv
			AsdaInventory.set_graize_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize_shield:
			content.region_rect.position = AaaaGlobal.atlas_graize_shield_inv
			AsdaInventory.set_graize_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral:
			content.region_rect.position = AaaaGlobal.atlas_higaral_inv
			AsdaInventory.set_higaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_higaral_pick_inv
			AsdaInventory.set_higaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_higaral_knife_inv
			AsdaInventory.set_higaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_higaral_shield_inv
			AsdaInventory.set_higaral_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto:
			content.region_rect.position = AaaaGlobal.atlas_adanto_inv
			AsdaInventory.set_adanto.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto_pick:
			content.region_rect.position = AaaaGlobal.atlas_adanto_pick_inv
			AsdaInventory.set_adanto_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto_knife:
			content.region_rect.position = AaaaGlobal.atlas_adanto_knife_inv
			AsdaInventory.set_adanto_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto_shield:
			content.region_rect.position = AaaaGlobal.atlas_adanto_shield_inv
			AsdaInventory.set_adanto_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_inv
			AsdaInventory.set_maxaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_pick_inv
			AsdaInventory.set_maxaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_knife_inv
			AsdaInventory.set_maxaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_shield_inv
			AsdaInventory.set_maxaral_shield.connect(update1)
			content2.visible = false
	update1()

func update1():
	match item_id:
# plant ################################################################
		AaaaGlobal.id_karat:
			update2(AsdaInventory.karat)
		AaaaGlobal.id_karat_seed:
			update2(AsdaInventory.karat_seed)
		AaaaGlobal.id_tamaso:
			update2(AsdaInventory.tamaso)
		AaaaGlobal.id_tamaso_seed:
			update2(AsdaInventory.tamaso_seed)
# fert ################################################################
		AaaaGlobal.id_fert_speed_low:
			update2(AsdaInventory.fert_speed_low)
		AaaaGlobal.id_fert_speed_mid:
			update2(AsdaInventory.fert_speed_mid)
		AaaaGlobal.id_fert_speed_high:
			update2(AsdaInventory.fert_speed_high)
		AaaaGlobal.id_fert_speed_max:
			update2(AsdaInventory.fert_speed_max)
		AaaaGlobal.id_fert_size_low:
			update2(AsdaInventory.fert_size_low)
		AaaaGlobal.id_fert_size_mid:
			update2(AsdaInventory.fert_size_mid)
		AaaaGlobal.id_fert_size_high:
			update2(AsdaInventory.fert_size_high)
		AaaaGlobal.id_fert_size_max:
			update2(AsdaInventory.fert_size_max)
# ect ################################################################
		AaaaGlobal.id_shovel:
			update2(AsdaInventory.shovel)
		AaaaGlobal.id_axe:
			update2(AsdaInventory.axe)
		AaaaGlobal.id_wood:
			update2(AsdaInventory.wood)
# mineral ################################################################
		AaaaGlobal.id_stone:
			update2(AsdaInventory.stone)
		AaaaGlobal.id_cese:
			update2(AsdaInventory.cese)
		AaaaGlobal.id_cese_pick:
			update2(AsdaInventory.cese_pick)
		AaaaGlobal.id_cese_knife:
			update2(AsdaInventory.cese_knife)
		AaaaGlobal.id_cese_shield:
			update2(AsdaInventory.cese_shield)
		AaaaGlobal.id_lowaral:
			update2(AsdaInventory.lowaral)
		AaaaGlobal.id_lowaral_pick:
			update2(AsdaInventory.lowaral_pick)
		AaaaGlobal.id_lowaral_knife:
			update2(AsdaInventory.lowaral_knife)
		AaaaGlobal.id_lowaral_shield:
			update2(AsdaInventory.lowaral_shield)
		AaaaGlobal.id_iena:
			update2(AsdaInventory.iena)
		AaaaGlobal.id_iena_pick:
			update2(AsdaInventory.iena_pick)
		AaaaGlobal.id_iena_knife:
			update2(AsdaInventory.iena_knife)
		AaaaGlobal.id_iena_shield:
			update2(AsdaInventory.iena_shield)
		AaaaGlobal.id_midaral:
			update2(AsdaInventory.midaral)
		AaaaGlobal.id_midaral_pick:
			update2(AsdaInventory.midaral_pick)
		AaaaGlobal.id_midaral_knife:
			update2(AsdaInventory.midaral_knife)
		AaaaGlobal.id_midaral_shield:
			update2(AsdaInventory.midaral_shield)
		AaaaGlobal.id_graize:
			update2(AsdaInventory.graize)
		AaaaGlobal.id_graize_pick:
			update2(AsdaInventory.graize_pick)
		AaaaGlobal.id_graize_knife:
			update2(AsdaInventory.graize_knife)
		AaaaGlobal.id_graize_shield:
			update2(AsdaInventory.graize_shield)
		AaaaGlobal.id_higaral:
			update2(AsdaInventory.higaral)
		AaaaGlobal.id_higaral_pick:
			update2(AsdaInventory.higaral_pick)
		AaaaGlobal.id_higaral_knife:
			update2(AsdaInventory.higaral_knife)
		AaaaGlobal.id_higaral_shield:
			update2(AsdaInventory.higaral_shield)
		AaaaGlobal.id_adanto:
			update2(AsdaInventory.adanto)
		AaaaGlobal.id_adanto_pick:
			update2(AsdaInventory.adanto_pick)
		AaaaGlobal.id_adanto_knife:
			update2(AsdaInventory.adanto_knife)
		AaaaGlobal.id_adanto_shield:
			update2(AsdaInventory.adanto_shield)
		AaaaGlobal.id_maxaral:
			update2(AsdaInventory.maxaral)
		AaaaGlobal.id_maxaral_pick:
			update2(AsdaInventory.maxaral_pick)
		AaaaGlobal.id_maxaral_knife:
			update2(AsdaInventory.maxaral_knife)
		AaaaGlobal.id_maxaral_shield:
			update2(AsdaInventory.maxaral_shield)

@onready var label: Label = $ColorRect/Label
var del0count: int = 0
func update2(del0):
	if del0 >= 1000 and del0count != 4:
		del0 = int(del0) / 1000.0
		del0count += 1
		update2(del0)
		return
	else:
		label.text = str(del0)
		match del0count:
			1:
				label.text += str("K")
			2:
				label.text += str("M")
			3:
				label.text += str("B")
			4:
				label.text += str("T")
		del0count = 0

func _on_button_pressed() -> void:
	AsasManager.equal_hold_item_id(item_id)

@onready var edge_hover: Sprite2D = $size/edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
