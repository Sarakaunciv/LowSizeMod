extends Button

func _on_pressed() -> void:
	match AsasManager.hold_item_id:
		AaaaGlobal.id_karat:
			if AsdaInventory.karat > 0:
				AsdaInventory.add_karat(-1)
				AsdaInventory.add_food(300)
		AaaaGlobal.id_karat_seed:
			if AsdaInventory.karat_seed > 0:
				AsdaInventory.add_karat_seed(-1)
				AsdaInventory.add_food(1)
		AaaaGlobal.id_tamaso:
			if AsdaInventory.tamaso > 0:
				AsdaInventory.add_tamaso(-1)
				AsdaInventory.add_food(330)
		AaaaGlobal.id_tamaso_seed:
			if AsdaInventory.tamaso_seed > 0:
				AsdaInventory.add_tamaso_seed(-1)
				AsdaInventory.add_food(3)
		AaaaGlobal.id_bait:
			if AsdaInventory.bait > 0:
				AsdaInventory.add_bait(-1)
				AsdaInventory.add_food(300)
		AaaaGlobal.id_fish:
			if AsdaInventory.fish > 0:
				AsdaInventory.add_fish(-1)
				AsdaInventory.add_food(1440)
		AaaaGlobal.id_crab:
			if AsdaInventory.crab > 0:
				AsdaInventory.add_crab(-1)
				AsdaInventory.add_food(680)
