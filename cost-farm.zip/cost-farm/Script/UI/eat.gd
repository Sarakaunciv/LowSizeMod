extends Button

func _on_pressed() -> void:
	match AsasManager.hold_item_id:
		AaaaGlobal.id_karat:
			if AsdaInventory.karat > 0:
				AsdaInventory.add_karat(-1)
				AsdaInventory.add_food(280)
		AaaaGlobal.id_karat_seed:
			if AsdaInventory.karat_seed > 0:
				AsdaInventory.add_karat_seed(-1)
				AsdaInventory.add_food(1)
		AaaaGlobal.id_tamaso:
			if AsdaInventory.tamaso > 0:
				AsdaInventory.add_tamaso(-1)
				AsdaInventory.add_food(330)
		AaaaGlobal.id_tamaso_seed:
			if AsdaInventory.tamaso_seed > 0:
				AsdaInventory.add_tamaso_seed(-1)
				AsdaInventory.add_food(5)
		AaaaGlobal.id_patrak:
			if AsdaInventory.patrak > 0:
				AsdaInventory.add_patrak(-1)
				AsdaInventory.add_food(360)
		AaaaGlobal.id_patrak_seed:
			if AsdaInventory.patrak_seed > 0:
				AsdaInventory.add_patrak_seed(-1)
				AsdaInventory.add_food(2)
		AaaaGlobal.id_apos:
			if AsdaInventory.apos > 0:
				AsdaInventory.add_apos(-1)
				AsdaInventory.add_food(1440)
		AaaaGlobal.id_apos_seed:
			if AsdaInventory.apos_seed > 0:
				AsdaInventory.add_apos_seed(-1)
				AsdaInventory.add_food(300)
		AaaaGlobal.id_whaat:
			if AsdaInventory.whaat > 0:
				AsdaInventory.add_whaat(-1)
				AsdaInventory.add_food(600)
				AsdaInventory.add_health(50000)
		AaaaGlobal.id_whaat_seed:
			if AsdaInventory.whaat_seed > 0:
				AsdaInventory.add_whaat_seed(-1)
				AsdaInventory.add_food(400)
				AsdaInventory.add_health(1000)
		AaaaGlobal.id_garn:
			if AsdaInventory.garn > 0:
				AsdaInventory.add_garn(-1)
				AsdaInventory.add_food(1800)
				AsdaInventory.add_health(80000)
		AaaaGlobal.id_garn_seed:
			if AsdaInventory.garn_seed > 0:
				AsdaInventory.add_garn_seed(-1)
				AsdaInventory.add_food(600)
				AsdaInventory.add_health(5000)
		AaaaGlobal.id_yume_karst_faw:
			if AsdaInventory.yume_karst_faw > 0:
				AsdaInventory.add_yume_karst_faw(-1)
				AsdaInventory.add_food(6000)
				AsdaInventory.add_health(1000000)
		AaaaGlobal.id_yume_karst_faw_seed:
			if AsdaInventory.yume_karst_faw_seed > 0:
				AsdaInventory.add_yume_karst_faw_seed(-1)
				AsdaInventory.add_food(6000)
				AsdaInventory.add_health(100000)
		AaaaGlobal.id_bait:
			if AsdaInventory.bait > 0:
				AsdaInventory.add_bait(-1)
				AsdaInventory.add_food(300)
		AaaaGlobal.id_fish:
			if AsdaInventory.fish > 0:
				AsdaInventory.add_fish(-1)
				AsdaInventory.add_food(1440)
		AaaaGlobal.id_crab:
			if AsdaInventory.crab > 0:
				AsdaInventory.add_crab(-1)
				AsdaInventory.add_food(680)
