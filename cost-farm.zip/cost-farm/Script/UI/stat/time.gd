extends ColorRect

@onready var time_day: Label = $time_day
@onready var time_hour: Label = $time_hour
var user_interface
func _ready() -> void:
	user_interface = get_node("../..")
	user_interface.ready0.connect(ready0)
	AsdaInventory.set_time_min.connect(update0)
	AsdaInventory.set_time_hour.connect(update0)
	AsdaInventory.set_time_day.connect(update1)
func ready0():
	update0()
	update1()

func update0():
	time_hour.text = str(AsdaInventory.time_hour, ":")
	if AsdaInventory.time_min < 10:
		time_hour.text += str(0)
	time_hour.text += str(AsdaInventory.time_min)

func update1():
	time_day.text = str(AsdaInventory.time_day / AaaaGlobal.time_day_in_year, "/ ", (AsdaInventory.time_day % AaaaGlobal.time_day_in_year) / AaaaGlobal.time_day_in_month, "/ ", (AsdaInventory.time_day % AaaaGlobal.time_day_in_year) % AaaaGlobal.time_day_in_month)
