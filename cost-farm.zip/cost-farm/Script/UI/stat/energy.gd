extends TextureProgressBar

var user_interface
func _ready() -> void:
	user_interface = get_node("../../..")
	user_interface.ready0.connect(ready0)
	AsdaInventory.set_energy.connect(update0)
	max_value = AsdaInventory.energy_max
	update0()

func ready0():
	update0()

func update0():
	value = AsdaInventory.energy
