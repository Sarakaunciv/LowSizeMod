extends Node2D

func _ready() -> void:
	AsasManager.set_hold_item_id.connect(update0)
	update0()

func _process(delta: float) -> void:
	self.global_position = get_global_mouse_position()

@onready var content: Sprite2D = $size/content
@onready var content2: Sprite2D = $size/content2
func update0():
	content.region_rect.position = AaaaGlobal.atlas_dirt_select
	content2.visible = false
	match AsasManager.hold_item_id:
# plant ################################################################
		AaaaGlobal.id_karat:
			content.region_rect.position = AaaaGlobal.atlas_karat_inv
			AsdaInventory.set_karat.connect(update1)
			content2.visible = false
		AaaaGlobal.id_karat_seed:
			content.region_rect.position = AaaaGlobal.atlas_karat_seed_inv
			AsdaInventory.set_karat_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
		AaaaGlobal.id_tamaso:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_inv
			AsdaInventory.set_tamaso.connect(update1)
			content2.visible = false
		AaaaGlobal.id_tamaso_seed:
			content.region_rect.position = AaaaGlobal.atlas_tamaso_seed_inv
			AsdaInventory.set_tamaso_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
		AaaaGlobal.id_patrak:
			content.region_rect.position = AaaaGlobal.atlas_patrak_inv
			AsdaInventory.set_patrak.connect(update1)
			content2.visible = false
		AaaaGlobal.id_patrak_seed:
			content.region_rect.position = AaaaGlobal.atlas_patrak_seed_inv
			AsdaInventory.set_patrak_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
		AaaaGlobal.id_apos:
			content.region_rect.position = AaaaGlobal.atlas_apos_inv
			AsdaInventory.set_apos.connect(update1)
			content2.visible = false
		AaaaGlobal.id_apos_seed:
			content.region_rect.position = AaaaGlobal.atlas_apos_seed_inv
			AsdaInventory.set_apos_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
		AaaaGlobal.id_whaat:
			content.region_rect.position = AaaaGlobal.atlas_whaat_inv
			AsdaInventory.set_whaat.connect(update1)
			content2.visible = false
		AaaaGlobal.id_whaat_seed:
			content.region_rect.position = AaaaGlobal.atlas_whaat_seed_inv
			AsdaInventory.set_whaat_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
		AaaaGlobal.id_garn:
			content.region_rect.position = AaaaGlobal.atlas_garn_inv
			AsdaInventory.set_garn.connect(update1)
			content2.visible = false
		AaaaGlobal.id_garn_seed:
			content.region_rect.position = AaaaGlobal.atlas_garn_seed_inv
			AsdaInventory.set_garn_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
		AaaaGlobal.id_graize_frizet:
			content.region_rect.position = AaaaGlobal.atlas_graize_frizet_inv
			AsdaInventory.set_graize_frizet.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize_frizet_seed:
			content.region_rect.position = AaaaGlobal.atlas_graize_frizet_seed_inv
			AsdaInventory.set_graize_frizet_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
		AaaaGlobal.id_yume_karst_faw:
			content.region_rect.position = AaaaGlobal.atlas_yume_karst_faw_inv
			AsdaInventory.set_yume_karst_faw.connect(update1)
			content2.visible = false
		AaaaGlobal.id_yume_karst_faw_seed:
			content.region_rect.position = AaaaGlobal.atlas_yume_karst_faw_seed_inv
			AsdaInventory.set_yume_karst_faw_seed.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_0_inv
# fert ################################################################
		AaaaGlobal.id_fert_speed_low:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_low.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_low_inv
		AaaaGlobal.id_fert_speed_mid:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_mid.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_mid_inv
		AaaaGlobal.id_fert_speed_high:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_high.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_high_inv
		AaaaGlobal.id_fert_speed_max:
			content.region_rect.position = AaaaGlobal.atlas_fert_speed_inv
			AsdaInventory.set_fert_speed_max.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_max_inv
		AaaaGlobal.id_fert_size_low:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_low.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_low_inv
		AaaaGlobal.id_fert_size_mid:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_mid.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_mid_inv
		AaaaGlobal.id_fert_size_high:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_high.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_high_inv
		AaaaGlobal.id_fert_size_max:
			content.region_rect.position = AaaaGlobal.atlas_fert_size_inv
			AsdaInventory.set_fert_size_max.connect(update1)
			content2.visible = true
			content2.region_rect.position = AaaaGlobal.atlas_bag_max_inv
# ect ################################################################
		AaaaGlobal.id_shovel:
			content.region_rect.position = AaaaGlobal.atlas_shovel_inv
			AsdaInventory.set_shovel.connect(update1)
			content2.visible = false
		AaaaGlobal.id_axe:
			content.region_rect.position = AaaaGlobal.atlas_axe_inv
			AsdaInventory.set_axe.connect(update1)
			content2.visible = false
		AaaaGlobal.id_wood:
			content.region_rect.position = AaaaGlobal.atlas_wood_inv
			AsdaInventory.set_wood.connect(update1)
			content2.visible = false
# fish ################################################################
		AaaaGlobal.id_bait:
			content.region_rect.position = AaaaGlobal.atlas_bait_inv
			AsdaInventory.set_bait.connect(update1)
			content2.visible = false
		AaaaGlobal.id_fish_rod:
			content.region_rect.position = AaaaGlobal.atlas_fish_rod_inv
			AsdaInventory.set_fish_rod.connect(update1)
			content2.visible = false
		AaaaGlobal.id_crab_pot:
			content.region_rect.position = AaaaGlobal.atlas_crab_pot_inv
			AsdaInventory.set_crab_pot.connect(update1)
			content2.visible = false
		AaaaGlobal.id_fish:
			content.region_rect.position = AaaaGlobal.atlas_fish_inv
			AsdaInventory.set_fish.connect(update1)
			content2.visible = false
		AaaaGlobal.id_crab:
			content.region_rect.position = AaaaGlobal.atlas_crab_inv
			AsdaInventory.set_crab.connect(update1)
			content2.visible = false
# mineral ################################################################
		AaaaGlobal.id_stone:
			content.region_rect.position = AaaaGlobal.atlas_stone_inv
			AsdaInventory.set_stone.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese:
			content.region_rect.position = AaaaGlobal.atlas_cese_inv
			AsdaInventory.set_cese.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese_pick:
			content.region_rect.position = AaaaGlobal.atlas_cese_pick_inv
			AsdaInventory.set_cese_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese_knife:
			content.region_rect.position = AaaaGlobal.atlas_cese_knife_inv
			AsdaInventory.set_cese_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_cese_shield:
			content.region_rect.position = AaaaGlobal.atlas_cese_shield_inv
			AsdaInventory.set_cese_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_inv
			AsdaInventory.set_lowaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_pick_inv
			AsdaInventory.set_lowaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_knife_inv
			AsdaInventory.set_lowaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_lowaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_lowaral_shield_inv
			AsdaInventory.set_lowaral_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena:
			content.region_rect.position = AaaaGlobal.atlas_iena_inv
			AsdaInventory.set_iena.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena_pick:
			content.region_rect.position = AaaaGlobal.atlas_iena_pick_inv
			AsdaInventory.set_iena_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena_knife:
			content.region_rect.position = AaaaGlobal.atlas_iena_knife_inv
			AsdaInventory.set_iena_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_iena_shield:
			content.region_rect.position = AaaaGlobal.atlas_iena_shield_inv
			AsdaInventory.set_iena_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral:
			content.region_rect.position = AaaaGlobal.atlas_midaral_inv
			AsdaInventory.set_midaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_midaral_pick_inv
			AsdaInventory.set_midaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_midaral_knife_inv
			AsdaInventory.set_midaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_midaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_midaral_shield_inv
			AsdaInventory.set_midaral_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize:
			content.region_rect.position = AaaaGlobal.atlas_graize_inv
			AsdaInventory.set_graize.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize_pick:
			content.region_rect.position = AaaaGlobal.atlas_graize_pick_inv
			AsdaInventory.set_graize_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize_knife:
			content.region_rect.position = AaaaGlobal.atlas_graize_knife_inv
			AsdaInventory.set_graize_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_graize_shield:
			content.region_rect.position = AaaaGlobal.atlas_graize_shield_inv
			AsdaInventory.set_graize_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral:
			content.region_rect.position = AaaaGlobal.atlas_higaral_inv
			AsdaInventory.set_higaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_higaral_pick_inv
			AsdaInventory.set_higaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_higaral_knife_inv
			AsdaInventory.set_higaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_higaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_higaral_shield_inv
			AsdaInventory.set_higaral_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto:
			content.region_rect.position = AaaaGlobal.atlas_adanto_inv
			AsdaInventory.set_adanto.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto_pick:
			content.region_rect.position = AaaaGlobal.atlas_adanto_pick_inv
			AsdaInventory.set_adanto_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto_knife:
			content.region_rect.position = AaaaGlobal.atlas_adanto_knife_inv
			AsdaInventory.set_adanto_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_adanto_shield:
			content.region_rect.position = AaaaGlobal.atlas_adanto_shield_inv
			AsdaInventory.set_adanto_shield.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_inv
			AsdaInventory.set_maxaral.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral_pick:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_pick_inv
			AsdaInventory.set_maxaral_pick.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral_knife:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_knife_inv
			AsdaInventory.set_maxaral_knife.connect(update1)
			content2.visible = false
		AaaaGlobal.id_maxaral_shield:
			content.region_rect.position = AaaaGlobal.atlas_maxaral_shield_inv
			AsdaInventory.set_maxaral_shield.connect(update1)
			content2.visible = false
# permit ################################################################
		AaaaGlobal.id_permit_farm:
			content.region_rect.position = AaaaGlobal.atlas_permit_farm_inv
			AsdaInventory.set_permit_farm.connect(update1)
			content2.visible = false
		AaaaGlobal.id_permit_mine:
			content.region_rect.position = AaaaGlobal.atlas_permit_mine_inv
			AsdaInventory.set_permit_mine.connect(update1)
			content2.visible = false
		AaaaGlobal.id_permit_wood:
			content.region_rect.position = AaaaGlobal.atlas_permit_wood_inv
			AsdaInventory.set_permit_wood.connect(update1)
			content2.visible = false
		AaaaGlobal.id_permit_fish:
			content.region_rect.position = AaaaGlobal.atlas_permit_fish_inv
			AsdaInventory.set_permit_fish.connect(update1)
			content2.visible = false
		AaaaGlobal.id_permit_crab:
			content.region_rect.position = AaaaGlobal.atlas_permit_crab_inv
			AsdaInventory.set_permit_crab.connect(update1)
			content2.visible = false
