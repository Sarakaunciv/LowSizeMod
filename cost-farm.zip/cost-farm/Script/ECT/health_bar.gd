extends TextureProgressBar

var parent
func _ready() -> void:
	parent = get_node("..")
	max_value = parent.hp_max
	update_health_bar()

func update_health_bar():
	value = parent.hp_left
	if parent.hp_left == parent.hp_max:
		self.visible = false
	else:
		self.visible = true
