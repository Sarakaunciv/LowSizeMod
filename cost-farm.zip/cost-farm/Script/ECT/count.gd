extends Control

func _ready() -> void:
	update0()

@onready var label: Label = $count/Label
signal del_update
var del_count: int = 1
var del_power: int = 0
func update0():
	label.text = str(del_count * (1000 ** del_power))
	del_update.emit()
func update1():
	if del_count > 999:
		del_count -= 999
	elif del_count < 1:
		del_count += 999
	update0()
func _on_aa_pressed() -> void:
	del_count += 1
	update1()
func _on_ba_pressed() -> void:
	del_count += 10
	update1()
func _on_ca_pressed() -> void:
	del_count += 100
	update1()

func _on_as_pressed() -> void:
	del_count -= 1
	update1()
func _on_bs_pressed() -> void:
	del_count -= 10
	update1()
func _on_cs_pressed() -> void:
	del_count -= 100
	update1()

func update2():
	if del_power > 3:
		del_power = 3
	elif del_power < 0:
		del_power = 0
	update0()
func _on_ka_pressed() -> void:
	del_power += 1
	update2()
func _on_ks_pressed() -> void:
	del_power -= 1
	update2()

func _on_reset_pressed() -> void:
	del_count = 0
	del_power = 0
	update0()
