extends Node

func _ready() -> void:
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		load0()
		AsdaInventory.add_money_low(0)
# stat ################################################################
# time
@export var time_min: int
@export var time_hour: int
@export var time_day: int
# health
@export var health_max: int
@export var health: int
# food
@export var food_max: int
@export var food: int
# energy
@export var energy_max: int
@export var energy: int
# ect ################################################################
@export var mine_floor: int
@export var mine_floor_max: int
# money ################################################################
@export var money_low: int
@export var money_mid: int
@export var money_high: int
@export var money_max: int
# item
# plant ################################################################
@export var karat: float
@export var karat_seed: int

@export var tamaso: float
@export var tamaso_seed: int
# fert ################################################################
@export var fert_speed_low: int
@export var fert_speed_mid: int
@export var fert_speed_high: int
@export var fert_speed_max: int

@export var fert_size_low: int
@export var fert_size_mid: int
@export var fert_size_high: int
@export var fert_size_max: int
# ect ################################################################
@export var shovel: int
@export var axe: int

@export var wood: int
# fish ################################################################
@export var bait: int
@export var fish_rod: int
@export var crab_pot: int
@export var fish: int
@export var crab: int
# mineral ################################################################
@export var stone: int

@export var cese: int
@export var cese_pick: int
@export var cese_knife: int
@export var cese_shield: int
	
@export var lowaral: int
@export var lowaral_pick: int
@export var lowaral_knife: int
@export var lowaral_shield: int
	
@export var iena: int
@export var iena_pick: int
@export var iena_knife: int
@export var iena_shield: int
	
@export var midaral: int
@export var midaral_pick: int
@export var midaral_knife: int
@export var midaral_shield: int
	
@export var graize: int
@export var graize_pick: int
@export var graize_knife: int
@export var graize_shield: int
	
@export var higaral: int
@export var higaral_pick: int
@export var higaral_knife: int
@export var higaral_shield: int
	
@export var adanto: int
@export var adanto_pick: int
@export var adanto_knife: int
@export var adanto_shield: int
	
@export var maxaral: int
@export var maxaral_pick: int
@export var maxaral_knife: int
@export var maxaral_shield: int
# permit ################################################################
@export var permit_farm: int
@export var permit_mine: int
@export var permit_wood: int
@export var permit_fish: int
@export var permit_crab: int

func load0():
# stat ################################################################
# time
	AsdaInventory.time_min = time_min
	AsdaInventory.time_hour = time_hour
	AsdaInventory.time_day = time_day
# health
	AsdaInventory.health_max = health_max
	AsdaInventory.health = health
# food
	AsdaInventory.food_max = food_max
	AsdaInventory.food = food
# energy
	AsdaInventory.energy_max = energy_max
	AsdaInventory.energy = energy
# ect ################################################################
	AsdaInventory.mine_floor = mine_floor
	AsdaInventory.mine_floor_max = mine_floor_max
# money ################################################################
	AsdaInventory.money_low = money_low
	AsdaInventory.money_mid = money_mid
	AsdaInventory.money_high = money_high
	AsdaInventory.money_max = money_max
# item
# plant ################################################################
	AsdaInventory.karat = karat
	AsdaInventory.karat_seed = karat_seed
	
	AsdaInventory.tamaso = tamaso
	AsdaInventory.tamaso_seed = tamaso_seed
# fert ################################################################
	AsdaInventory.fert_speed_low = fert_speed_low
	AsdaInventory.fert_speed_mid = fert_speed_mid
	AsdaInventory.fert_speed_high = fert_speed_high
	AsdaInventory.fert_speed_max = fert_speed_max
	
	AsdaInventory.fert_size_low = fert_size_low
	AsdaInventory.fert_size_mid = fert_size_mid
	AsdaInventory.fert_size_high = fert_size_high
	AsdaInventory.fert_size_max = fert_size_max
# ect ################################################################
	AsdaInventory.shovel = shovel
	AsdaInventory.axe = axe
	
	AsdaInventory.wood = wood
# fish ################################################################
	AsdaInventory.bait = bait
	AsdaInventory.fish_rod = fish_rod
	AsdaInventory.crab_pot = crab_pot
	AsdaInventory.fish = fish
	AsdaInventory.crab = crab
# mineral ################################################################
	AsdaInventory.stone = stone
	
	AsdaInventory.cese = cese
	AsdaInventory.cese_pick = cese_pick
	AsdaInventory.cese_knife = cese_knife
	AsdaInventory.cese_shield = cese_shield
	
	AsdaInventory.lowaral = lowaral
	AsdaInventory.lowaral_pick = lowaral_pick
	AsdaInventory.lowaral_knife = lowaral_knife
	AsdaInventory.lowaral_shield = lowaral_shield
	
	AsdaInventory.iena = iena
	AsdaInventory.iena_pick = iena_pick
	AsdaInventory.iena_knife = iena_knife
	AsdaInventory.iena_shield = iena_shield
	
	AsdaInventory.midaral = midaral
	AsdaInventory.midaral_pick = midaral_pick
	AsdaInventory.midaral_knife = midaral_knife
	AsdaInventory.midaral_shield = midaral_shield
	
	AsdaInventory.graize = graize
	AsdaInventory.graize_pick = graize_pick
	AsdaInventory.graize_knife = graize_knife
	AsdaInventory.graize_shield = graize_shield
	
	AsdaInventory.higaral = higaral
	AsdaInventory.higaral_pick = higaral_pick
	AsdaInventory.higaral_knife = higaral_knife
	AsdaInventory.higaral_shield = higaral_shield
	
	AsdaInventory.adanto = adanto
	AsdaInventory.adanto_pick = adanto_pick
	AsdaInventory.adanto_knife = adanto_knife
	AsdaInventory.adanto_shield = adanto_shield
	
	AsdaInventory.maxaral = maxaral
	AsdaInventory.maxaral_pick = maxaral_pick
	AsdaInventory.maxaral_knife = maxaral_knife
	AsdaInventory.maxaral_shield = maxaral_shield
# permit ################################################################
	AsdaInventory.permit_farm = permit_farm
	AsdaInventory.permit_mine = permit_mine
	AsdaInventory.permit_wood = permit_wood
	AsdaInventory.permit_fish = permit_fish
	AsdaInventory.permit_crab = permit_crab

func save0():
# stat ################################################################
# time
	time_min = AsdaInventory.time_min
	time_hour = AsdaInventory.time_hour
	time_day = AsdaInventory.time_day
# health
	health_max = AsdaInventory.health_max
	health = AsdaInventory.health
# food
	food_max = AsdaInventory.food_max
	food = AsdaInventory.food
# energy
	energy_max = AsdaInventory.energy_max
	energy = AsdaInventory.energy
# ect ################################################################
	mine_floor = AsdaInventory.mine_floor
	mine_floor_max = AsdaInventory.mine_floor_max
# money ################################################################
	money_low = AsdaInventory.money_low
	money_mid = AsdaInventory.money_mid
	money_high = AsdaInventory.money_high
	money_max = AsdaInventory.money_max
# item
# plant ################################################################
	karat = AsdaInventory.karat
	karat_seed = AsdaInventory.karat_seed
	
	tamaso = AsdaInventory.tamaso
	tamaso_seed = AsdaInventory.tamaso_seed
# fert ################################################################
	fert_speed_low = AsdaInventory.fert_speed_low
	fert_speed_mid = AsdaInventory.fert_speed_mid
	fert_speed_high = AsdaInventory.fert_speed_high
	fert_speed_max = AsdaInventory.fert_speed_max
	
	fert_size_low = AsdaInventory.fert_size_low
	fert_size_mid = AsdaInventory.fert_size_mid
	fert_size_high = AsdaInventory.fert_size_high
	fert_size_max = AsdaInventory.fert_size_max
# ect ################################################################
	shovel = AsdaInventory.shovel
	axe = AsdaInventory.axe
	
	wood = AsdaInventory.wood
# fish ################################################################
	bait = AsdaInventory.bait
	fish_rod = AsdaInventory.fish_rod
	crab_pot = AsdaInventory.crab_pot
	fish = AsdaInventory.fish
	crab = AsdaInventory.crab
# mineral ################################################################
	stone = AsdaInventory.stone
	
	cese = AsdaInventory.cese
	cese_pick = AsdaInventory.cese_pick
	cese_knife = AsdaInventory.cese_knife
	cese_shield = AsdaInventory.cese_shield
	
	lowaral = AsdaInventory.lowaral
	lowaral_pick = AsdaInventory.lowaral_pick
	lowaral_knife = AsdaInventory.lowaral_knife
	lowaral_shield = AsdaInventory.lowaral_shield
	
	iena = AsdaInventory.iena
	iena_pick = AsdaInventory.iena_pick
	iena_knife = AsdaInventory.iena_knife
	iena_shield = AsdaInventory.iena_shield
	
	midaral = AsdaInventory.midaral
	midaral_pick = AsdaInventory.midaral_pick
	midaral_knife = AsdaInventory.midaral_knife
	midaral_shield = AsdaInventory.midaral_shield
	
	graize = AsdaInventory.graize
	graize_pick = AsdaInventory.graize_pick
	graize_knife = AsdaInventory.graize_knife
	graize_shield = AsdaInventory.graize_shield
	
	higaral = AsdaInventory.higaral
	higaral_pick = AsdaInventory.higaral_pick
	higaral_knife = AsdaInventory.higaral_knife
	higaral_shield = AsdaInventory.higaral_shield
	
	adanto = AsdaInventory.adanto
	adanto_pick = AsdaInventory.adanto_pick
	adanto_knife = AsdaInventory.adanto_knife
	adanto_shield = AsdaInventory.adanto_shield
	
	maxaral = AsdaInventory.maxaral
	maxaral_pick = AsdaInventory.maxaral_pick
	maxaral_knife = AsdaInventory.maxaral_knife
	maxaral_shield = AsdaInventory.maxaral_shield
# fish ################################################################
	bait = AsdaInventory.bait
	fish_rod = AsdaInventory.fish_rod
	crab_pot = AsdaInventory.crab_pot
	fish = AsdaInventory.fish
	crab = AsdaInventory.crab

func _on_tree_exiting() -> void:
	save0()
	var data = zzzz_resource.new()
	var inventory_data = self
	var inv_pack = PackedScene.new()
	inv_pack.pack(inventory_data)
	data.inv.append(inv_pack)
	ResourceSaver.save(data, "res://Scene/SaveScene/inv.tres")
