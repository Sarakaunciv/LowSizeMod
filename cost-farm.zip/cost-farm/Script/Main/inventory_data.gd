extends Node

func _ready() -> void:
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		load0()
		AsdaInventory.add_money_low(0)

@export var money_low: int
@export var money_mid: int
@export var money_high: int
@export var money_max: int
# item
@export var karat: float
@export var karat_seed: int

@export var tamaso: float
@export var tamaso_seed: int

@export var fert_speed_low: int
@export var fert_speed_mid: int
@export var fert_speed_high: int
@export var fert_speed_max: int

@export var fert_size_low: int
@export var fert_size_mid: int
@export var fert_size_high: int
@export var fert_size_max: int

func load0():
	AsdaInventory.money_low = money_low
	AsdaInventory.money_mid = money_mid
	AsdaInventory.money_high = money_high
	AsdaInventory.money_max = money_max
	# item
	AsdaInventory.karat = karat
	AsdaInventory.karat_seed = karat_seed
	
	AsdaInventory.tamaso = tamaso
	AsdaInventory.tamaso_seed = tamaso_seed
	
	AsdaInventory.fert_speed_low = fert_speed_low
	AsdaInventory.fert_speed_mid = fert_speed_mid
	AsdaInventory.fert_speed_high = fert_speed_high
	AsdaInventory.fert_speed_max = fert_speed_max
	
	AsdaInventory.fert_size_low = fert_size_low
	AsdaInventory.fert_size_mid = fert_size_mid
	AsdaInventory.fert_size_high = fert_size_high
	AsdaInventory.fert_size_max = fert_size_max

func save0():
	money_low = AsdaInventory.money_low
	money_mid = AsdaInventory.money_mid
	money_high = AsdaInventory.money_high
	money_max = AsdaInventory.money_max
	# item
	karat = AsdaInventory.karat
	karat_seed = AsdaInventory.karat_seed
	
	tamaso = AsdaInventory.tamaso
	tamaso_seed = AsdaInventory.tamaso_seed
	
	fert_speed_low = AsdaInventory.fert_speed_low
	fert_speed_mid = AsdaInventory.fert_speed_mid
	fert_speed_high = AsdaInventory.fert_speed_high
	fert_speed_max = AsdaInventory.fert_speed_max
	
	fert_size_low = AsdaInventory.fert_size_low
	fert_size_mid = AsdaInventory.fert_size_mid
	fert_size_high = AsdaInventory.fert_size_high
	fert_size_max = AsdaInventory.fert_size_max

func _on_tree_exiting() -> void:
	save0()
	var data = zzzz_resource.new()
	var inventory_data = self
	var inv_pack = PackedScene.new()
	inv_pack.pack(inventory_data)
	data.inv.append(inv_pack)
	ResourceSaver.save(data, "res://Scene/SaveScene/inv.tres")
