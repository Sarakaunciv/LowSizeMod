extends Node

func _ready() -> void:
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		load0()
		AsdaInventory.add_money_low(0)

@export var money_low: int
@export var money_mid: int
@export var money_high: int
@export var money_max: int
# item
# plant ################################################################
@export var karat: float
@export var karat_seed: int

@export var tamaso: float
@export var tamaso_seed: int
# fert ################################################################
@export var fert_speed_low: int
@export var fert_speed_mid: int
@export var fert_speed_high: int
@export var fert_speed_max: int

@export var fert_size_low: int
@export var fert_size_mid: int
@export var fert_size_high: int
@export var fert_size_max: int
# mineral ################################################################
@export var cese: int
@export var cese_pick: int
@export var cese_knife: int
@export var cese_shield: int
	
@export var lowaral: int
@export var lowaral_pick: int
@export var lowaral_knife: int
@export var lowaral_shield: int
	
@export var iena: int
@export var iena_pick: int
@export var iena_knife: int
@export var iena_shield: int
	
@export var midaral: int
@export var midaral_pick: int
@export var midaral_knife: int
@export var midaral_shield: int
	
@export var graize: int
@export var graize_pick: int
@export var graize_knife: int
@export var graize_shield: int
	
@export var higaral: int
@export var higaral_pick: int
@export var higaral_knife: int
@export var higaral_shield: int
	
@export var adanto: int
@export var adanto_pick: int
@export var adanto_knife: int
@export var adanto_shield: int
	
@export var maxaral: int
@export var maxaral_pick: int
@export var maxaral_knife: int
@export var maxaral_shield: int

func load0():
	AsdaInventory.money_low = money_low
	AsdaInventory.money_mid = money_mid
	AsdaInventory.money_high = money_high
	AsdaInventory.money_max = money_max
	# item
	# plant ################################################################
	AsdaInventory.karat = karat
	AsdaInventory.karat_seed = karat_seed
	
	AsdaInventory.tamaso = tamaso
	AsdaInventory.tamaso_seed = tamaso_seed
	# fert ################################################################
	AsdaInventory.fert_speed_low = fert_speed_low
	AsdaInventory.fert_speed_mid = fert_speed_mid
	AsdaInventory.fert_speed_high = fert_speed_high
	AsdaInventory.fert_speed_max = fert_speed_max
	
	AsdaInventory.fert_size_low = fert_size_low
	AsdaInventory.fert_size_mid = fert_size_mid
	AsdaInventory.fert_size_high = fert_size_high
	AsdaInventory.fert_size_max = fert_size_max
	# mineral ################################################################
	AsdaInventory.cese = cese
	AsdaInventory.cese_pick = cese_pick
	AsdaInventory.cese_knife = cese_knife
	AsdaInventory.cese_shield = cese_shield
	
	AsdaInventory.lowaral = lowaral
	AsdaInventory.lowaral_pick = lowaral_pick
	AsdaInventory.lowaral_knife = lowaral_knife
	AsdaInventory.lowaral_shield = lowaral_shield
	
	AsdaInventory.iena = iena
	AsdaInventory.iena_pick = iena_pick
	AsdaInventory.iena_knife = iena_knife
	AsdaInventory.iena_shield = iena_shield
	
	AsdaInventory.midaral = midaral
	AsdaInventory.midaral_pick = midaral_pick
	AsdaInventory.midaral_knife = midaral_knife
	AsdaInventory.midaral_shield = midaral_shield
	
	AsdaInventory.graize = graize
	AsdaInventory.graize_pick = graize_pick
	AsdaInventory.graize_knife = graize_knife
	AsdaInventory.graize_shield = graize_shield
	
	AsdaInventory.higaral = higaral
	AsdaInventory.higaral_pick = higaral_pick
	AsdaInventory.higaral_knife = higaral_knife
	AsdaInventory.higaral_shield = higaral_shield
	
	AsdaInventory.adanto = adanto
	AsdaInventory.adanto_pick = adanto_pick
	AsdaInventory.adanto_knife = adanto_knife
	AsdaInventory.adanto_shield = adanto_shield
	
	AsdaInventory.maxaral = maxaral
	AsdaInventory.maxaral_pick = maxaral_pick
	AsdaInventory.maxaral_knife = maxaral_knife
	AsdaInventory.maxaral_shield = maxaral_shield

func save0():
	money_low = AsdaInventory.money_low
	money_mid = AsdaInventory.money_mid
	money_high = AsdaInventory.money_high
	money_max = AsdaInventory.money_max
	# item
	# plant ################################################################
	karat = AsdaInventory.karat
	karat_seed = AsdaInventory.karat_seed
	
	tamaso = AsdaInventory.tamaso
	tamaso_seed = AsdaInventory.tamaso_seed
	# fert ################################################################
	fert_speed_low = AsdaInventory.fert_speed_low
	fert_speed_mid = AsdaInventory.fert_speed_mid
	fert_speed_high = AsdaInventory.fert_speed_high
	fert_speed_max = AsdaInventory.fert_speed_max
	
	fert_size_low = AsdaInventory.fert_size_low
	fert_size_mid = AsdaInventory.fert_size_mid
	fert_size_high = AsdaInventory.fert_size_high
	fert_size_max = AsdaInventory.fert_size_max
	# mineral ################################################################

func _on_tree_exiting() -> void:
	save0()
	var data = zzzz_resource.new()
	var inventory_data = self
	var inv_pack = PackedScene.new()
	inv_pack.pack(inventory_data)
	data.inv.append(inv_pack)
	ResourceSaver.save(data, "res://Scene/SaveScene/inv.tres")
