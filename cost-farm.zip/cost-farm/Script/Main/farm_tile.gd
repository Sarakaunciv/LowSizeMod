extends Node2D

var is_dark: bool = false
var is_hoe: bool = false

@onready var button: Button = $Button
func _ready() -> void:
	update0()
	update1()
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

@onready var dirt: Sprite2D = $dirt
func update0():
	dirt.region_rect.position = AaaaGlobal.atlas_dirt# * AaaaGlobal.the_texture_size
	if is_dark == true:
		dirt.region_rect.position = AaaaGlobal.atlas_dirt_dark
@onready var hoe_dirt: Sprite2D = $dirt/hoe_dirt
func update1():
	if is_hoe == true:
		hoe_dirt.visible = true

func _on_button_mouse_entered() -> void:
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_pressed() -> void:
	if is_hoe == false:
		hoe0()
	elif is_occupy == false:
		plant_plant0()
	else:
		plant1.harvest0()
func hoe0():
	is_hoe = true
	update1()

@onready var plant: Node2D = $plant
var plant0 = load("res://Script/Main/Plant/plant.tscn")
var plant1
var is_occupy: bool = false
func plant_plant0():
	if is_occupy == false:
		is_occupy = true
		var del0plant = plant0.instantiate()
		plant.call_deferred("add_child", del0plant)
		plant1 = del0plant

func kill_plant():
	is_occupy = false
	plant1.queue_free()
