extends Node2D

@onready var fertilizer: Node2D = $dirt/hoe_dirt/fertilizer
@onready var button: Button = $Button

func _ready() -> void:
	update0()
	update1()
	update5()
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS
	fertilizer.z_index = 8

@onready var dirt: Sprite2D = $dirt
@export var is_dark: bool = false
func update0():
	dirt.region_rect.position = AaaaGlobal.atlas_dirt
	if is_dark == true:
		dirt.region_rect.position = AaaaGlobal.atlas_dirt_dark
@onready var hoe_dirt: Sprite2D = $dirt/hoe_dirt
@export var is_hoe: bool = false
func update1():
	if is_hoe == true:
		hoe_dirt.visible = true

@onready var edge_hover: Sprite2D = $edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false

var seed_pool = [AaaaGlobal.id_karat_seed, AaaaGlobal.id_tamaso_seed, AaaaGlobal.id_patrak_seed, AaaaGlobal.id_apos_seed, AaaaGlobal.id_whaat_seed, AaaaGlobal.id_garn_seed, AaaaGlobal.id_graize_frizet_seed, AaaaGlobal.id_yume_karst_faw_seed]
var fert_speed_pool = [AaaaGlobal.id_fert_speed_low, AaaaGlobal.id_fert_speed_mid, AaaaGlobal.id_fert_speed_high, AaaaGlobal.id_fert_speed_max]
var fert_size_pool = [AaaaGlobal.id_fert_size_low, AaaaGlobal.id_fert_size_mid, AaaaGlobal.id_fert_size_high, AaaaGlobal.id_fert_size_max]
@export var is_occupy: bool = false
func _on_button_pressed() -> void:
	if is_hoe == false:
		hoe0()
	elif is_occupy == false:
		if AsasManager.hold_item_id in seed_pool:
			plant_plant0()
		elif AsasManager.hold_item_id in fert_speed_pool or AsasManager.hold_item_id in fert_size_pool:
			plant_fert0()
	elif is_occupy == true:
		if AsasManager.hold_item_id == AaaaGlobal.id_shovel and AsdaInventory.shovel > 0:
			AsdaInventory.add_time_min(1)
			kill_plant()
		elif AsasManager.hold_item_id in fert_speed_pool:
			plant_fert0()
		else:
			harvest0()
func hoe0():
	AsdaInventory.add_time_min(4)
	is_hoe = true
	update1()

func plant_fert0():
	match AsasManager.hold_item_id:
		AaaaGlobal.id_fert_speed_low:
			if fertilizer_speed < AaaaGlobal.fert_speed_low_value and AsdaInventory.fert_speed_low >= AsdaInventory.permit_farm:
				fertilizer_speed = AaaaGlobal.fert_speed_low_value
				AsdaInventory.add_fert_speed_low(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
		AaaaGlobal.id_fert_speed_mid:
			if fertilizer_speed < AaaaGlobal.fert_speed_mid_value and AsdaInventory.fert_speed_mid >= AsdaInventory.permit_farm:
				fertilizer_speed = AaaaGlobal.fert_speed_mid_value
				AsdaInventory.add_fert_speed_mid(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
		AaaaGlobal.id_fert_speed_high:
			if fertilizer_speed < AaaaGlobal.fert_speed_high_value and AsdaInventory.fert_speed_high >= AsdaInventory.permit_farm:
				fertilizer_speed = AaaaGlobal.fert_speed_high_value
				AsdaInventory.add_fert_speed_high(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
		AaaaGlobal.id_fert_speed_max:
			if fertilizer_speed < AaaaGlobal.fert_speed_max_value and AsdaInventory.fert_speed_max >= AsdaInventory.permit_farm:
				fertilizer_speed = AaaaGlobal.fert_speed_max_value
				AsdaInventory.add_fert_speed_max(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
		AaaaGlobal.id_fert_size_low:
			if fertilizer_size < AaaaGlobal.fert_size_low_value and AsdaInventory.fert_size_low >= AsdaInventory.permit_farm:
				fertilizer_size = AaaaGlobal.fert_size_low_value
				AsdaInventory.add_fert_size_low(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
		AaaaGlobal.id_fert_size_mid:
			if fertilizer_size < AaaaGlobal.fert_size_mid_value and AsdaInventory.fert_size_mid >= AsdaInventory.permit_farm:
				fertilizer_size = AaaaGlobal.fert_size_mid_value
				AsdaInventory.add_fert_size_mid(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
		AaaaGlobal.id_fert_size_high:
			if fertilizer_size < AaaaGlobal.fert_size_high_value and AsdaInventory.fert_size_high >= AsdaInventory.permit_farm:
				fertilizer_size = AaaaGlobal.fert_size_high_value
				AsdaInventory.add_fert_size_high(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
		AaaaGlobal.id_fert_size_max:
			if fertilizer_size < AaaaGlobal.fert_size_max_value and AsdaInventory.fert_size_max >= AsdaInventory.permit_farm:
				fertilizer_size = AaaaGlobal.fert_size_max_value
				AsdaInventory.add_fert_size_max(AsdaInventory.permit_farm * -1)
				AsdaInventory.add_time_min(1)
	update4()
func kill_fert():
	fertilizer_speed = 1.0
	fertilizer_size = 1.0

@onready var speed: Sprite2D = $dirt/hoe_dirt/fertilizer/speed
@onready var size: Sprite2D = $dirt/hoe_dirt/fertilizer/size
func update4():
	if fertilizer_speed != 1.0:
		speed.visible = true
		match fertilizer_speed:
			AaaaGlobal.fert_speed_low_value:
				speed.region_rect.position = AaaaGlobal.atlas_bag_low_inv
			AaaaGlobal.fert_speed_mid_value:
				speed.region_rect.position = AaaaGlobal.atlas_bag_mid_inv
			AaaaGlobal.fert_speed_high_value:
				speed.region_rect.position = AaaaGlobal.atlas_bag_high_inv
			AaaaGlobal.fert_speed_max_value:
				speed.region_rect.position = AaaaGlobal.atlas_bag_max_inv
	else:
		speed.visible = false
	if fertilizer_size != 1.0:
		size.visible = true
		match fertilizer_size:
			AaaaGlobal.fert_size_low_value:
				size.region_rect.position = AaaaGlobal.atlas_bag_low_inv
			AaaaGlobal.fert_size_mid_value:
				size.region_rect.position = AaaaGlobal.atlas_bag_mid_inv
			AaaaGlobal.fert_size_high_value:
				size.region_rect.position = AaaaGlobal.atlas_bag_high_inv
			AaaaGlobal.fert_size_max_value:
				size.region_rect.position = AaaaGlobal.atlas_bag_max_inv
	else:
		size.visible = false

func plant_plant0():
	match AsasManager.hold_item_id:
		AaaaGlobal.id_karat_seed:
			if AsdaInventory.karat_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_karat_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_karat
				AsdaInventory.add_time_min(1)
			else:
				return
		AaaaGlobal.id_tamaso_seed:
			if AsdaInventory.tamaso_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_tamaso_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_tamaso
				AsdaInventory.add_time_min(1)
			else:
				return
		AaaaGlobal.id_patrak_seed:
			if AsdaInventory.patrak_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_patrak_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_patrak
				AsdaInventory.add_time_min(1)
			else:
				return
		AaaaGlobal.id_apos_seed:
			if AsdaInventory.apos_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_apos_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_apos
				AsdaInventory.add_time_min(1)
			else:
				return
		AaaaGlobal.id_whaat_seed:
			if AsdaInventory.whaat_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_whaat_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_whaat
				AsdaInventory.add_time_min(1)
			else:
				return
		AaaaGlobal.id_garn_seed:
			if AsdaInventory.garn_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_garn_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_garn
				AsdaInventory.add_time_min(1)
			else:
				return
		AaaaGlobal.id_graize_frizet_seed:
			if AsdaInventory.graize_frizet_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_graize_frizet_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_graize_frizet
				AsdaInventory.add_time_min(1)
			else:
				return
		AaaaGlobal.id_yume_karst_faw_seed:
			if AsdaInventory.yume_karst_faw_seed >= AsdaInventory.permit_farm:
				AsdaInventory.add_yume_karst_faw_seed(AsdaInventory.permit_farm * -1)
				plant_id = AaaaGlobal.id_yume_karst_faw
				AsdaInventory.add_time_min(1)
			else:
				return
	is_occupy = true
	update2()
func kill_plant():
	is_occupy = false
	
	plant.visible = false
	plant_id = 0
	plant_age = 0
	is_multi_harvest = false

# plant
@onready var plant: Sprite2D = $dirt/hoe_dirt/plant

@export var plant_id: int = 0
@export var plant_age: int = 0
var multi_harvest_plant = [AaaaGlobal.id_tamaso]
@export var is_multi_harvest: bool = false

@export var fertilizer_speed: float = 1.0
@export var fertilizer_size: float = 1.0

@export var plant_sprite_main_pos: Vector2 = Vector2()
func update2():
	if plant_id in multi_harvest_plant:
		is_multi_harvest = true
	plant.visible = true
	match plant_id:
		AaaaGlobal.id_karat:
			plant.region_rect.position = AaaaGlobal.atlas_karat_plant
		AaaaGlobal.id_tamaso:
			plant.region_rect.position = AaaaGlobal.atlas_tamaso_plant
	plant_sprite_main_pos = plant.region_rect.position
func update3():
	if plant_age >= 1200 and is_multi_harvest == true:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_5
	elif plant_age >= 1000:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_4
	elif plant_age >= 700:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_3
	elif plant_age >= 400:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_2
	elif plant_age >= 100:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_1

@export var current_day: int = 0
func update5():
	if current_day < AsdaInventory.time_day:
		for del0 in range(AsdaInventory.time_day - current_day):
			grow0()
func grow0():
	current_day += 1
	if is_occupy == true:
		match plant_id:
			AaaaGlobal.id_karat:
				plant_age += AaaaGlobal.karat_grow_speed * fertilizer_speed
			AaaaGlobal.id_tamaso:
				plant_age += AaaaGlobal.tamaso_grow_speed * fertilizer_speed
			AaaaGlobal.id_patrak:
				plant_age += AaaaGlobal.patrak_grow_speed * fertilizer_speed
			AaaaGlobal.id_apos:
				plant_age += AaaaGlobal.apos_grow_speed * fertilizer_speed
			AaaaGlobal.id_whaat:
				plant_age += AaaaGlobal.whaat_grow_speed * fertilizer_speed
			AaaaGlobal.id_garn:
				plant_age += AaaaGlobal.garn_grow_speed * fertilizer_speed
			AaaaGlobal.id_graize_frizet:
				plant_age += AaaaGlobal.graize_frizet_grow_speed * fertilizer_speed
			AaaaGlobal.id_yume_karst_faw:
				plant_age += AaaaGlobal.yume_karst_faw_grow_speed * fertilizer_speed
		update3()

var del0count: float = 0.0
func harvest0():
	if is_multi_harvest == true:
		if plant_age >= 1200:
			plant_age -= 1000
			harvest1()
			plant_age = 1000
			update3()
	else:
		if plant_age >= 1000:
			harvest1()
			kill_plant()
func harvest1():
	del0count = AsdaInventory.permit_farm * fertilizer_size * plant_age / 1000
	match plant_id:
		AaaaGlobal.id_karat:
			AsdaInventory.add_karat(del0count * AaaaGlobal.karat_harvest_count)
		AaaaGlobal.id_tamaso:
			AsdaInventory.add_tamaso(del0count * AaaaGlobal.tamaso_harvest_count)
		AaaaGlobal.id_patrak:
			AsdaInventory.add_patrak(del0count * AaaaGlobal.patrak_harvest_count)
		AaaaGlobal.id_apos:
			AsdaInventory.add_apos(del0count * AaaaGlobal.apos_harvest_count)
		AaaaGlobal.id_whaat:
			AsdaInventory.add_whaat(del0count * AaaaGlobal.whaat_harvest_count)
		AaaaGlobal.id_garn:
			AsdaInventory.add_garn(del0count * AaaaGlobal.garn_harvest_count)
		AaaaGlobal.id_graize_frizet:
			AsdaInventory.add_graize_frizet(del0count * AaaaGlobal.graize_frizet_harvest_count)
		AaaaGlobal.id_yume_karst_faw:
			AsdaInventory.add_yume_karst_faw(del0count * AaaaGlobal.yume_karst_faw_harvest_count)
	AsdaInventory.add_time_min(1)
