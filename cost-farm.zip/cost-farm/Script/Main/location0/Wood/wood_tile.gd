extends Node2D

@onready var button: Button = $Button
@onready var auto_dig_timer: Timer = $auto_dig_timer
var mine
var health_bar

var stone_id: int = 0
var hp_max: int = 12000
var hp_left: int = 12000

func _ready() -> void:
	AsasManager.set_auto_stop.connect(_on_button_mouse_exited)
	auto_dig_timer.wait_time = 0.01
	auto_dig_timer.timeout.connect(dig0)
	mine = get_node("../..")
	health_bar = get_node("health_bar")
	update0()
	if 1 == randi_range(1, 10):
		is_tree = true
	update1()
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

@onready var body_sprite: Sprite2D = $body_sprite
@export var is_dark: bool = false
func update0():
	body_sprite.region_rect.position = AaaaGlobal.atlas_wood_tile
	if is_dark == true:
		body_sprite.region_rect.position = AaaaGlobal.atlas_wood_tile_dark

@onready var tree: Sprite2D = $body_sprite/tree
@export var is_tree: bool = false
func update1():
	if is_tree == true:
		tree.visible = true
	else:
		tree.visible = false

@onready var edge_hover: Sprite2D = $edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
	auto_dig_timer.stop()

func _on_button_pressed() -> void:
	if is_tree == true:
		auto_dig_timer.start()
		dig0()

func dig0():
	AsdaInventory.add_time_min(1)
	hp_left -= AsasManager.axe_power
	if hp_left <= 0:
		break0()
	health_bar.update_health_bar()

func break0():
	auto_dig_timer.stop()
	is_tree = false
	update1()
	hp_left = hp_max #safe
	AsdaInventory.add_wood(25 * AsdaInventory.permit_wood)
