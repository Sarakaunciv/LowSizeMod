extends Node2D

@onready var progress: TextureProgressBar = $progress
@onready var timer: Timer = $Timer
var fish_progress_max: int = 10000
var fish_progress: int = 5000

var fish_size: int = 160
var tier: int = 1
func _ready() -> void:
	progress.max_value = fish_progress_max
	get_tier()
	update0()
	update1()
	timer.timeout.connect(fish_pull)
	timer.wait_time = 0.1
	timer.start()

@onready var label: Label = $fish/Label
var fish_pull_power: int = 0
var fish_count: float = 0
var max_range: int = 0
func get_tier():
	tier = randi_range(1, 4)
	label.text = str(tier)
	match tier:
		1:
			fish_pull_power = 40
			max_range = 480
			fish_count = randf_range(0.2, 0.32)
		2:
			fish_pull_power = 90
			max_range = 240
			fish_count = randf_range(0.4, 0.56)
		3:
			fish_pull_power = 140
			max_range = 120
			fish_count = randf_range(0.72, 1.28)
		4:
			fish_pull_power = 240
			max_range = 0
			fish_count = randf_range(2.0, 3.2)

func fish_pull():
	fish_progress -= fish_pull_power
	update1()

func update0():
	fish.position = Vector2(randi_range(0, 1600 - fish_size - (max_range * 2)), randi_range(0, 800 - fish_size - max_range))

func update1():
	if fish_progress >= 10000:
		catch()
	elif fish_progress <= 0:
		fail()
	progress.value = fish_progress

@onready var fish: ColorRect = $fish
func _on_fish_mouse_entered() -> void:
	fish_progress += 1000
	update0()
	update1()

func fail():
	AsdaInventory.add_fish(0)
	queue_free()
func catch():
	AsdaInventory.add_fish(fish_count)
	queue_free()
