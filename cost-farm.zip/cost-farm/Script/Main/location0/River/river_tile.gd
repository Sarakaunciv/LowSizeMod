extends Node2D

@onready var button: Button = $Button

func _ready() -> void:
	update0()
	update1()
	update2()
	update3()
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

@onready var body_sprite: Sprite2D = $body_sprite
@export var is_dark: bool = false
func update0():
	body_sprite.region_rect.position = AaaaGlobal.atlas_river_tile
	if is_dark == true:
		body_sprite.region_rect.position = AaaaGlobal.atlas_river_tile_dark

@onready var crab_pot: Sprite2D = $body_sprite/crab_pot
@export var is_crab_pot: bool = false
func update1():
	if is_crab_pot == true:
		crab_pot.visible = true
	else:
		crab_pot.visible = false

@onready var edge_hover: Sprite2D = $edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false

func _on_button_pressed() -> void:
	if AsasManager.hold_item_id == AaaaGlobal.id_crab_pot and is_crab_pot == false and AsdaInventory.crab_pot >= AsdaInventory.permit_crab:
		is_crab_pot = true
		AsdaInventory.add_crab_pot(AsdaInventory.permit_crab * -1)
		update1()
	elif AsasManager.hold_item_id == AaaaGlobal.id_fish_rod and is_crab_pot == true and AsdaInventory.fish_rod > 0:
		harvest0()
		is_crab_pot = false
		AsdaInventory.add_crab_pot(AsdaInventory.permit_crab)
		crab_count = 0
		update1()
	elif is_crab_pot == true:
		harvest0()

@export var current_day: int = 0
func update3():
	if current_day < AsdaInventory.time_day:
		for del0 in range(AsdaInventory.time_day - current_day):
			grow0()

@onready var crab: Sprite2D = $body_sprite/crab_pot/crab
@export var crab_count: int = 0
func update2():
	if crab_count >= 1000:
		crab.visible = true
	else:
		crab.visible = false
func grow0():
	current_day += 1
	if is_crab_pot == true:
		crab_count += randi_range(500, 1500)
		update2()

var del0count: float = 0.0
func harvest0():
	if crab_count >= 1000:
		AsdaInventory.add_crab(1.0 * crab_count / 1000 * AsdaInventory.permit_crab)
		crab_count = 0
		update2()
