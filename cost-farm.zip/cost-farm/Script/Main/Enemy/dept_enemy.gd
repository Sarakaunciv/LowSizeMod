extends Node2D

@onready var button: Button = $Button
@onready var auto_dig_timer: Timer = $auto_dig_timer
var mine
var health_bar

var hp_max: int = 1
var hp_left: int = 1
var dmg_reduction: int = 1
var knife_power: float = 1
var attack_power: float = 1
func _ready() -> void:
	AsasManager.add_location_prevent(1)
	AsasManager.add_auto_stop()
	AsdaInventory.set_time_min.connect(attack)
	auto_dig_timer.wait_time = 0.01
	auto_dig_timer.timeout.connect(dig0)
	health_bar = get_node("health_bar")
	update0()
	knife_power = AsasManager.knife_power * (1.0 * AsasManager.knife_multiplier / dmg_reduction)
	attack_power = (1.0 * hp_max / AsasManager.shield_power) * (1.0 * dmg_reduction / AsasManager.shield_multiplier) * -1
	label.text = str(hp_max, "\n", attack_power, "\n", knife_power)
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS
@onready var label: Label = $Label

@onready var body_sprite: Sprite2D = $body_sprite
var tier: int = 1
func update0():
	match tier:
		4:
			scale *= 2.5
			body_sprite.region_rect.position.x += 6 * AaaaGlobal.the_texture_size
		3:
			scale *= 2
			body_sprite.region_rect.position.x += 4 * AaaaGlobal.the_texture_size
		2:
			scale *= 1.5
			body_sprite.region_rect.position.x += 2 * AaaaGlobal.the_texture_size
	update1()
func update1():
	match tier:
		1:
			hp_max = (40 ** 1 * AsdaInventory.dept_low)
			dmg_reduction = (25 ** 1)
		2:
			hp_max = (40 ** 2 * AsdaInventory.dept_mid)
			dmg_reduction = (25 ** 2)
		3:
			hp_max = (40 ** 3 * AsdaInventory.dept_high)
			dmg_reduction = (25 ** 3)
		4:
			hp_max = (40 ** 4 * AsdaInventory.dept_max)
			dmg_reduction = (25 ** 4)
	hp_left = hp_max

@onready var edge_hover: Sprite2D = $edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
	auto_dig_timer.stop()

func _on_button_pressed() -> void:
	auto_dig_timer.start()
	dig0()

func dig0():
	AsdaInventory.add_time_min(1)
	hp_left -= knife_power
	if hp_left <= 0:
		break0()
	health_bar.update_health_bar()

@onready var enemy: Sprite2D = $enemy
func break0():
	auto_dig_timer.stop()
	AsasManager.add_location_prevent(-1)
	queue_free()

func attack():
	AsdaInventory.add_health(attack_power)
