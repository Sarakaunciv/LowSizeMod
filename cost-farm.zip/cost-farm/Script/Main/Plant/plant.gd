extends Node2D

var id_plant: int = 0
var plant_age: float = 0.0
var multi_harvest_plant = [AaaaGlobal.id_tamaso]
var is_multi_harvest: bool = false

var fertilizer_speed: float = 1.0

var farm_tile
func _ready() -> void:
	AsasManager.set_day.connect(grow0)
	farm_tile = get_node("../..")
	
	id_plant = randi_range(1, 2)
	if id_plant in multi_harvest_plant:
		is_multi_harvest = true
	
	update0()

@onready var sprite_2d: Sprite2D = $Sprite2D
var sprite_2d_main_pos: Vector2 = Vector2()
func update0():
	match id_plant:
		AaaaGlobal.id_karat:
			sprite_2d.region_rect.position = AaaaGlobal.atlas_karat
		AaaaGlobal.id_tamaso:
			sprite_2d.region_rect.position = AaaaGlobal.atlas_tamaso
	sprite_2d_main_pos = sprite_2d.region_rect.position
func update1():
	if plant_age >= 1.2 and is_multi_harvest == true:
		sprite_2d.region_rect.position = sprite_2d_main_pos + AaaaGlobal.atlas_plant_s_5
	elif plant_age >= 1.0:
		sprite_2d.region_rect.position = sprite_2d_main_pos + AaaaGlobal.atlas_plant_s_4
	elif plant_age >= 0.7:
		sprite_2d.region_rect.position = sprite_2d_main_pos + AaaaGlobal.atlas_plant_s_3
	elif plant_age >= 0.4:
		sprite_2d.region_rect.position = sprite_2d_main_pos + AaaaGlobal.atlas_plant_s_2
	elif plant_age >= 0.1:
		sprite_2d.region_rect.position = sprite_2d_main_pos + AaaaGlobal.atlas_plant_s_1

func grow0(del0):
	match id_plant:
		AaaaGlobal.id_karat:
			plant_age += AaaaGlobal.karat_grow_speed * fertilizer_speed
		AaaaGlobal.id_tamaso:
			plant_age += AaaaGlobal.tamaso_grow_speed * fertilizer_speed
	update1()

func harvest0():
	if is_multi_harvest == true:
		if plant_age >= 1.2:
			plant_age -= (plant_age - 1.0)
			update1()
	else:
		if plant_age >= 1.0:
			farm_tile.kill_plant()
