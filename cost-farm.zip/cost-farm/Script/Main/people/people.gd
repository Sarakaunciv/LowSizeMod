extends Node2D

@export var day0: int = 0
# _value
@export var name_value: String = ""
@export var age_value: int = 0
# buff
@export var work_id: int = 0
@export var work_lvl: int = 0

@export var money_value: int = 0
func _ready() -> void:
	update0()

func get_money_value():
	#if 1 == randi_range(1, 8):
		#work_id = AaaaGlobal.id_people_work_cooker
	match work_id:
		0:
			money_value = 0
		AaaaGlobal.id_people_work_farmer:
			money_value = AaaaGlobal.id_people_work_farmer_money
		AaaaGlobal.id_people_work_fisher:
			money_value = AaaaGlobal.id_people_work_fisher_money
		AaaaGlobal.id_people_work_miner:
			money_value = AaaaGlobal.id_people_work_miner_money
		AaaaGlobal.id_people_work_wooder:
			money_value = AaaaGlobal.id_people_work_wooder_money
		AaaaGlobal.id_people_work_cooker:
			money_value = AaaaGlobal.id_people_work_cooker_money
		AaaaGlobal.id_people_work_not:
			money_value = AaaaGlobal.id_people_work_not_money
	for del0 in range(work_lvl):
		money_value *= 3

func update_work():
	if age_value >= AaaaGlobal.people_work_not_age:
		work_id = AaaaGlobal.id_people_work_not
func update0():
	if day0 <= AsdaInventory.time_day:
		time_pass(AsdaInventory.time_day - day0)
	update_work()
	get_money_value()
	update1()

func time_pass(day):
	day0 += day
	age_value += day
	AsdaInventory.add_money_low(money_value * day)

@onready var name_value0: Label = $ColorRect/ColorRect/name_value/Label
@onready var age_value0: Label = $ColorRect/ColorRect/age_value/Label
@onready var money_value0: Label = $ColorRect/ColorRect/money_value/Label
@onready var work_lvl0: Label = $ColorRect/ColorRect/work_lvl/Label
@onready var work_id0: Label = $ColorRect/ColorRect/work_id/Label
func update1():
	name_value0.text = name_value
	age_value0.text = str(age_value / AaaaGlobal.time_day_in_year, "/ ", (age_value % AaaaGlobal.time_day_in_year) / AaaaGlobal.time_day_in_month, "/ ", (age_value % AaaaGlobal.time_day_in_year) % AaaaGlobal.time_day_in_month)
	money_value0.text = str(money_value)
	work_lvl0.text = "lvl " + str(work_lvl + 1)
	match work_id:
		0:
			work_id0.text = "dead"
		AaaaGlobal.id_people_work_farmer:
			work_id0.text = "farmer"
		AaaaGlobal.id_people_work_fisher:
			work_id0.text = "fisher"
		AaaaGlobal.id_people_work_miner:
			work_id0.text = "miner"
		AaaaGlobal.id_people_work_wooder:
			work_id0.text = "wooder"
		AaaaGlobal.id_people_work_not:
			work_id0.text = "not"
		AaaaGlobal.id_people_work_cooker:
			work_id0.text = "cooker"

# ect
var is_follow: bool = false
func _process(delta: float) -> void:
	if is_follow == true:
		self.global_position = get_global_mouse_position() - Vector2(40, 40)

func _on_move_pressed() -> void:
	if is_follow == true:
		is_follow = false
	else:
		is_follow = true
		self.get_parent().move_child(self, -1)
