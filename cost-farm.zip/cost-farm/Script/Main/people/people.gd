extends Node2D

func _ready() -> void:
	update0()

@export var day0: int = 0
# _value
@export var name0_value: String = ""
@export var age0_value: int = 0
# buff
@export var money: int = 0
func update0():
	if day0 <= AsdaInventory.time_day:
		time_pass(AsdaInventory.time_day - day0)
	update1()

func time_pass(day):
	day0 += day
	AsdaInventory.add_money_low(money * day)

@onready var name0: Label = $ColorRect/ColorRect/name/Label
@onready var age0: Label = $ColorRect/ColorRect/age/Label
@onready var money0: Label = $ColorRect/ColorRect/money/Label
func update1():
	name0.text = name0_value
	age0.text = str(age0_value / AaaaGlobal.time_day_in_year, "/ ", (age0_value % AaaaGlobal.time_day_in_year) / AaaaGlobal.time_day_in_month, "/ ", (age0_value % AaaaGlobal.time_day_in_year) % AaaaGlobal.time_day_in_month)
	money0.text = str(money)

# ect
var is_follow: bool = false
func _process(delta: float) -> void:
	if is_follow == true:
		self.global_position = get_global_mouse_position() - Vector2(40, 40)

func _on_move_pressed() -> void:
	if is_follow == true:
		is_follow = false
	else:
		is_follow = true
		self.get_parent().move_child(self, -1)
