extends Node2D

@onready var wood: Button = $wood

var scene_id: int = AaaaGlobal.id_scene_wood
func _ready() -> void:
	AsasManager.get_axe0()
	if AsdaInventory.permit_wood != 0:
		wood.visible = true

@onready var wood_tile_0: Node2D = $wood_tile_0
@onready var permit: ColorRect = $permit
var wood_tile = load("res://Script/Main/Wood/wood_tile.tscn")
func wood_tile_build():
	if AsdaInventory.permit_wood != 0:
		var wood_tile_1 = get_tree().get_nodes_in_group("wood_tile")
		for del0 in wood_tile_1:
			del0.queue_free()
		for del0x in range(20):
			for del0y in range(10):
				var del0tile = wood_tile.instantiate()
				if del0x % 2 == del0y % 2:
					del0tile.is_dark = false
				else:
					del0tile.is_dark = true
				wood_tile_0.call_deferred("add_child", del0tile)
				del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)
	else:
		permit.visible = true

func _on_wood_pressed() -> void:
	AsdaInventory.add_time_min(5)
	wood_tile_build()
