extends Node2D

@onready var ready_delay: Timer = $ready_delay
@onready var floor0: Control = $floor

var scene_id: int = AaaaGlobal.id_scene_mine
func _ready() -> void:
	AsdaInventory.set_mine_floor.connect(update0)
	AsdaInventory.set_mine_floor_max.connect(update1)
	ready_delay.timeout.connect(ready0)
	ready_delay.wait_time = 0.1
	ready_delay.one_shot = true
	ready_delay.start()
	for del0 in floor0.find_children("*"):
		if del0 is Button:
			del0.focus_mode = Control.FOCUS_NONE

func ready0():
	AsasManager.get_pick0()
	AsasManager.get_knife0()
	AsasManager.get_shield0()
	update0()
	mine_tile_build()

@onready var mine_tile_0: Node2D = $mine_tile_0
@onready var permit: ColorRect = $permit
var mine_tile = load("res://Script/Main/mine/mine_tile.tscn")
func mine_tile_build():
	if AsdaInventory.permit_mine != 0:
		var mine_tile_1 = get_tree().get_nodes_in_group("mine_tile")
		for del0 in mine_tile_1:
			del0.queue_free()
		for del0x in range(20):
			for del0y in range(10):
				var del0tile = mine_tile.instantiate()
				mine_tile_0.call_deferred("add_child", del0tile)
				del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)
	else:
		permit.visible = true

@onready var mine_floor: Label = $floor/ColorRect/mine_floor
func update0():
	mine_floor.text = str(AsdaInventory.mine_floor)
func _on_ba_pressed() -> void:
	AsdaInventory.add_mine_floor(10)
func _on_aa_pressed() -> void:
	AsdaInventory.add_mine_floor(1)
func _on_as_pressed() -> void:
	AsdaInventory.add_mine_floor(-1)
func _on_bs_pressed() -> void:
	AsdaInventory.add_mine_floor(-10)
func _on_reset_pressed() -> void:
	if AsasManager.location_prevent == 0:
		mine_tile_build()

func update1():
	AsdaInventory.add_mine_floor(1)
	mine_tile_build()
