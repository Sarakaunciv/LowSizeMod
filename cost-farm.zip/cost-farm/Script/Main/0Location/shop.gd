extends Node2D

var scene_id: int = AaaaGlobal.id_scene_shop

var buy_count: int = 0
var power_count: int = 0
var del0money: int = 0
func _ready() -> void:
	AsasManager.set_hold_item_id.connect(update0)
	update3()

func update0():
	match AsasManager.hold_item_id:
# plant ################################################################
		AaaaGlobal.id_karat:
			del0money = AaaaGlobal.id_karat_price
		AaaaGlobal.id_karat_seed:
			del0money = AaaaGlobal.id_karat_seed_price
		AaaaGlobal.id_tamaso:
			del0money = AaaaGlobal.id_tamaso_price
		AaaaGlobal.id_tamaso_seed:
			del0money = AaaaGlobal.id_tamaso_seed_price
		AaaaGlobal.id_patrak:
			del0money = AaaaGlobal.id_patrak_price
		AaaaGlobal.id_patrak_seed:
			del0money = AaaaGlobal.id_patrak_seed_price
		AaaaGlobal.id_apos:
			del0money = AaaaGlobal.id_apos_price
		AaaaGlobal.id_apos_seed:
			del0money = AaaaGlobal.id_apos_seed_price
		AaaaGlobal.id_whaat:
			del0money = AaaaGlobal.id_whaat_price
		AaaaGlobal.id_whaat_seed:
			del0money = AaaaGlobal.id_whaat_seed_price
		AaaaGlobal.id_garn:
			del0money = AaaaGlobal.id_garn_price
		AaaaGlobal.id_garn_seed:
			del0money = AaaaGlobal.id_garn_seed_price
		AaaaGlobal.id_graize_frizet:
			del0money = AaaaGlobal.id_graize_frizet_price
		AaaaGlobal.id_graize_frizet_seed:
			del0money = AaaaGlobal.id_graize_frizet_seed_price
		AaaaGlobal.id_yume_karst_faw:
			del0money = AaaaGlobal.id_yume_karst_faw_price
		AaaaGlobal.id_yume_karst_faw_seed:
			del0money = AaaaGlobal.id_yume_karst_faw_seed_price
# fert ################################################################
		AaaaGlobal.id_fert_speed_low:
			del0money = AaaaGlobal.id_fert_speed_low_price
		AaaaGlobal.id_fert_speed_mid:
			del0money = AaaaGlobal.id_fert_speed_mid_price
		AaaaGlobal.id_fert_speed_high:
			del0money = AaaaGlobal.id_fert_speed_high_price
		AaaaGlobal.id_fert_speed_max:
			del0money = AaaaGlobal.id_fert_speed_max_price
		AaaaGlobal.id_fert_size_low:
			del0money = AaaaGlobal.id_fert_size_low_price
		AaaaGlobal.id_fert_size_mid:
			del0money = AaaaGlobal.id_fert_size_mid_price
		AaaaGlobal.id_fert_size_high:
			del0money = AaaaGlobal.id_fert_size_high_price
		AaaaGlobal.id_fert_size_max:
			del0money = AaaaGlobal.id_fert_size_max_price
# ect ################################################################
		AaaaGlobal.id_shovel:
			del0money = AaaaGlobal.id_shovel_price
		AaaaGlobal.id_axe:
			del0money = AaaaGlobal.id_axe_price
		AaaaGlobal.id_wood:
			del0money = AaaaGlobal.id_wood_price
# fish ################################################################
		AaaaGlobal.id_bait:
			del0money = AaaaGlobal.id_bait_price
		AaaaGlobal.id_fish_rod:
			del0money = AaaaGlobal.id_fish_rod_price
		AaaaGlobal.id_crab_pot:
			del0money = AaaaGlobal.id_crab_pot_price
		AaaaGlobal.id_fish:
			del0money = AaaaGlobal.id_fish_price
		AaaaGlobal.id_crab:
			del0money = AaaaGlobal.id_crab_price
# mineral ################################################################
		AaaaGlobal.id_stone:
			del0money = AaaaGlobal.id_stone_price
		AaaaGlobal.id_cese:
			del0money = AaaaGlobal.id_cese_price
		AaaaGlobal.id_cese_pick:
			del0money = AaaaGlobal.id_cese_pick_price
		AaaaGlobal.id_cese_knife:
			del0money = AaaaGlobal.id_cese_knife_price
		AaaaGlobal.id_cese_shield:
			del0money = AaaaGlobal.id_cese_shield_price
		AaaaGlobal.id_lowaral:
			del0money = AaaaGlobal.id_lowaral_price
		AaaaGlobal.id_lowaral_pick:
			del0money = AaaaGlobal.id_lowaral_pick_price
		AaaaGlobal.id_lowaral_knife:
			del0money = AaaaGlobal.id_lowaral_knife_price
		AaaaGlobal.id_lowaral_shield:
			del0money = AaaaGlobal.id_lowaral_shield_price
		AaaaGlobal.id_iena:
			del0money = AaaaGlobal.id_iena_price
		AaaaGlobal.id_iena_pick:
			del0money = AaaaGlobal.id_iena_pick_price
		AaaaGlobal.id_iena_knife:
			del0money = AaaaGlobal.id_iena_knife_price
		AaaaGlobal.id_iena_shield:
			del0money = AaaaGlobal.id_iena_shield_price
		AaaaGlobal.id_midaral:
			del0money = AaaaGlobal.id_midaral_price
		AaaaGlobal.id_midaral_pick:
			del0money = AaaaGlobal.id_midaral_pick_price
		AaaaGlobal.id_midaral_knife:
			del0money = AaaaGlobal.id_midaral_knife_price
		AaaaGlobal.id_midaral_shield:
			del0money = AaaaGlobal.id_midaral_shield_price
		AaaaGlobal.id_graize:
			del0money = AaaaGlobal.id_graize_price
		AaaaGlobal.id_graize_pick:
			del0money = AaaaGlobal.id_graize_pick_price
		AaaaGlobal.id_graize_knife:
			del0money = AaaaGlobal.id_graize_knife_price
		AaaaGlobal.id_graize_shield:
			del0money = AaaaGlobal.id_graize_shield_price
		AaaaGlobal.id_higaral:
			del0money = AaaaGlobal.id_higaral_price
		AaaaGlobal.id_higaral_pick:
			del0money = AaaaGlobal.id_higaral_pick_price
		AaaaGlobal.id_higaral_knife:
			del0money = AaaaGlobal.id_higaral_knife_price
		AaaaGlobal.id_higaral_shield:
			del0money = AaaaGlobal.id_higaral_shield_price
		AaaaGlobal.id_adanto:
			del0money = AaaaGlobal.id_adanto_price
		AaaaGlobal.id_adanto_pick:
			del0money = AaaaGlobal.id_adanto_pick_price
		AaaaGlobal.id_adanto_knife:
			del0money = AaaaGlobal.id_adanto_knife_price
		AaaaGlobal.id_adanto_shield:
			del0money = AaaaGlobal.id_adanto_shield_price
		AaaaGlobal.id_maxaral:
			del0money = AaaaGlobal.id_maxaral_price
		AaaaGlobal.id_maxaral_pick:
			del0money = AaaaGlobal.id_maxaral_pick_price
		AaaaGlobal.id_maxaral_knife:
			del0money = AaaaGlobal.id_maxaral_knife_price
		AaaaGlobal.id_maxaral_shield:
			del0money = AaaaGlobal.id_maxaral_shield_price
# permit ################################################################
		AaaaGlobal.id_permit_farm:
			del0money = AaaaGlobal.id_permit_farm_price
		AaaaGlobal.id_permit_mine:
			del0money = AaaaGlobal.id_permit_mine_price
		AaaaGlobal.id_permit_wood:
			del0money = AaaaGlobal.id_permit_wood_price
		AaaaGlobal.id_permit_fish:
			del0money = AaaaGlobal.id_permit_fish_price
		AaaaGlobal.id_permit_crab:
			del0money = AaaaGlobal.id_permit_crab_price
	update1()

func update1():
#del0money *= buy_count
	money_low = 0
	money_mid = 0
	money_high = 0
	money_max = 0
	match power_count:
		0:
			add_money_low(del0money * buy_count)
		1:
			add_money_mid(del0money * buy_count)
		2:
			add_money_high(del0money * buy_count)
		3:
			add_money_max(del0money * buy_count)
	update2()

@onready var money_low_label: Label = $shop/money/money_low/Label
@onready var money_mid_label: Label = $shop/money/money_mid/Label
@onready var money_high_label: Label = $shop/money/money_high/Label
@onready var money_max_label: Label = $shop/money/money_max/Label
func update2():
	money_low_label.text = str(money_low)
	money_mid_label.text = str(money_mid)
	money_high_label.text = str(money_high)
	money_max_label.text = str(money_max)

@onready var count_label: Label = $shop/count/count/Label
func update3():
	update1()
	count_label.text = str(buy_count * (1000 ** power_count))
func update4():
	if buy_count > 999:
		buy_count -= 999
	elif buy_count < 1:
		buy_count += 999
	update3()
func _on_aa_pressed() -> void:
	buy_count += 1
	update4()
func _on_ba_pressed() -> void:
	buy_count += 10
	update4()
func _on_ca_pressed() -> void:
	buy_count += 100
	update4()
func _on_as_pressed() -> void:
	buy_count -= 1
	update4()
func _on_bs_pressed() -> void:
	buy_count -= 10
	update4()
func _on_cs_pressed() -> void:
	buy_count -= 100
	update4()

func update5():
	if power_count > 3:
		power_count = 3
	elif power_count < 0:
		power_count = 0
	update3()
func _on_ka_pressed() -> void:
	power_count += 1
	update5()
func _on_ks_pressed() -> void:
	power_count -= 1
	update5()

func _on_reset_pressed() -> void:
	buy_count = 0
	power_count = 0
	update3()

var money_low: int = 0
func add_money_low(money_low_count):
	money_low += money_low_count
	if money_low >= 1000:
		var del0 = money_low % 1000
		add_money_mid((money_low - del0) / 1000)
		money_low = del0
	elif money_low < 0:
		var del0 = (money_low * -1) % 1000
		add_money_mid((money_low + del0) / 1000 - 1)
		add_money_low(((money_low + del0) - 1000) * -1)
var money_mid: int = 0
func add_money_mid(money_mid_count):
	money_mid += money_mid_count
	if money_mid >= 1000:
		var del0 = money_mid % 1000
		add_money_high((money_mid - del0) / 1000)
		money_mid = del0
	elif money_mid < 0:
		var del0 = (money_mid * -1) % 1000
		add_money_high((money_mid + del0) / 1000 - 1)
		add_money_mid(((money_mid + del0) - 1000) * -1)
var money_high: int = 0
func add_money_high(money_high_count):
	money_high += money_high_count
	if money_high >= 1000:
		var del0 = money_high % 1000
		add_money_max((money_high - del0) / 1000)
		money_high = del0
	elif money_high < 0:
		var del0 = (money_high * -1) % 1000
		add_money_max((money_high + del0) / 1000 - 1)
		add_money_high(((money_high + del0) - 1000) * -1)
var money_max: int = 0
func add_money_max(money_max_count):
	money_max += money_max_count

var del_buy_count: int = 0
var del_power_count: int = 0
func save0():
	del_buy_count = buy_count
	del_power_count = power_count
func load0():
	buy_count = del_buy_count
	power_count = del_power_count

var del0count: int = 1
var del1count: float = 0.0
var del2count: int = 0
var del3count: int = 0
var is_trade_back: bool = false
var is_save: bool = false
func _on_buy_pressed() -> void:
	if is_trade_back == true:
		is_trade_back = false
		del0count = 1
		if is_save == false:
			is_save = true
			save0()
		buy_count = floor(del1count) * -1
		if buy_count >= 1000 ** 3:
			buy_count /= 1000 ** 3
			power_count = 3
		elif buy_count >= 1000 ** 2:
			buy_count /= 1000 ** 2
			power_count = 2
		elif buy_count >= 1000 ** 1:
			buy_count /= 1000 ** 1
			power_count = 1
		else:
			power_count = 0
		trade()
		await get_tree().process_frame
		is_save = false
		load0()
		update3()
	else:
		del0count = 1 * 2
		trade()
func _on_sell_pressed() -> void:
	del0count = -1
	trade()
func trade():
	del2count = del0money * buy_count * del0count * -1
	match power_count:
		0:
			AsdaInventory.add_money_low(del2count)
		1:
			AsdaInventory.add_money_mid(del2count)
		2:
			AsdaInventory.add_money_high(del2count)
		3:
			AsdaInventory.add_money_max(del2count)
	if del0count > 1:
		del0count = 1
	del3count = buy_count * (1000 ** power_count) * del0count
	match AsasManager.hold_item_id:
# plant ################################################################
		AaaaGlobal.id_karat:
			AsdaInventory.add_karat(del3count)
			del1count = AsdaInventory.karat
		AaaaGlobal.id_karat_seed:
			AsdaInventory.add_karat_seed(del3count)
			del1count = AsdaInventory.karat_seed
		AaaaGlobal.id_tamaso:
			AsdaInventory.add_tamaso(del3count)
			del1count = AsdaInventory.tamaso
		AaaaGlobal.id_tamaso_seed:
			AsdaInventory.add_tamaso_seed(del3count)
			del1count = AsdaInventory.tamaso_seed
		AaaaGlobal.id_patrak:
			AsdaInventory.add_patrak(del3count)
			del1count = AsdaInventory.patrak
		AaaaGlobal.id_patrak_seed:
			AsdaInventory.add_patrak_seed(del3count)
			del1count = AsdaInventory.patrak_seed
		AaaaGlobal.id_apos:
			AsdaInventory.add_apos(del3count)
			del1count = AsdaInventory.apos
		AaaaGlobal.id_apos_seed:
			AsdaInventory.add_apos_seed(del3count)
			del1count = AsdaInventory.apos_seed
		AaaaGlobal.id_whaat:
			AsdaInventory.add_whaat(del3count)
			del1count = AsdaInventory.whaat
		AaaaGlobal.id_whaat_seed:
			AsdaInventory.add_whaat_seed(del3count)
			del1count = AsdaInventory.whaat_seed
		AaaaGlobal.id_garn:
			AsdaInventory.add_garn(del3count)
			del1count = AsdaInventory.garn
		AaaaGlobal.id_garn_seed:
			AsdaInventory.add_garn_seed(del3count)
			del1count = AsdaInventory.garn_seed
		AaaaGlobal.id_graize_frizet:
			AsdaInventory.add_graize_frizet(del3count)
			del1count = AsdaInventory.graize_frizet
		AaaaGlobal.id_graize_frizet_seed:
			AsdaInventory.add_graize_frizet_seed(del3count)
			del1count = AsdaInventory.graize_frizet_seed
		AaaaGlobal.id_yume_karst_faw:
			AsdaInventory.add_yume_karst_faw(del3count)
			del1count = AsdaInventory.yume_karst_faw
		AaaaGlobal.id_yume_karst_faw_seed:
			AsdaInventory.add_yume_karst_faw_seed(del3count)
			del1count = AsdaInventory.yume_karst_faw_seed
# fert ################################################################
		AaaaGlobal.id_fert_speed_low:
			AsdaInventory.add_fert_speed_low(del3count)
			del1count = AsdaInventory.fert_speed_low
		AaaaGlobal.id_fert_speed_mid:
			AsdaInventory.add_fert_speed_mid(del3count)
			del1count = AsdaInventory.fert_speed_mid
		AaaaGlobal.id_fert_speed_high:
			AsdaInventory.add_fert_speed_high(del3count)
			del1count = AsdaInventory.fert_speed_high
		AaaaGlobal.id_fert_speed_max:
			AsdaInventory.add_fert_speed_max(del3count)
			del1count = AsdaInventory.fert_speed_max
		AaaaGlobal.id_fert_size_low:
			AsdaInventory.add_fert_size_low(del3count)
			del1count = AsdaInventory.fert_size_low
		AaaaGlobal.id_fert_size_mid:
			AsdaInventory.add_fert_size_mid(del3count)
			del1count = AsdaInventory.fert_size_mid
		AaaaGlobal.id_fert_size_high:
			AsdaInventory.add_fert_size_high(del3count)
			del1count = AsdaInventory.fert_size_high
		AaaaGlobal.id_fert_size_max:
			AsdaInventory.add_fert_size_max(del3count)
			del1count = AsdaInventory.fert_size_max
# ect ################################################################
		AaaaGlobal.id_shovel:
			AsdaInventory.add_shovel(del3count)
			del1count = AsdaInventory.shovel
		AaaaGlobal.id_axe:
			AsdaInventory.add_axe(del3count)
			del1count = AsdaInventory.axe
		AaaaGlobal.id_wood:
			AsdaInventory.add_wood(del3count)
			del1count = AsdaInventory.wood
# fish ################################################################
		AaaaGlobal.id_bait:
			AsdaInventory.add_bait(del3count)
			del1count = AsdaInventory.bait
		AaaaGlobal.id_fish_rod:
			AsdaInventory.add_fish_rod(del3count)
			del1count = AsdaInventory.fish_rod
		AaaaGlobal.id_crab_pot:
			AsdaInventory.add_crab_pot(del3count)
			del1count = AsdaInventory.crab_pot
		AaaaGlobal.id_fish:
			AsdaInventory.add_fish(del3count)
			del1count = AsdaInventory.fish
		AaaaGlobal.id_crab:
			AsdaInventory.add_crab(del3count)
			del1count = AsdaInventory.crab
# mineral ################################################################
		AaaaGlobal.id_stone:
			AsdaInventory.add_stone(del3count)
			del1count = AsdaInventory.stone
		AaaaGlobal.id_cese:
			AsdaInventory.add_cese(del3count)
			del1count = AsdaInventory.cese
		AaaaGlobal.id_cese_pick:
			AsdaInventory.add_cese_pick(del3count)
			del1count = AsdaInventory.cese_pick
		AaaaGlobal.id_cese_knife:
			AsdaInventory.add_cese_knife(del3count)
			del1count = AsdaInventory.cese_knife
		AaaaGlobal.id_cese_shield:
			AsdaInventory.add_cese_shield(del3count)
			del1count = AsdaInventory.cese_shield
		AaaaGlobal.id_lowaral:
			AsdaInventory.add_lowaral(del3count)
			del1count = AsdaInventory.lowaral
		AaaaGlobal.id_lowaral_pick:
			AsdaInventory.add_lowaral_pick(del3count)
			del1count = AsdaInventory.lowaral_pick
		AaaaGlobal.id_lowaral_knife:
			AsdaInventory.add_lowaral_knife(del3count)
			del1count = AsdaInventory.lowaral_knife
		AaaaGlobal.id_lowaral_shield:
			AsdaInventory.add_lowaral_shield(del3count)
			del1count = AsdaInventory.lowaral_shield
		AaaaGlobal.id_iena:
			AsdaInventory.add_iena(del3count)
			del1count = AsdaInventory.iena
		AaaaGlobal.id_iena_pick:
			AsdaInventory.add_iena_pick(del3count)
			del1count = AsdaInventory.iena_pick
		AaaaGlobal.id_iena_knife:
			AsdaInventory.add_iena_knife(del3count)
			del1count = AsdaInventory.iena_knife
		AaaaGlobal.id_iena_shield:
			AsdaInventory.add_iena_shield(del3count)
			del1count = AsdaInventory.iena_shield
		AaaaGlobal.id_midaral:
			AsdaInventory.add_midaral(del3count)
			del1count = AsdaInventory.midaral
		AaaaGlobal.id_midaral_pick:
			AsdaInventory.add_midaral_pick(del3count)
			del1count = AsdaInventory.midaral_pick
		AaaaGlobal.id_midaral_knife:
			AsdaInventory.add_midaral_knife(del3count)
			del1count = AsdaInventory.midaral_knife
		AaaaGlobal.id_midaral_shield:
			AsdaInventory.add_midaral_shield(del3count)
			del1count = AsdaInventory.midaral_shield
		AaaaGlobal.id_graize:
			AsdaInventory.add_graize(del3count)
			del1count = AsdaInventory.graize
		AaaaGlobal.id_graize_pick:
			AsdaInventory.add_graize_pick(del3count)
			del1count = AsdaInventory.graize_pick
		AaaaGlobal.id_graize_knife:
			AsdaInventory.add_graize_knife(del3count)
			del1count = AsdaInventory.graize_knife
		AaaaGlobal.id_graize_shield:
			AsdaInventory.add_graize_shield(del3count)
			del1count = AsdaInventory.graize_shield
		AaaaGlobal.id_higaral:
			AsdaInventory.add_higaral(del3count)
			del1count = AsdaInventory.higaral
		AaaaGlobal.id_higaral_pick:
			AsdaInventory.add_higaral_pick(del3count)
			del1count = AsdaInventory.higaral_pick
		AaaaGlobal.id_higaral_knife:
			AsdaInventory.add_higaral_knife(del3count)
			del1count = AsdaInventory.higaral_knife
		AaaaGlobal.id_higaral_shield:
			AsdaInventory.add_higaral_shield(del3count)
			del1count = AsdaInventory.higaral_shield
		AaaaGlobal.id_adanto:
			AsdaInventory.add_adanto(del3count)
			del1count = AsdaInventory.adanto
		AaaaGlobal.id_adanto_pick:
			AsdaInventory.add_adanto_pick(del3count)
			del1count = AsdaInventory.adanto_pick
		AaaaGlobal.id_adanto_knife:
			AsdaInventory.add_adanto_knife(del3count)
			del1count = AsdaInventory.adanto_knife
		AaaaGlobal.id_adanto_shield:
			AsdaInventory.add_adanto_shield(del3count)
			del1count = AsdaInventory.adanto_shield
		AaaaGlobal.id_maxaral:
			AsdaInventory.add_maxaral(del3count)
			del1count = AsdaInventory.maxaral
		AaaaGlobal.id_maxaral_pick:
			AsdaInventory.add_maxaral_pick(del3count)
			del1count = AsdaInventory.maxaral_pick
		AaaaGlobal.id_maxaral_knife:
			AsdaInventory.add_maxaral_knife(del3count)
			del1count = AsdaInventory.maxaral_knife
		AaaaGlobal.id_maxaral_shield:
			AsdaInventory.add_maxaral_shield(del3count)
			del1count = AsdaInventory.maxaral_shield
# permit ################################################################
		AaaaGlobal.id_permit_farm:
			AsdaInventory.add_permit_farm(del3count)
			del1count = AsdaInventory.permit_farm
			if FileAccess.file_exists("res://Scene/SaveScene/farm.tres"):
				var del0 = DirAccess.open("res://Scene/SaveScene/")
				del0.remove("farm.tres")
		AaaaGlobal.id_permit_mine:
			AsdaInventory.add_permit_mine(del3count)
			del1count = AsdaInventory.permit_mine
		AaaaGlobal.id_permit_wood:
			AsdaInventory.add_permit_wood(del3count)
			del1count = AsdaInventory.permit_wood
		AaaaGlobal.id_permit_fish:
			AsdaInventory.add_permit_fish(del3count)
			del1count = AsdaInventory.permit_fish
		AaaaGlobal.id_permit_crab:
			AsdaInventory.add_permit_crab(del3count)
			del1count = AsdaInventory.permit_crab
			if FileAccess.file_exists("res://Scene/SaveScene/river.tres"):
				var del0 = DirAccess.open("res://Scene/SaveScene/")
				del0.remove("river.tres")
	if del1count < 0:
		is_trade_back = true
		_on_buy_pressed()
