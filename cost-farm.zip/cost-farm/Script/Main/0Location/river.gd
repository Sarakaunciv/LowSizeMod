extends Node2D

@onready var ready_delay: Timer = $ready_delay

var scene_id: int = AaaaGlobal.id_scene_river
func _ready() -> void:
	AsdaInventory.set_fish.connect(fish_reset)
	ready_delay.timeout.connect(ready0)
	ready_delay.wait_time = 0.1
	ready_delay.one_shot = true
	ready_delay.start()
	update0()
	fish.focus_mode = Control.FOCUS_NONE
	fish.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

func ready0():
	river_tile_build()

@onready var river_tile_0: Node2D = $river_tile_0
@onready var permit: ColorRect = $permit
var river_tile = load("res://Script/Main/river/river_tile.tscn")
func river_tile_build():
	if AsdaInventory.permit_crab != 0:
		if FileAccess.file_exists("res://Scene/SaveScene/river.tres"):
			var data = ResourceLoader.load("res://Scene/SaveScene/river.tres") as zzzz_resource
			for del0 in data.river_tile_0:
				var del0tile = del0.instantiate()
				river_tile_0.call_deferred("add_child", del0tile)
				del0tile._ready()
		else:
			for del0x in range(20):
				for del0y in range(10):
					var del0tile = river_tile.instantiate()
					if del0x % 2 == del0y % 2:
						del0tile.is_dark = false
					else:
						del0tile.is_dark = true
					del0tile.current_day = AsdaInventory.time_day
					river_tile_0.call_deferred("add_child", del0tile)
					del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)
	else:
		permit.visible = true

@onready var fish: Button = $fish
func update0():
	if AsdaInventory.permit_fish != 0:
		fish.visible = true

@onready var fish_fish: Node2D = $fish_fish
var fish_fish_fish = load("res://Script/Main/River/fish_fish_fish.tscn")
var is_fish_fish: bool = false
func _on_fish_pressed() -> void:
	if AsdaInventory.fish_rod != 0 and is_fish_fish == false:
		AsdaInventory.add_time_min(randi_range(10, 60))
		is_fish_fish = true
		var del0 = fish_fish_fish.instantiate()
		fish_fish.call_deferred("add_child", del0)

func fish_reset():
	is_fish_fish = false
