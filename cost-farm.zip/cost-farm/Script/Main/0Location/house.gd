extends Node2D

var scene_id: int = AaaaGlobal.id_scene_house

func _ready() -> void:
	update0()
@onready var time_sleep_label: Label = $button/sleep/ColorRect/time_sleep_label

var time_sleep: int = 0
func update0():
	if time_sleep < 0:
		time_sleep = 0
	time_sleep_label.text = str(time_sleep / 60, ":")
	if time_sleep < 10:
		time_sleep_label.text += str(0)
	time_sleep_label.text += str(time_sleep % 60)

func _on_sleep_pressed() -> void:
	AsdaInventory.add_is_sleep(true)
	AsdaInventory.add_time_min(time_sleep)

func _on_aa_pressed() -> void:
	time_sleep += 5
	update0()
func _on_ba_pressed() -> void:
	time_sleep += 30
	update0()
func _on_ca_pressed() -> void:
	time_sleep += 180
	update0()

func _on_as_pressed() -> void:
	time_sleep -= 5
	update0()
func _on_bs_pressed() -> void:
	time_sleep -= 30
	update0()
func _on_cs_pressed() -> void:
	time_sleep -= 180
	update0()
