extends Node2D

@export var is_dark: bool = false
@export var is_hoe: bool = false

@onready var button: Button = $Button
func _ready() -> void:
	if !AsasManager.set_day.is_connected(grow0):
		AsasManager.set_day.connect(grow0)
	update0()
	update1()
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

@onready var dirt: Sprite2D = $dirt
func update0():
	dirt.region_rect.position = AaaaGlobal.atlas_dirt
	if is_dark == true:
		dirt.region_rect.position = AaaaGlobal.atlas_dirt_dark
@onready var hoe_dirt: Sprite2D = $dirt/hoe_dirt
func update1():
	if is_hoe == true:
		hoe_dirt.visible = true

func _on_button_mouse_entered() -> void:
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_pressed() -> void:
	if is_hoe == false:
		hoe0()
	elif is_occupy == false and AsasManager.hold_item_id in seed_pool:
		plant_plant0()
	elif is_occupy == true:
		harvest0()
func hoe0():
	is_hoe = true
	update1()

var seed_pool = [AaaaGlobal.id_karat_seed, AaaaGlobal.id_tamaso_seed]
@export var is_occupy: bool = false
func plant_plant0():
	match AsasManager.hold_item_id:
		AaaaGlobal.id_karat_seed:
			if AsdaInventory.karat_seed >= 1:
				AsdaInventory.add_karat_seed(-1)
				plant_id = AaaaGlobal.id_karat
			else:
				return
		AaaaGlobal.id_tamaso_seed:
			if AsdaInventory.tamaso_seed >= 1:
				AsdaInventory.add_tamaso_seed(-1)
				plant_id = AaaaGlobal.id_tamaso
			else:
				return
	is_occupy = true
	ready0()

func kill_plant():
	is_occupy = false
	
	plant.visible = false
	plant_id = 0
	plant_age = 0
	is_multi_harvest = false
	fertilizer_speed = 1.0

# plant
@export var plant_id: int = 0
@export var plant_age: int = 0
var multi_harvest_plant = [AaaaGlobal.id_tamaso]
@export var is_multi_harvest: bool = false

@export var fertilizer_speed: float = 1.0

func ready0() -> void:
	if plant_id in multi_harvest_plant:
		is_multi_harvest = true
	
	update2()

@onready var plant: Sprite2D = $dirt/hoe_dirt/plant
@export var plant_sprite_main_pos: Vector2 = Vector2()
func update2():
	plant.visible = true
	match plant_id:
		AaaaGlobal.id_karat:
			plant.region_rect.position = AaaaGlobal.atlas_karat_plant
		AaaaGlobal.id_tamaso:
			plant.region_rect.position = AaaaGlobal.atlas_tamaso_plant
	plant_sprite_main_pos = plant.region_rect.position
func update3():
	if plant_age >= 1200 and is_multi_harvest == true:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_5
	elif plant_age >= 1000:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_4
	elif plant_age >= 700:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_3
	elif plant_age >= 400:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_2
	elif plant_age >= 100:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_1

func grow0(del0):
	if is_occupy == true:
		match plant_id:
			AaaaGlobal.id_karat:
				plant_age += AaaaGlobal.karat_grow_speed * fertilizer_speed
			AaaaGlobal.id_tamaso:
				plant_age += AaaaGlobal.tamaso_grow_speed * fertilizer_speed
		update3()

func harvest0():
	if is_multi_harvest == true:
		if plant_age >= 1200:
			plant_age -= 1000
			harvest1()
			plant_age = 1000
			update3()
	else:
		if plant_age >= 1000:
			harvest1()
			kill_plant()
func harvest1():
	match plant_id:
		AaaaGlobal.id_karat:
			AsdaInventory.add_karat(plant_age)
		AaaaGlobal.id_tamaso:
			AsdaInventory.add_tamaso(plant_age)
