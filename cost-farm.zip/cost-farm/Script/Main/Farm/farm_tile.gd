extends Node2D

@export var is_dark: bool = false
@export var is_hoe: bool = false

@onready var fertilizer: Node2D = $dirt/hoe_dirt/fertilizer
@onready var button: Button = $Button
@export var current_day: int = 0
func _ready() -> void:
	update0()
	update1()
	update5()
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS
	fertilizer.z_index = 8

@onready var dirt: Sprite2D = $dirt
func update0():
	dirt.region_rect.position = AaaaGlobal.atlas_dirt
	if is_dark == true:
		dirt.region_rect.position = AaaaGlobal.atlas_dirt_dark
@onready var hoe_dirt: Sprite2D = $dirt/hoe_dirt
func update1():
	if is_hoe == true:
		hoe_dirt.visible = true

@onready var edge_hover: Sprite2D = $edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false

var seed_pool = [AaaaGlobal.id_karat_seed, AaaaGlobal.id_tamaso_seed]
var fert_speed_pool = [AaaaGlobal.id_fert_speed_low, AaaaGlobal.id_fert_speed_mid, AaaaGlobal.id_fert_speed_high, AaaaGlobal.id_fert_speed_max]
var fert_size_pool = [AaaaGlobal.id_fert_size_low, AaaaGlobal.id_fert_size_mid, AaaaGlobal.id_fert_size_high, AaaaGlobal.id_fert_size_max]
@export var is_occupy: bool = false
func _on_button_pressed() -> void:
	if is_hoe == false:
		hoe0()
	elif is_occupy == false:
		if AsasManager.hold_item_id in seed_pool:
			plant_plant0()
		elif AsasManager.hold_item_id in fert_speed_pool or AsasManager.hold_item_id in fert_size_pool:
			plant_fert0()
	elif is_occupy == true:
		if AsasManager.hold_item_id in fert_speed_pool:
			plant_fert0()
		else:
			harvest0()
func hoe0():
	is_hoe = true
	update1()

func plant_fert0():
	match AsasManager.hold_item_id:
		AaaaGlobal.id_fert_speed_low:
			if fertilizer_speed < AaaaGlobal.fert_speed_low_value and AsdaInventory.fert_speed_low >= 1:
				fertilizer_speed = AaaaGlobal.fert_speed_low_value
				AsdaInventory.add_fert_speed_low(-1)
		AaaaGlobal.id_fert_speed_mid:
			if fertilizer_speed < AaaaGlobal.fert_speed_mid_value and AsdaInventory.fert_speed_mid >= 1:
				fertilizer_speed = AaaaGlobal.fert_speed_mid_value
				AsdaInventory.add_fert_speed_mid(-1)
		AaaaGlobal.id_fert_speed_high:
			if fertilizer_speed < AaaaGlobal.fert_speed_high_value and AsdaInventory.fert_speed_high >= 1:
				fertilizer_speed = AaaaGlobal.fert_speed_high_value
				AsdaInventory.add_fert_speed_high(-1)
		AaaaGlobal.id_fert_speed_max:
			if fertilizer_speed < AaaaGlobal.fert_speed_max_value and AsdaInventory.fert_speed_max >= 1:
				fertilizer_speed = AaaaGlobal.fert_speed_max_value
				AsdaInventory.add_fert_speed_max(-1)
		AaaaGlobal.id_fert_size_low:
			if fertilizer_size < AaaaGlobal.fert_size_low_value and AsdaInventory.fert_size_low >= 1:
				fertilizer_size = AaaaGlobal.fert_size_low_value
				AsdaInventory.add_fert_size_low(-1)
		AaaaGlobal.id_fert_size_mid:
			if fertilizer_size < AaaaGlobal.fert_size_mid_value and AsdaInventory.fert_size_mid >= 1:
				fertilizer_size = AaaaGlobal.fert_size_mid_value
				AsdaInventory.add_fert_size_mid(-1)
		AaaaGlobal.id_fert_size_high:
			if fertilizer_size < AaaaGlobal.fert_size_high_value and AsdaInventory.fert_size_high >= 1:
				fertilizer_size = AaaaGlobal.fert_size_high_value
				AsdaInventory.add_fert_size_high(-1)
		AaaaGlobal.id_fert_size_max:
			if fertilizer_size < AaaaGlobal.fert_size_max_value and AsdaInventory.fert_size_max >= 1:
				fertilizer_size = AaaaGlobal.fert_size_max_value
				AsdaInventory.add_fert_size_max(-1)
	update4()
func kill_fert():
	fertilizer_speed = 1.0
	fertilizer_size = 1.0

@onready var speed: Sprite2D = $dirt/hoe_dirt/fertilizer/speed
@onready var size: Sprite2D = $dirt/hoe_dirt/fertilizer/size
func update4():
	if fertilizer_speed != 1.0:
		speed.visible = true
		match fertilizer_speed:
			AaaaGlobal.fert_speed_low_value:
				speed.region_rect.position = AaaaGlobal.atlas_fert_low_inv
			AaaaGlobal.fert_speed_mid_value:
				speed.region_rect.position = AaaaGlobal.atlas_fert_mid_inv
			AaaaGlobal.fert_speed_high_value:
				speed.region_rect.position = AaaaGlobal.atlas_fert_high_inv
			AaaaGlobal.fert_speed_max_value:
				speed.region_rect.position = AaaaGlobal.atlas_fert_max_inv
	else:
		speed.visible = false
	if fertilizer_size != 1.0:
		size.visible = true
		match fertilizer_size:
			AaaaGlobal.fert_size_low_value:
				size.region_rect.position = AaaaGlobal.atlas_fert_low_inv
			AaaaGlobal.fert_size_mid_value:
				size.region_rect.position = AaaaGlobal.atlas_fert_mid_inv
			AaaaGlobal.fert_size_high_value:
				size.region_rect.position = AaaaGlobal.atlas_fert_high_inv
			AaaaGlobal.fert_size_max_value:
				size.region_rect.position = AaaaGlobal.atlas_fert_max_inv
	else:
		size.visible = false

func plant_plant0():
	match AsasManager.hold_item_id:
		AaaaGlobal.id_karat_seed:
			if AsdaInventory.karat_seed >= 1:
				AsdaInventory.add_karat_seed(-1)
				plant_id = AaaaGlobal.id_karat
			else:
				return
		AaaaGlobal.id_tamaso_seed:
			if AsdaInventory.tamaso_seed >= 1:
				AsdaInventory.add_tamaso_seed(-1)
				plant_id = AaaaGlobal.id_tamaso
			else:
				return
	is_occupy = true
	update2()
func kill_plant():
	is_occupy = false
	
	plant.visible = false
	plant_id = 0
	plant_age = 0
	is_multi_harvest = false

# plant
@onready var plant: Sprite2D = $dirt/hoe_dirt/plant

@export var plant_id: int = 0
@export var plant_age: int = 0
var multi_harvest_plant = [AaaaGlobal.id_tamaso]
@export var is_multi_harvest: bool = false

@export var fertilizer_speed: float = 1.0
@export var fertilizer_size: float = 1.0

@export var plant_sprite_main_pos: Vector2 = Vector2()
func update2():
	if plant_id in multi_harvest_plant:
		is_multi_harvest = true
	plant.visible = true
	match plant_id:
		AaaaGlobal.id_karat:
			plant.region_rect.position = AaaaGlobal.atlas_karat_plant
		AaaaGlobal.id_tamaso:
			plant.region_rect.position = AaaaGlobal.atlas_tamaso_plant
	plant_sprite_main_pos = plant.region_rect.position
func update3():
	if plant_age >= 1200 and is_multi_harvest == true:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_5
	elif plant_age >= 1000:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_4
	elif plant_age >= 700:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_3
	elif plant_age >= 400:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_2
	elif plant_age >= 100:
		plant.region_rect.position = plant_sprite_main_pos + AaaaGlobal.atlas_plant_s_1

func update5():
	if current_day < AsdaInventory.time_day:
		for del0 in range(AsdaInventory.time_day - current_day):
			grow0()
func grow0():
	current_day += 1
	if is_occupy == true:
		match plant_id:
			AaaaGlobal.id_karat:
				plant_age += AaaaGlobal.karat_grow_speed * fertilizer_speed
			AaaaGlobal.id_tamaso:
				plant_age += AaaaGlobal.tamaso_grow_speed * fertilizer_speed
		update3()

var del0count: float = 0.0
func harvest0():
	if is_multi_harvest == true:
		if plant_age >= 1200:
			plant_age -= 1000
			harvest1()
			plant_age = 1000
			update3()
	else:
		if plant_age >= 1000:
			harvest1()
			kill_plant()
func harvest1():
	del0count = plant_age * fertilizer_size / 1000
	match plant_id:
		AaaaGlobal.id_karat:
			AsdaInventory.add_karat(del0count)
		AaaaGlobal.id_tamaso:
			AsdaInventory.add_tamaso(del0count)
