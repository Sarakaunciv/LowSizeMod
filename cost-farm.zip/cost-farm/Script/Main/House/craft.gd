extends Button

func _on_pressed() -> void:
	match AsasManager.hold_item_id:
# plant ################################################################
# fert ################################################################
# ect ################################################################
		AaaaGlobal.id_shovel:
			if AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0 and AsdaInventory.stone >= 4:
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_stone(-1 * 8)
				AsdaInventory.add_shovel(1)
		AaaaGlobal.id_axe:
			if AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0 and AsdaInventory.stone >= 18:
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_stone(-1 * 18)
				AsdaInventory.add_axe(1)
# fish ################################################################
		AaaaGlobal.id_bait:
			if AsdaInventory.fish >= 1:
				AsdaInventory.add_fish(-1 * 1)
				AsdaInventory.add_bait(6)
		AaaaGlobal.id_fish_rod:
			if AsdaInventory.wood >= 18:
				AsdaInventory.add_wood(-1 * 18)
				AsdaInventory.add_fish_rod(1)
		AaaaGlobal.id_crab_pot:
			if AsdaInventory.wood >= 15 and AsdaInventory.bait >= 10:
				AsdaInventory.add_wood(-1 * 15)
				AsdaInventory.add_bait(-1 * 10)
				AsdaInventory.add_crab_pot(1)
# mineral ################################################################
		AaaaGlobal.id_cese_pick:
			if AsdaInventory.cese >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_cese(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_cese_pick(1)
		AaaaGlobal.id_cese_knife:
			if AsdaInventory.cese >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_cese(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_cese_knife(1)
		AaaaGlobal.id_cese_shield:
			if AsdaInventory.cese >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_cese(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_cese_shield(1)
		AaaaGlobal.id_lowaral_pick:
			if AsdaInventory.lowaral >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_lowaral(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_lowaral_pick(1)
		AaaaGlobal.id_lowaral_knife:
			if AsdaInventory.lowaral >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_lowaral(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_lowaral_knife(1)
		AaaaGlobal.id_lowaral_shield:
			if AsdaInventory.lowaral >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_lowaral(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_lowaral_shield(1)
		AaaaGlobal.id_iena_pick:
			if AsdaInventory.iena >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_iena(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_iena_pick(1)
		AaaaGlobal.id_iena_knife:
			if AsdaInventory.iena >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_iena(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_iena_knife(1)
		AaaaGlobal.id_iena_shield:
			if AsdaInventory.iena >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_iena(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_iena_shield(1)
		AaaaGlobal.id_midaral_pick:
			if AsdaInventory.midaral >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_midaral(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_midaral_pick(1)
		AaaaGlobal.id_midaral_knife:
			if AsdaInventory.midaral >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_midaral(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_midaral_knife(1)
		AaaaGlobal.id_midaral_shield:
			if AsdaInventory.midaral >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_midaral(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_midaral_shield(1)
		AaaaGlobal.id_graize_pick:
			if AsdaInventory.graize >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_graize(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_graize_pick(1)
		AaaaGlobal.id_graize_knife:
			if AsdaInventory.graize >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_graize(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_graize_knife(1)
		AaaaGlobal.id_graize_shield:
			if AsdaInventory.graize >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_graize(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_graize_shield(1)
		AaaaGlobal.id_higaral_pick:
			if AsdaInventory.higaral >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_higaral(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_higaral_pick(1)
		AaaaGlobal.id_higaral_knife:
			if AsdaInventory.higaral >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_higaral(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_higaral_knife(1)
		AaaaGlobal.id_higaral_shield:
			if AsdaInventory.higaral >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_higaral(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_higaral_shield(1)
		AaaaGlobal.id_adanto_pick:
			if AsdaInventory.adanto >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_adanto(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_adanto_pick(1)
		AaaaGlobal.id_adanto_knife:
			if AsdaInventory.adanto >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_adanto(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_adanto_knife(1)
		AaaaGlobal.id_adanto_shield:
			if AsdaInventory.adanto >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_adanto(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_adanto_shield(1)
		AaaaGlobal.id_maxaral_pick:
			if AsdaInventory.maxaral >= AaaaGlobal.recipe_pick_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count0:
				AsdaInventory.add_maxaral(-1 * AaaaGlobal.recipe_pick_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count0)
				AsdaInventory.add_maxaral_pick(1)
		AaaaGlobal.id_maxaral_knife:
			if AsdaInventory.maxaral >= AaaaGlobal.recipe_knife_count and AsdaInventory.wood >= AaaaGlobal.recipe_wood_count1:
				AsdaInventory.add_maxaral(-1 * AaaaGlobal.recipe_knife_count)
				AsdaInventory.add_wood(-1 * AaaaGlobal.recipe_wood_count1)
				AsdaInventory.add_maxaral_knife(1)
		AaaaGlobal.id_maxaral_shield:
			if AsdaInventory.maxaral >= AaaaGlobal.recipe_shield_count:
				AsdaInventory.add_maxaral(-1 * AaaaGlobal.recipe_shield_count)
				AsdaInventory.add_maxaral_shield(1)
