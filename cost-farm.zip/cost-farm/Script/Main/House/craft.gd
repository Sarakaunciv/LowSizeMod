extends Button

func _on_pressed() -> void:
	match AsasManager.hold_item_id:
		AaaaGlobal.id_bait:
			if AsdaInventory.fish >= 1:
				AsdaInventory.add_fish(-1)
				AsdaInventory.add_bait(4)
