extends Node2D

@onready var button: Button = $Button
@onready var timer: Timer = $Timer
var mine
var health_bar

var stone_id: int = 0
var hp_max: int = 1
var hp_left: int = 1
var dmg_reduction: int = 1
var dig_power: int = 1
func _ready() -> void:
	timer.wait_time = 0.1
	timer.timeout.connect(dig0)
	mine = get_node("../..")
	health_bar = get_node("health_bar")
	update0()
	dig_power = mine.pickaxe_power * (mine.attack_multiplier / dmg_reduction)
	#print(pickaxe_power)
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

func update0():
	if AsdaInventory.mine_floor - 24 >= randi_range(1, 100):
		stone_id = 8
	elif AsdaInventory.mine_floor - 16 >= randi_range(1, 100):
		stone_id = 7
	elif AsdaInventory.mine_floor - 12 >= randi_range(1, 100):
		stone_id = 6
	elif AsdaInventory.mine_floor - 8 >= randi_range(1, 100):
		stone_id = 5
	elif AsdaInventory.mine_floor - 4 >= randi_range(1, 100):
		stone_id = 4
	elif AsdaInventory.mine_floor + 2 >= randi_range(1, 100):
		stone_id = 3
	elif AsdaInventory.mine_floor + 12 >= randi_range(1, 100):
		stone_id = 2
	elif AsdaInventory.mine_floor + 30 >= randi_range(1, 100):
		stone_id = 1
	update1()
@onready var stone: Sprite2D = $stone
func update1():
	match stone_id:
		1:
			stone.region_rect.position = AaaaGlobal.atlas_cese_stone
			hp_max = 40 ** 0.5
			dmg_reduction = 25 ** 0.5
		2:
			stone.region_rect.position = AaaaGlobal.atlas_lowaral_stone
			hp_max = 40 ** 1
			dmg_reduction = 25 ** 1
		3:
			stone.region_rect.position = AaaaGlobal.atlas_iena_stone
			hp_max = 40 ** 1.5
			dmg_reduction = 25 ** 1.5
		4:
			stone.region_rect.position = AaaaGlobal.atlas_midaral_stone
			hp_max = 40 ** 2
			dmg_reduction = 25 ** 2
		5:
			stone.region_rect.position = AaaaGlobal.atlas_graize_stone
			hp_max = 40 ** 2.5
			dmg_reduction = 25 ** 2.5
		6:
			stone.region_rect.position = AaaaGlobal.atlas_higaral_stone
			hp_max = 40 ** 3
			dmg_reduction = 25 ** 3
		7:
			stone.region_rect.position = AaaaGlobal.atlas_adanto_stone
			hp_max = 40 ** 3.5
			dmg_reduction = 25 ** 3.5
		8:
			stone.region_rect.position = AaaaGlobal.atlas_maxaral_stone
			hp_max = 40 ** 4
			dmg_reduction = 25 ** 4
	hp_max *= 100
	hp_left = hp_max

@onready var edge_hover: Sprite2D = $edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
	timer.stop()

func _on_button_pressed() -> void:
	dig0()
	timer.start()

func dig0():
	hp_left -= dig_power
	if hp_left <= 0:
		break0()
	health_bar.update_health_bar()

func break0():
	match stone_id:
		0:
			AsdaInventory.add_money_low(1)
		1:
			AsdaInventory.add_cese(1)
		2:
			AsdaInventory.add_lowaral(1)
		3:
			AsdaInventory.add_iena(1)
		4:
			AsdaInventory.add_midaral(1)
		5:
			AsdaInventory.add_graize(1)
		6:
			AsdaInventory.add_higaral(1)
		7:
			AsdaInventory.add_adanto(1)
		8:
			AsdaInventory.add_maxaral(1)
	queue_free()
