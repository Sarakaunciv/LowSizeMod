extends Node2D

@onready var button: Button = $Button
@onready var auto_dig_timer: Timer = $auto_dig_timer
var mine
var health_bar

var stone_id: int = 0
var hp_max: int = 1
var hp_left: int = 1
var dmg_reduction: int = 1
var pickaxe_power: int = 1
var knife_power: int = 1
func _ready() -> void:
	auto_dig_timer.wait_time = 0.1
	auto_dig_timer.timeout.connect(dig0)
	mine = get_node("../..")
	health_bar = get_node("health_bar")
	update0()
	pickaxe_power = mine.pickaxe_power * (mine.pickaxe_multiplier / dmg_reduction)
	knife_power = mine.knife_power * (mine.knife_multiplier / dmg_reduction)
	button.focus_mode = Control.FOCUS_NONE
	button.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS

func update0():
	if AsdaInventory.mine_floor - 100 >= randi_range(1, 100):
		stone_id = 8
	elif AsdaInventory.mine_floor - 80 >= randi_range(1, 100):
		stone_id = 7
	elif AsdaInventory.mine_floor - 60 >= randi_range(1, 100):
		stone_id = 6
	elif AsdaInventory.mine_floor - 40 >= randi_range(1, 100):
		stone_id = 5
	elif AsdaInventory.mine_floor - 20 >= randi_range(1, 100):
		stone_id = 4
	elif AsdaInventory.mine_floor + 0 >= randi_range(1, 100):
		stone_id = 3
	elif AsdaInventory.mine_floor + 20 >= randi_range(1, 100):
		stone_id = 2
	elif AsdaInventory.mine_floor + 40 >= randi_range(1, 100):
		stone_id = 1
	update1()
@onready var stone: Sprite2D = $stone
func update1():
	match stone_id:
		1:
			stone.region_rect.position = AaaaGlobal.atlas_cese_stone
			hp_max = 40 ** 0.5
			dmg_reduction = 25 ** 0.5
		2:
			stone.region_rect.position = AaaaGlobal.atlas_lowaral_stone
			hp_max = 40 ** 1
			dmg_reduction = 25 ** 1
		3:
			stone.region_rect.position = AaaaGlobal.atlas_iena_stone
			hp_max = 40 ** 1.5
			dmg_reduction = 25 ** 1.5
		4:
			stone.region_rect.position = AaaaGlobal.atlas_midaral_stone
			hp_max = 40 ** 2
			dmg_reduction = 25 ** 2
		5:
			stone.region_rect.position = AaaaGlobal.atlas_graize_stone
			hp_max = 40 ** 2.5
			dmg_reduction = 25 ** 2.5
		6:
			stone.region_rect.position = AaaaGlobal.atlas_higaral_stone
			hp_max = 40 ** 3
			dmg_reduction = 25 ** 3
		7:
			stone.region_rect.position = AaaaGlobal.atlas_adanto_stone
			hp_max = 40 ** 3.5
			dmg_reduction = 25 ** 3.5
		8:
			stone.region_rect.position = AaaaGlobal.atlas_maxaral_stone
			hp_max = 40 ** 4
			dmg_reduction = 25 ** 4
	hp_max *= 100
	hp_left = hp_max

@onready var edge_hover: Sprite2D = $edge_hover
func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
	auto_dig_timer.stop()

var is_stair: bool = false
var is_enemy: bool = false
func _on_button_pressed() -> void:
	if is_stair == true:
		AsdaInventory.add_mine_floor_max(1)
	else:
		auto_dig_timer.start()
		dig0()

func dig0():
	if is_stair == false:
		if is_enemy == true and knife_power > 0:
			AsdaInventory.add_time_min(1)
			hp_left -= knife_power
			if hp_left <= 0:
				break0()
			health_bar.update_health_bar()
		elif pickaxe_power > 0:
			AsdaInventory.add_time_min(1)
			hp_left -= pickaxe_power
			if hp_left <= 0:
				break0()
			health_bar.update_health_bar()

@onready var enemy: Sprite2D = $enemy
func break0():
	auto_dig_timer.stop()
	enemy.visible = false
	match stone_id:
		0:
			AsdaInventory.add_stone(1)
		1:
			AsdaInventory.add_cese(1)
			AsdaInventory.add_stone(3)
		2:
			AsdaInventory.add_lowaral(1)
			AsdaInventory.add_stone(16)
		3:
			AsdaInventory.add_iena(1)
			AsdaInventory.add_stone(80)
		4:
			AsdaInventory.add_midaral(1)
			AsdaInventory.add_stone(400)
		5:
			AsdaInventory.add_graize(1)
			AsdaInventory.add_stone(2000)
		6:
			AsdaInventory.add_higaral(1)
			AsdaInventory.add_stone(10000)
		7:
			AsdaInventory.add_adanto(1)
			AsdaInventory.add_stone(50000)
		8:
			AsdaInventory.add_maxaral(1)
			AsdaInventory.add_stone(250000)
	if is_enemy == false and 1 == randi_range(1, 4):
		AsdaInventory.set_time_min.connect(attack)
		is_enemy = true
		AsasManager.add_location_prevent(1)
		hp_left = hp_max
		health_bar.update_health_bar()
		enemy.visible = true
	elif AsdaInventory.mine_floor == AsdaInventory.mine_floor_max and 1 == randi_range(1, 20):
		if is_enemy == true:
			AsasManager.add_location_prevent(-1)
		is_stair = true
		hp_left = hp_max
		health_bar.update_health_bar()
		stone.region_rect.position = AaaaGlobal.atlas_stair
	else:
		if is_enemy == true:
			AsasManager.add_location_prevent(-1)
		queue_free()

func attack():
	AsdaInventory.add_health(-10 * dmg_reduction * hp_max)
