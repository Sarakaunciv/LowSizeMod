extends Node

# stat ################################################################
# time
func update_time(time_count):
# energy
	if is_sleep == true:
		add_health(time_count * 50)
		add_energy(time_count * 3)
		add_is_sleep(false)
	else:
		if energy <= 0:
			add_health(time_count * -100)
		elif energy - time_count <= 0:
			add_health(energy * 20)
			add_health((energy - time_count) * 100)
		else:
			add_health(time_count * 20)
		add_energy(time_count * -1)
# food
	if food <= 0:
		add_health(time_count * -200)
	elif food - time_count <= 0:
		add_health(food * 100)
		add_health((food - time_count) * 200)
	else:
		add_health(time_count * 100)
	add_food(time_count * -1)

signal set_time_min()
var time_min: int = 0
func add_time_min(time_min_count):
	time_min += time_min_count
	update_time(time_min_count)
	if time_min >= 60:
		var del0 = time_min % 60
		add_time_hour((time_min - del0) / 60)
		time_min = del0
	set_time_min.emit()

signal set_time_hour()
var time_hour: int = 0
func add_time_hour(time_hour_count):
	time_hour += time_hour_count
	if time_hour >= 24:
		var del0 = time_hour % 24
		add_time_day((time_hour - del0) / 24)
		time_hour = del0
	set_time_hour.emit()

signal set_time_day()
var time_day: int = 0
func add_time_day(time_day_count):
	time_day += time_day_count
	set_time_day.emit()
# health
var health_max: int = 1000000
signal health_0()
signal set_health()
var health: int = 1000000
func add_health(health_count):
	health += health_count
	if health >= 1000000:
		health = 1000000
	set_health.emit()
	if health <= 0:
		health = 0
		health_0.emit()
# food
var food_max: int = 3000
signal set_food()
var food: int = 3000
func add_food(food_count):
	food += food_count
	if food < -1000:
		food = -1000
	if food >= food_max:
		food = food_max
	set_food.emit()

var is_sleep: bool = false
func add_is_sleep(is_sleep_count):
	is_sleep = is_sleep_count
var energy_max: int = 1440
signal set_energy()
var energy: int = 1440
func add_energy(energy_count):
	energy += energy_count
	if energy < -960:
		energy = -960
	if energy >= energy_max:
		energy = energy_max
	set_energy.emit()
# ect ################################################################
signal set_mine_floor()
var mine_floor: int = 0
func add_mine_floor(mine_floor_count):
	mine_floor += mine_floor_count
	if mine_floor > mine_floor_max:
		mine_floor = mine_floor_max
	set_mine_floor.emit()
signal set_mine_floor_max()
var mine_floor_max: int = 0
func add_mine_floor_max(mine_floor_max_count):
	mine_floor_max += mine_floor_max_count
	set_mine_floor_max.emit()

# money ################################################################
signal set_money()
var money_low: int = 0
func add_money_low(money_low_count):
	money_low += money_low_count
	if money_low >= 1000:
		var del0 = money_low % 1000
		add_money_mid((money_low - del0) / 1000)
		money_low = del0
	elif money_low < 0:
		var del0 = (money_low * -1) % 1000
		add_money_mid((money_low + del0) / 1000 - 1)
		add_money_low(((money_low + del0) - 1000) * -1)
	set_money.emit()
var money_mid: int = 0
func add_money_mid(money_mid_count):
	money_mid += money_mid_count
	if money_mid >= 1000:
		var del0 = money_mid % 1000
		add_money_high((money_mid - del0) / 1000)
		money_mid = del0
	elif money_mid < 0:
		var del0 = (money_mid * -1) % 1000
		add_money_high((money_mid + del0) / 1000 - 1)
		add_money_mid(((money_mid + del0) - 1000) * -1)
	set_money.emit()
var money_high: int = 0
func add_money_high(money_high_count):
	money_high += money_high_count
	if money_high >= 1000:
		var del0 = money_high % 1000
		add_money_max((money_high - del0) / 1000)
		money_high = del0
	elif money_high < 0:
		var del0 = (money_high * -1) % 1000
		add_money_max((money_high + del0) / 1000 - 1)
		add_money_high(((money_high + del0) - 1000) * -1)
	set_money.emit()
var money_max: int = 0
func add_money_max(money_max_count):
	money_max += money_max_count
	set_money.emit()

var dept_low: int = 0
var dept_mid: int = 0
var dept_high: int = 0
var dept_max: int = 0
func get_dept():
	dept_low = money_low * -1
	dept_mid = money_mid * -1
	dept_high = money_high * -1
	dept_max = money_max * -1
	if dept_max > 0:
		dept_max -= 1
		dept_high += 1000 - 1
		dept_mid += 1000 - 1
		dept_low += 1000
		if dept_low == 1000:
			dept_low -= 1000
			dept_mid += 1
			if dept_mid == 1000:
				dept_mid -= 1000
				dept_high += 1
				if dept_high == 1000:
					dept_high -= 1000
					dept_max += 1
	else:
		dept_low = 0
		dept_mid = 0
		dept_high = 0
		dept_max = 0

# item
# plant ################################################################
signal set_karat()
var karat: float = 0
func add_karat(karat_count):
	karat += karat_count
	karat = int(karat * 1000) / 1000.0
	set_karat.emit()
signal set_karat_seed()
var karat_seed: int = 0
func add_karat_seed(karat_seed_count):
	karat_seed += karat_seed_count
	set_karat_seed.emit()

signal set_tamaso()
var tamaso: float = 0
func add_tamaso(tamaso_count):
	tamaso += tamaso_count
	tamaso = int(tamaso * 1000) / 1000.0
	set_tamaso.emit()
signal set_tamaso_seed()
var tamaso_seed: int = 0
func add_tamaso_seed(tamaso_seed_count):
	tamaso_seed += tamaso_seed_count
	set_tamaso_seed.emit()

# fert ################################################################
signal set_fert_speed_low()
var fert_speed_low: int = 0
func add_fert_speed_low(fert_speed_low_count):
	fert_speed_low += fert_speed_low_count
	set_fert_speed_low.emit()
signal set_fert_speed_mid()
var fert_speed_mid: int = 0
func add_fert_speed_mid(fert_speed_mid_count):
	fert_speed_mid += fert_speed_mid_count
	set_fert_speed_mid.emit()
signal set_fert_speed_high()
var fert_speed_high: int = 0
func add_fert_speed_high(fert_speed_high_count):
	fert_speed_high += fert_speed_high_count
	set_fert_speed_high.emit()
signal set_fert_speed_max()
var fert_speed_max: int = 0
func add_fert_speed_max(fert_speed_max_count):
	fert_speed_max += fert_speed_max_count
	set_fert_speed_max.emit()

signal set_fert_size_low()
var fert_size_low: int = 0
func add_fert_size_low(fert_size_low_count):
	fert_size_low += fert_size_low_count
	set_fert_size_low.emit()
signal set_fert_size_mid()
var fert_size_mid: int = 0
func add_fert_size_mid(fert_size_mid_count):
	fert_size_mid += fert_size_mid_count
	set_fert_size_mid.emit()
signal set_fert_size_high()
var fert_size_high: int = 0
func add_fert_size_high(fert_size_high_count):
	fert_size_high += fert_size_high_count
	set_fert_size_high.emit()
signal set_fert_size_max()
var fert_size_max: int = 0
func add_fert_size_max(fert_size_max_count):
	fert_size_max += fert_size_max_count
	set_fert_size_max.emit()
# ect ################################################################
signal set_shovel()
var shovel: int = 0
func add_shovel(shovel_count):
	shovel += shovel_count
	set_shovel.emit()
signal set_axe()
var axe: int = 0
func add_axe(axe_count):
	axe += axe_count
	set_axe.emit()

signal set_wood()
var wood: int = 0
func add_wood(wood_count):
	wood += wood_count
	set_wood.emit()

# mineral ################################################################
signal set_stone()
var stone: int = 0
func add_stone(stone_count):
	stone += stone_count
	set_stone.emit()

signal set_cese()
var cese: int = 0
func add_cese(cese_count):
	cese += cese_count
	set_cese.emit()
signal set_cese_pick()
var cese_pick: int = 0
func add_cese_pick(cese_pick_count):
	cese_pick += cese_pick_count
	set_cese_pick.emit()
signal set_cese_knife()
var cese_knife: int = 0
func add_cese_knife(cese_knife_count):
	cese_knife += cese_knife_count
	set_cese_knife.emit()
signal set_cese_shield()
var cese_shield: int = 0
func add_cese_shield(cese_shield_count):
	cese_shield += cese_shield_count
	set_cese_shield.emit()

signal set_lowaral()
var lowaral: int = 0
func add_lowaral(lowaral_count):
	lowaral += lowaral_count
	set_lowaral.emit()
signal set_lowaral_pick()
var lowaral_pick: int = 0
func add_lowaral_pick(lowaral_pick_count):
	lowaral_pick += lowaral_pick_count
	set_lowaral_pick.emit()
signal set_lowaral_knife()
var lowaral_knife: int = 0
func add_lowaral_knife(lowaral_knife_count):
	lowaral_knife += lowaral_knife_count
	set_lowaral_knife.emit()
signal set_lowaral_shield()
var lowaral_shield: int = 0
func add_lowaral_shield(lowaral_shield_count):
	lowaral_shield += lowaral_shield_count
	set_lowaral_shield.emit()

signal set_iena()
var iena: int = 0
func add_iena(iena_count):
	iena += iena_count
	set_iena.emit()
signal set_iena_pick()
var iena_pick: int = 0
func add_iena_pick(iena_pick_count):
	iena_pick += iena_pick_count
	set_iena_pick.emit()
signal set_iena_knife()
var iena_knife: int = 0
func add_iena_knife(iena_knife_count):
	iena_knife += iena_knife_count
	set_iena_knife.emit()
signal set_iena_shield()
var iena_shield: int = 0
func add_iena_shield(iena_shield_count):
	iena_shield += iena_shield_count
	set_iena_shield.emit()

signal set_midaral()
var midaral: int = 0
func add_midaral(midaral_count):
	midaral += midaral_count
	set_midaral.emit()
signal set_midaral_pick()
var midaral_pick: int = 0
func add_midaral_pick(midaral_pick_count):
	midaral_pick += midaral_pick_count
	set_midaral_pick.emit()
signal set_midaral_knife()
var midaral_knife: int = 0
func add_midaral_knife(midaral_knife_count):
	midaral_knife += midaral_knife_count
	set_midaral_knife.emit()
signal set_midaral_shield()
var midaral_shield: int = 0
func add_midaral_shield(midaral_shield_count):
	midaral_shield += midaral_shield_count
	set_midaral_shield.emit()

signal set_graize()
var graize: int = 0
func add_graize(graize_count):
	graize += graize_count
	set_graize.emit()
signal set_graize_pick()
var graize_pick: int = 0
func add_graize_pick(graize_pick_count):
	graize_pick += graize_pick_count
	set_graize_pick.emit()
signal set_graize_knife()
var graize_knife: int = 0
func add_graize_knife(graize_knife_count):
	graize_knife += graize_knife_count
	set_graize_knife.emit()
signal set_graize_shield()
var graize_shield: int = 0
func add_graize_shield(graize_shield_count):
	graize_shield += graize_shield_count
	set_graize_shield.emit()

signal set_higaral()
var higaral: int = 0
func add_higaral(higaral_count):
	higaral += higaral_count
	set_higaral.emit()
signal set_higaral_pick()
var higaral_pick: int = 0
func add_higaral_pick(higaral_pick_count):
	higaral_pick += higaral_pick_count
	set_higaral_pick.emit()
signal set_higaral_knife()
var higaral_knife: int = 0
func add_higaral_knife(higaral_knife_count):
	higaral_knife += higaral_knife_count
	set_higaral_knife.emit()
signal set_higaral_shield()
var higaral_shield: int = 0
func add_higaral_shield(higaral_shield_count):
	higaral_shield += higaral_shield_count
	set_higaral_shield.emit()

signal set_adanto()
var adanto: int = 0
func add_adanto(adanto_count):
	adanto += adanto_count
	set_adanto.emit()
signal set_adanto_pick()
var adanto_pick: int = 0
func add_adanto_pick(adanto_pick_count):
	adanto_pick += adanto_pick_count
	set_adanto_pick.emit()
signal set_adanto_knife()
var adanto_knife: int = 0
func add_adanto_knife(adanto_knife_count):
	adanto_knife += adanto_knife_count
	set_adanto_knife.emit()
signal set_adanto_shield()
var adanto_shield: int = 0
func add_adanto_shield(adanto_shield_count):
	adanto_shield += adanto_shield_count
	set_adanto_shield.emit()

signal set_maxaral()
var maxaral: int = 0
func add_maxaral(maxaral_count):
	maxaral += maxaral_count
	set_maxaral.emit()
signal set_maxaral_pick()
var maxaral_pick: int = 0
func add_maxaral_pick(maxaral_pick_count):
	maxaral_pick += maxaral_pick_count
	set_maxaral_pick.emit()
signal set_maxaral_knife()
var maxaral_knife: int = 0
func add_maxaral_knife(maxaral_knife_count):
	maxaral_knife += maxaral_knife_count
	set_maxaral_knife.emit()
signal set_maxaral_shield()
var maxaral_shield: int = 0
func add_maxaral_shield(maxaral_shield_count):
	maxaral_shield += maxaral_shield_count
	set_maxaral_shield.emit()
