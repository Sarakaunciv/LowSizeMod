extends Node

# money
signal set_money(set_ting0)
var money_low: int = 0
func add_money_low(money_low_count):
	money_low += money_low_count
	if money_low >= 1000:
		var del0 = money_low % 1000
		add_money_mid((money_low - del0) / 1000)
		money_low = del0
	elif money_low < 0:
		var del0 = (money_low * -1) % 1000
		add_money_mid((money_low + del0) / 1000 - 1)
		add_money_low(((money_low + del0) - 1000) * -1)
	set_money.emit(money_low)
var money_mid: int = 0
func add_money_mid(money_mid_count):
	money_mid += money_mid_count
	if money_mid >= 1000:
		var del0 = money_mid % 1000
		add_money_high((money_mid - del0) / 1000)
		money_mid = del0
	elif money_mid < 0:
		var del0 = (money_mid * -1) % 1000
		add_money_high((money_mid + del0) / 1000 - 1)
		add_money_mid(((money_mid + del0) - 1000) * -1)
	set_money.emit(money_mid)
var money_high: int = 0
func add_money_high(money_high_count):
	money_high += money_high_count
	if money_high >= 1000:
		var del0 = money_high % 1000
		add_money_max((money_high - del0) / 1000)
		money_high = del0
	elif money_high < 0:
		var del0 = (money_high * -1) % 1000
		add_money_max((money_high + del0) / 1000 - 1)
		add_money_high(((money_high + del0) - 1000) * -1)
	set_money.emit(money_high)
var money_max: int = 0
func add_money_max(money_max_count):
	money_max += money_max_count
	set_money.emit(money_max)

var dept_low: int = 0
var dept_mid: int = 0
var dept_high: int = 0
var dept_max: int = 0
func get_dept():
	dept_low = money_low * -1
	dept_mid = money_mid * -1
	dept_high = money_high * -1
	dept_max = money_max * -1
	if dept_max > 0:
		dept_max -= 1
		dept_high += 1000 - 1
		dept_mid += 1000 - 1
		dept_low += 1000
		if dept_low == 1000:
			dept_low -= 1000
			dept_mid += 1
			if dept_mid == 1000:
				dept_mid -= 1000
				dept_high += 1
				if dept_high == 1000:
					dept_high -= 1000
					dept_max += 1
	else:
		dept_low = 0
		dept_mid = 0
		dept_high = 0
		dept_max = 0

# item
# plant ################################################################
signal set_karat(set_ting0)
var karat: float = 0
func add_karat(karat_count):
	karat += karat_count
	karat = int(karat * 1000) / 1000.0
	set_karat.emit(karat)
signal set_karat_seed(set_ting0)
var karat_seed: int = 10
func add_karat_seed(karat_seed_count):
	karat_seed += karat_seed_count
	set_karat_seed.emit(karat_seed)

signal set_tamaso(set_ting0)
var tamaso: float = 0
func add_tamaso(tamaso_count):
	tamaso += tamaso_count
	tamaso = int(tamaso * 1000) / 1000.0
	set_tamaso.emit(tamaso)
signal set_tamaso_seed(set_ting0)
var tamaso_seed: int = 10
func add_tamaso_seed(tamaso_seed_count):
	tamaso_seed += tamaso_seed_count
	set_tamaso_seed.emit(tamaso_seed)

# fert ################################################################
signal set_fert_speed_low(set_ting0)
var fert_speed_low: int = 4
func add_fert_speed_low(fert_speed_low_count):
	fert_speed_low += fert_speed_low_count
	set_fert_speed_low.emit(fert_speed_low)
signal set_fert_speed_mid(set_ting0)
var fert_speed_mid: int = 4
func add_fert_speed_mid(fert_speed_mid_count):
	fert_speed_mid += fert_speed_mid_count
	set_fert_speed_mid.emit(fert_speed_mid)
signal set_fert_speed_high(set_ting0)
var fert_speed_high: int = 4
func add_fert_speed_high(fert_speed_high_count):
	fert_speed_high += fert_speed_high_count
	set_fert_speed_high.emit(fert_speed_high)
signal set_fert_speed_max(set_ting0)
var fert_speed_max: int = 4
func add_fert_speed_max(fert_speed_max_count):
	fert_speed_max += fert_speed_max_count
	set_fert_speed_max.emit(fert_speed_max)

signal set_fert_size_low(set_ting0)
var fert_size_low: int = 4
func add_fert_size_low(fert_size_low_count):
	fert_size_low += fert_size_low_count
	set_fert_size_low.emit(fert_size_low)
signal set_fert_size_mid(set_ting0)
var fert_size_mid: int = 4
func add_fert_size_mid(fert_size_mid_count):
	fert_size_mid += fert_size_mid_count
	set_fert_size_mid.emit(fert_size_mid)
signal set_fert_size_high(set_ting0)
var fert_size_high: int = 4
func add_fert_size_high(fert_size_high_count):
	fert_size_high += fert_size_high_count
	set_fert_size_high.emit(fert_size_high)
signal set_fert_size_max(set_ting0)
var fert_size_max: int = 4
func add_fert_size_max(fert_size_max_count):
	fert_size_max += fert_size_max_count
	set_fert_size_max.emit(fert_size_max)

# mineral ################################################################
signal set_cese(set_ting0)
var cese: int = 4
func add_cese(cese_count):
	cese += cese_count
	set_cese.emit(cese)
signal set_cese_pick(set_ting0)
var cese_pick: int = 4
func add_cese_pick(cese_pick_count):
	cese_pick += cese_pick_count
	set_cese_pick.emit(cese_pick)
signal set_cese_knife(set_ting0)
var cese_knife: int = 4
func add_cese_knife(cese_knife_count):
	cese_knife += cese_knife_count
	set_cese_knife.emit(cese_knife)
signal set_cese_shield(set_ting0)
var cese_shield: int = 4
func add_cese_shield(cese_shield_count):
	cese_shield += cese_shield_count
	set_cese_shield.emit(cese_shield)

signal set_lowaral(set_ting0)
var lowaral: int = 4
func add_lowaral(lowaral_count):
	lowaral += lowaral_count
	set_lowaral.emit(lowaral)
signal set_lowaral_pick(set_ting0)
var lowaral_pick: int = 4
func add_lowaral_pick(lowaral_pick_count):
	lowaral_pick += lowaral_pick_count
	set_lowaral_pick.emit(lowaral_pick)
signal set_lowaral_knife(set_ting0)
var lowaral_knife: int = 4
func add_lowaral_knife(lowaral_knife_count):
	lowaral_knife += lowaral_knife_count
	set_lowaral_knife.emit(lowaral_knife)
signal set_lowaral_shield(set_ting0)
var lowaral_shield: int = 4
func add_lowaral_shield(lowaral_shield_count):
	lowaral_shield += lowaral_shield_count
	set_lowaral_shield.emit(lowaral_shield)

signal set_iena(set_ting0)
var iena: int = 4
func add_iena(iena_count):
	iena += iena_count
	set_iena.emit(iena)
signal set_iena_pick(set_ting0)
var iena_pick: int = 4
func add_iena_pick(iena_pick_count):
	iena_pick += iena_pick_count
	set_iena_pick.emit(iena_pick)
signal set_iena_knife(set_ting0)
var iena_knife: int = 4
func add_iena_knife(iena_knife_count):
	iena_knife += iena_knife_count
	set_iena_knife.emit(iena_knife)
signal set_iena_shield(set_ting0)
var iena_shield: int = 4
func add_iena_shield(iena_shield_count):
	iena_shield += iena_shield_count
	set_iena_shield.emit(iena_shield)

signal set_midaral(set_ting0)
var midaral: int = 4
func add_midaral(midaral_count):
	midaral += midaral_count
	set_midaral.emit(midaral)
signal set_midaral_pick(set_ting0)
var midaral_pick: int = 4
func add_midaral_pick(midaral_pick_count):
	midaral_pick += midaral_pick_count
	set_midaral_pick.emit(midaral_pick)
signal set_midaral_knife(set_ting0)
var midaral_knife: int = 4
func add_midaral_knife(midaral_knife_count):
	midaral_knife += midaral_knife_count
	set_midaral_knife.emit(midaral_knife)
signal set_midaral_shield(set_ting0)
var midaral_shield: int = 4
func add_midaral_shield(midaral_shield_count):
	midaral_shield += midaral_shield_count
	set_midaral_shield.emit(midaral_shield)

signal set_graize(set_ting0)
var graize: int = 4
func add_graize(graize_count):
	graize += graize_count
	set_graize.emit(graize)
signal set_graize_pick(set_ting0)
var graize_pick: int = 4
func add_graize_pick(graize_pick_count):
	graize_pick += graize_pick_count
	set_graize_pick.emit(graize_pick)
signal set_graize_knife(set_ting0)
var graize_knife: int = 4
func add_graize_knife(graize_knife_count):
	graize_knife += graize_knife_count
	set_graize_knife.emit(graize_knife)
signal set_graize_shield(set_ting0)
var graize_shield: int = 4
func add_graize_shield(graize_shield_count):
	graize_shield += graize_shield_count
	set_graize_shield.emit(graize_shield)

signal set_higaral(set_ting0)
var higaral: int = 4
func add_higaral(higaral_count):
	higaral += higaral_count
	set_higaral.emit(higaral)
signal set_higaral_pick(set_ting0)
var higaral_pick: int = 4
func add_higaral_pick(higaral_pick_count):
	higaral_pick += higaral_pick_count
	set_higaral_pick.emit(higaral_pick)
signal set_higaral_knife(set_ting0)
var higaral_knife: int = 4
func add_higaral_knife(higaral_knife_count):
	higaral_knife += higaral_knife_count
	set_higaral_knife.emit(higaral_knife)
signal set_higaral_shield(set_ting0)
var higaral_shield: int = 4
func add_higaral_shield(higaral_shield_count):
	higaral_shield += higaral_shield_count
	set_higaral_shield.emit(higaral_shield)

signal set_adanto(set_ting0)
var adanto: int = 4
func add_adanto(adanto_count):
	adanto += adanto_count
	set_adanto.emit(adanto)
signal set_adanto_pick(set_ting0)
var adanto_pick: int = 4
func add_adanto_pick(adanto_pick_count):
	adanto_pick += adanto_pick_count
	set_adanto_pick.emit(adanto_pick)
signal set_adanto_knife(set_ting0)
var adanto_knife: int = 4
func add_adanto_knife(adanto_knife_count):
	adanto_knife += adanto_knife_count
	set_adanto_knife.emit(adanto_knife)
signal set_adanto_shield(set_ting0)
var adanto_shield: int = 4
func add_adanto_shield(adanto_shield_count):
	adanto_shield += adanto_shield_count
	set_adanto_shield.emit(adanto_shield)

signal set_maxaral(set_ting0)
var maxaral: int = 4
func add_maxaral(maxaral_count):
	maxaral += maxaral_count
	set_maxaral.emit(maxaral)
signal set_maxaral_pick(set_ting0)
var maxaral_pick: int = 4
func add_maxaral_pick(maxaral_pick_count):
	maxaral_pick += maxaral_pick_count
	set_maxaral_pick.emit(maxaral_pick)
signal set_maxaral_knife(set_ting0)
var maxaral_knife: int = 4
func add_maxaral_knife(maxaral_knife_count):
	maxaral_knife += maxaral_knife_count
	set_maxaral_knife.emit(maxaral_knife)
signal set_maxaral_shield(set_ting0)
var maxaral_shield: int = 4
func add_maxaral_shield(maxaral_shield_count):
	maxaral_shield += maxaral_shield_count
	set_maxaral_shield.emit(maxaral_shield)
