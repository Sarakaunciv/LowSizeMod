extends Node

# money
signal set_money(set_ting0)
var money_low: int = 0
func add_money_low(money_low_count):
	money_low += money_low_count
	if money_low >= 1000:
		var del0 = money_low % 1000
		add_money_mid((money_low - del0) / 1000)
		money_low = del0
	elif money_low < 0:
		var del0 = (money_low * -1) % 1000
		add_money_mid((money_low + del0) / 1000 - 1)
		add_money_low(((money_low + del0) - 1000) * -1)
	set_money.emit(money_low)
var money_mid: int = 0
func add_money_mid(money_mid_count):
	money_mid += money_mid_count
	if money_mid >= 1000:
		var del0 = money_mid % 1000
		add_money_high((money_mid - del0) / 1000)
		money_mid = del0
	elif money_mid < 0:
		var del0 = (money_mid * -1) % 1000
		add_money_high((money_mid + del0) / 1000 - 1)
		add_money_mid(((money_mid + del0) - 1000) * -1)
	set_money.emit(money_mid)
var money_high: int = 0
func add_money_high(money_high_count):
	money_high += money_high_count
	if money_high >= 1000:
		var del0 = money_high % 1000
		add_money_max((money_high - del0) / 1000)
		money_high = del0
	elif money_high < 0:
		var del0 = (money_high * -1) % 1000
		add_money_max((money_high + del0) / 1000 - 1)
		add_money_high(((money_high + del0) - 1000) * -1)
	set_money.emit(money_high)
var money_max: int = 0
func add_money_max(money_max_count):
	money_max += money_max_count
	set_money.emit(money_max)

var dept_low: int = 0
var dept_mid: int = 0
var dept_high: int = 0
var dept_max: int = 0
func get_dept():
	dept_low = money_low * -1
	dept_mid = money_mid * -1
	dept_high = money_high * -1
	dept_max = money_max * -1
	if dept_max > 0:
		dept_max -= 1
		dept_high += 1000 - 1
		dept_mid += 1000 - 1
		dept_low += 1000
		if dept_low == 1000:
			dept_low -= 1000
			dept_mid += 1
			if dept_mid == 1000:
				dept_mid -= 1000
				dept_high += 1
				if dept_high == 1000:
					dept_high -= 1000
					dept_max += 1
	else:
		dept_low = 0
		dept_mid = 0
		dept_high = 0
		dept_max = 0

# item
signal set_karat(set_ting0)
var karat: float = 0
func add_karat(karat_count):
	karat += karat_count
	karat = int(karat * 1000) / 1000.0
	set_karat.emit(karat)
signal set_karat_seed(set_ting0)
var karat_seed: int = 10
func add_karat_seed(karat_seed_count):
	karat_seed += karat_seed_count
	set_karat_seed.emit(karat_seed)

signal set_tamaso(set_ting0)
var tamaso: float = 0
func add_tamaso(tamaso_count):
	tamaso += tamaso_count
	tamaso = int(tamaso * 1000) / 1000.0
	set_tamaso.emit(tamaso)
signal set_tamaso_seed(set_ting0)
var tamaso_seed: int = 10
func add_tamaso_seed(tamaso_seed_count):
	tamaso_seed += tamaso_seed_count
	set_tamaso_seed.emit(tamaso_seed)

signal set_fert_speed_low(set_ting0)
var fert_speed_low: int = 4
func add_fert_speed_low(fert_speed_low_count):
	fert_speed_low += fert_speed_low_count
	set_fert_speed_low.emit(fert_speed_low)
signal set_fert_speed_mid(set_ting0)
var fert_speed_mid: int = 4
func add_fert_speed_mid(fert_speed_mid_count):
	fert_speed_mid += fert_speed_mid_count
	set_fert_speed_mid.emit(fert_speed_mid)
signal set_fert_speed_high(set_ting0)
var fert_speed_high: int = 4
func add_fert_speed_high(fert_speed_high_count):
	fert_speed_high += fert_speed_high_count
	set_fert_speed_high.emit(fert_speed_high)
signal set_fert_speed_max(set_ting0)
var fert_speed_max: int = 4
func add_fert_speed_max(fert_speed_max_count):
	fert_speed_max += fert_speed_max_count
	set_fert_speed_max.emit(fert_speed_max)

signal set_fert_size_low(set_ting0)
var fert_size_low: int = 4
func add_fert_size_low(fert_size_low_count):
	fert_size_low += fert_size_low_count
	set_fert_size_low.emit(fert_size_low)
signal set_fert_size_mid(set_ting0)
var fert_size_mid: int = 4
func add_fert_size_mid(fert_size_mid_count):
	fert_size_mid += fert_size_mid_count
	set_fert_size_mid.emit(fert_size_mid)
signal set_fert_size_high(set_ting0)
var fert_size_high: int = 4
func add_fert_size_high(fert_size_high_count):
	fert_size_high += fert_size_high_count
	set_fert_size_high.emit(fert_size_high)
signal set_fert_size_max(set_ting0)
var fert_size_max: int = 4
func add_fert_size_max(fert_size_max_count):
	fert_size_max += fert_size_max_count
	set_fert_size_max.emit(fert_size_max)
