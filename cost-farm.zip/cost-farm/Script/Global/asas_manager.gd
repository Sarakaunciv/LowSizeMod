extends Node

signal set_hold_item_id()
var hold_item_id: int = 0
func equal_hold_item_id(hold_item_id_count):
	hold_item_id = hold_item_id_count
	set_hold_item_id.emit()
