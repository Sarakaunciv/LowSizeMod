extends Node

signal set_hold_item_id()
var hold_item_id: int = 0
func equal_hold_item_id(hold_item_id_count):
	hold_item_id = hold_item_id_count
	set_hold_item_id.emit()

signal set_location_prevent()
var location_prevent: int = 0
func add_location_prevent(location_prevent_count):
	location_prevent += location_prevent_count
	set_location_prevent.emit()

func reset0():
	hold_item_id = 0
	location_prevent = 0
