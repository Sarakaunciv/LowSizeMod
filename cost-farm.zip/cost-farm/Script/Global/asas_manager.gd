extends Node

var hold_item_id: int = 0

signal set_day(set_ting0)
var time_day: int = 0
func add_day(day_count):
	time_day += day_count
	set_day.emit(time_day)
