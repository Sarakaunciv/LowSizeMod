extends Node

signal set_hold_item_id
var hold_item_id: int = 0
func equal_hold_item_id(hold_item_id_count):
	hold_item_id = hold_item_id_count
	set_hold_item_id.emit()

signal set_location_prevent
var location_prevent: int = 0
func add_location_prevent(location_prevent_count):
	location_prevent += location_prevent_count
	set_location_prevent.emit()

signal build_people0
var people_name0: String = ""
var people_age0: int = 0
var people_money0: int = 0
func build_people(name0: String, age0: int, money0: int):
	people_name0 = name0
	people_age0 = age0
	people_money0 = money0
	build_people0.emit()

signal set_auto_stop
func add_auto_stop():
	set_auto_stop.emit()

var axe_power: int = 0
func get_axe0():
	axe_power = 100 * ((float(AsdaInventory.axe) ** 0.9) / AsdaInventory.permit_wood)
var pick_power: int = 0
var pick_multiplier: int = 1
func get_pick0():
	pick_power = 0
	pick_multiplier = 1
	
	pick_power += AsdaInventory.shovel + AsdaInventory.axe
	
	pick_power += AsdaInventory.cese_pick * (40 ** 0.5)
	pick_multiplier += AsdaInventory.cese_pick * (25 ** 0.5)
	pick_power += AsdaInventory.lowaral_pick * (40 ** 1)
	pick_multiplier += AsdaInventory.lowaral_pick * (25 ** 1)
	pick_power += AsdaInventory.iena_pick * (40 ** 1.5)
	pick_multiplier += AsdaInventory.iena_pick * (25 ** 1.5)
	pick_power += AsdaInventory.midaral_pick * (40 ** 2)
	pick_multiplier += AsdaInventory.midaral_pick * (25 ** 2)
	pick_power += AsdaInventory.graize_pick * (40 ** 2.5)
	pick_multiplier += AsdaInventory.graize_pick * (25 ** 2.5)
	pick_power += AsdaInventory.higaral_pick * (40 ** 3)
	pick_multiplier += AsdaInventory.higaral_pick * (25 ** 3)
	pick_power += AsdaInventory.adanto_pick * (40 ** 3.5)
	pick_multiplier += AsdaInventory.adanto_pick * (25 ** 3.5)
	pick_power += AsdaInventory.maxaral_pick * (40 ** 4)
	pick_multiplier += AsdaInventory.maxaral_pick * (25 ** 4)
var knife_power: int = 0
var knife_multiplier: int = 1
func get_knife0():
	knife_power = 0
	knife_multiplier = 1
	
	knife_power += AsdaInventory.shovel + AsdaInventory.axe
	
	knife_power += AsdaInventory.cese_pick * (40 ** 0.5) / 4
	knife_multiplier += AsdaInventory.cese_pick * (25 ** 0.5) / 4
	knife_power += AsdaInventory.lowaral_pick * (40 ** 1) / 4
	knife_multiplier += AsdaInventory.lowaral_pick * (25 ** 1) / 4
	knife_power += AsdaInventory.iena_pick * (40 ** 1.5) / 4
	knife_multiplier += AsdaInventory.iena_pick * (25 ** 1.5) / 4
	knife_power += AsdaInventory.midaral_pick * (40 ** 2) / 4
	knife_multiplier += AsdaInventory.midaral_pick * (25 ** 2) / 4
	knife_power += AsdaInventory.graize_pick * (40 ** 2.5) / 4
	knife_multiplier += AsdaInventory.graize_pick * (25 ** 2.5) / 4
	knife_power += AsdaInventory.higaral_pick * (40 ** 3) / 4
	knife_multiplier += AsdaInventory.higaral_pick * (25 ** 3) / 4
	knife_power += AsdaInventory.adanto_pick * (40 ** 3.5) / 4
	knife_multiplier += AsdaInventory.adanto_pick * (25 ** 3.5) / 4
	knife_power += AsdaInventory.maxaral_pick * (40 ** 4) / 4
	knife_multiplier += AsdaInventory.maxaral_pick * (25 ** 4) / 4
	
	knife_power += AsdaInventory.cese_knife * (40 ** 0.5)
	knife_multiplier += AsdaInventory.cese_knife * (25 ** 0.5)
	knife_power += AsdaInventory.lowaral_knife * (40 ** 1)
	knife_multiplier += AsdaInventory.lowaral_knife * (25 ** 1)
	knife_power += AsdaInventory.iena_knife * (40 ** 1.5)
	knife_multiplier += AsdaInventory.iena_knife * (25 ** 1.5)
	knife_power += AsdaInventory.midaral_knife * (40 ** 2)
	knife_multiplier += AsdaInventory.midaral_knife * (25 ** 2)
	knife_power += AsdaInventory.graize_knife * (40 ** 2.5)
	knife_multiplier += AsdaInventory.graize_knife * (25 ** 2.5)
	knife_power += AsdaInventory.higaral_knife * (40 ** 3)
	knife_multiplier += AsdaInventory.higaral_knife * (25 ** 3)
	knife_power += AsdaInventory.adanto_knife * (40 ** 3.5)
	knife_multiplier += AsdaInventory.adanto_knife * (25 ** 3.5)
	knife_power += AsdaInventory.maxaral_knife * (40 ** 4)
	knife_multiplier += AsdaInventory.maxaral_knife * (25 ** 4)
var shield_power: int = 0
var shield_multiplier: int = 1
func get_shield0():
	shield_power = 1
	shield_multiplier = 1
	
	shield_power += AsdaInventory.shovel + AsdaInventory.axe
	
	shield_power += AsdaInventory.cese_shield * (40 ** 0.5)
	shield_multiplier += AsdaInventory.cese_shield * (25 ** 0.5)
	shield_power += AsdaInventory.lowaral_shield * (40 ** 1)
	shield_multiplier += AsdaInventory.lowaral_shield * (25 ** 1)
	shield_power += AsdaInventory.iena_shield * (40 ** 1.5)
	shield_multiplier += AsdaInventory.iena_shield * (25 ** 1.5)
	shield_power += AsdaInventory.midaral_shield * (40 ** 2)
	shield_multiplier += AsdaInventory.midaral_shield * (25 ** 2)
	shield_power += AsdaInventory.graize_shield * (40 ** 2.5)
	shield_multiplier += AsdaInventory.graize_shield * (25 ** 2.5)
	shield_power += AsdaInventory.higaral_shield * (40 ** 3)
	shield_multiplier += AsdaInventory.higaral_shield * (25 ** 3)
	shield_power += AsdaInventory.adanto_shield * (40 ** 3.5)
	shield_multiplier += AsdaInventory.adanto_shield * (25 ** 3.5)
	shield_power += AsdaInventory.maxaral_shield * (40 ** 4)
	shield_multiplier += AsdaInventory.maxaral_shield * (25 ** 4)

func reset0():
	hold_item_id = 0
	location_prevent = 0
