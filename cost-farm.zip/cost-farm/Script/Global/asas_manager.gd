extends Node

signal set_hold_item_id(set_ting0)
var hold_item_id: int = 0
func equal_hold_item_id(hold_item_id_count):
	hold_item_id = hold_item_id_count
	set_hold_item_id.emit(hold_item_id)

signal set_day(set_ting0)
var time_day: int = 0
func add_day(day_count):
	time_day += day_count
	set_day.emit(time_day)
