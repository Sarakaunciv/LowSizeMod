extends Node

var the_texture_size: int = 16
var tile_size0: int = 80
var inventory_row: int = 20
var inventory_page: int = inventory_row * 3

var atlas_dirt: Vector2 = Vector2(0 + 8, 0) * the_texture_size
var atlas_dirt_dark: Vector2 = Vector2(1 + 8, 0) * the_texture_size
var atlas_dirt_select: Vector2 = Vector2(5 + 8, 0) * the_texture_size

## scene
var id_scene_farm: int = 1
# plant ################################################################
var atlas_plant_s_0: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_1: Vector2 = Vector2(1, 0) * the_texture_size
var atlas_plant_s_2: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_3: Vector2 = Vector2(3, 0) * the_texture_size
var atlas_plant_s_4: Vector2 = Vector2(4, 0) * the_texture_size
var atlas_plant_s_5: Vector2 = Vector2(5, 0) * the_texture_size
var atlas_plant_seed: Vector2 = Vector2(1, 0) * the_texture_size
# karat
var id_karat: int = 1
var id_karat_price: int = 45
var id_karat_seed: int = id_karat + (inventory_row * 1)
var id_karat_seed_price: int = 2
var atlas_karat_inv: Vector2 = Vector2(0, 0) * the_texture_size
var atlas_karat_seed_inv: Vector2 = atlas_karat_inv + atlas_plant_seed
var atlas_karat_plant: Vector2 = atlas_karat_inv + atlas_plant_s_0
var karat_grow_speed: int = 100
# tamaso
var id_tamaso: int = 2
var id_tamaso_price: int = 50
var id_tamaso_seed: int = id_tamaso + (inventory_row * 1)
var id_tamaso_seed_price: int = 4
var atlas_tamaso_inv: Vector2 = Vector2(0, 1) * the_texture_size
var atlas_tamaso_seed_inv: Vector2 = atlas_tamaso_inv + atlas_plant_seed
var atlas_tamaso_plant: Vector2 = atlas_tamaso_inv + atlas_plant_s_0
var tamaso_grow_speed: int = 100

# fert ################################################################
var atlas_bag_0: Vector2 = Vector2(0, 0 + 8) * the_texture_size
var atlas_fert_low_inv: Vector2 = Vector2(1, 0 + 8) * the_texture_size
var atlas_fert_mid_inv: Vector2 = Vector2(2, 0 + 8) * the_texture_size
var atlas_fert_high_inv: Vector2 = Vector2(3, 0 + 8) * the_texture_size
var atlas_fert_max_inv: Vector2 = Vector2(4, 0 + 8) * the_texture_size

var atlas_fert_speed_inv: Vector2 = Vector2(5, 0 + 8) * the_texture_size
var atlas_fert_size_inv: Vector2 = Vector2(6, 0 + 8) * the_texture_size

var id_fert_speed_low: int = 1 + (inventory_row * 2)
var id_fert_speed_low_price: int = 650
var fert_speed_low_value: float = 2.0
var id_fert_speed_mid: int = 2 + (inventory_row * 2)
var id_fert_speed_mid_price: int = 4000
var fert_speed_mid_value: float = 4.0
var id_fert_speed_high: int = 3 + (inventory_row * 2)
var id_fert_speed_high_price: int = 33000
var fert_speed_high_value: float = 20.0
var id_fert_speed_max: int = 4 + (inventory_row * 2)
var id_fert_speed_max_price: int = 300000
var fert_speed_max_value: float = 100.0
var id_fert_size_low: int = 5 + (inventory_row * 2)
var id_fert_size_low_price: int = 850
var fert_size_low_value: float = 2.0
var id_fert_size_mid: int = 6 + (inventory_row * 2)
var id_fert_size_mid_price: int = 5800
var fert_size_mid_value: float = 4.0
var id_fert_size_high: int = 7 + (inventory_row * 2)
var id_fert_size_high_price: int = 46200
var fert_size_high_value: float = 20.0
var id_fert_size_max: int = 8 + (inventory_row * 2)
var id_fert_size_max_price: int = 450000
var fert_size_max_value: float = 100.0

# mineral ################################################################
# tool
var recipe_pick_count: int = 12
var recipe_knife_count: int = 22
var recipe_shield_count: int = 29
# cese
var id_cese: int = 1 + (inventory_row * 3)
var id_cese_price: int = 4
var atlas_cese_inv: Vector2 = Vector2(0 + 8, 7) * the_texture_size
# cese_pick
var id_cese_pick: int = 1 + 8 + (inventory_row * 3)
var id_cese_pick_price: int = 4 * recipe_pick_count
var atlas_cese_pick_inv: Vector2 = Vector2(0, 2 + 8) * the_texture_size
# cese_knife
var id_cese_knife: int = 1 + 8 + (inventory_row * 4)
var id_cese_knife_price: int = 4 * recipe_knife_count
var atlas_cese_knife_inv: Vector2 = Vector2(0, 3 + 8) * the_texture_size
# cese_shield
var id_cese_shield: int = 1 + 8 + (inventory_row * 5)
var id_cese_shield_price: int = 4 * recipe_shield_count
var atlas_cese_shield_inv: Vector2 = Vector2(0, 4 + 8) * the_texture_size

# lowaral
var id_lowaral: int = 2 + (inventory_row * 3)
var id_lowaral_price: int = 125
var atlas_lowaral_inv: Vector2 = Vector2(1 + 8, 7) * the_texture_size
# lowaral_pick
var id_lowaral_pick: int = 2 + 8 + (inventory_row * 3)
var id_lowaral_pick_price: int = 125 * recipe_pick_count
var atlas_lowaral_pick_inv: Vector2 = Vector2(1, 2 + 8) * the_texture_size
# lowaral_knife
var id_lowaral_knife: int = 2 + 8 + (inventory_row * 4)
var id_lowaral_knife_price: int = 125 * recipe_knife_count
var atlas_lowaral_knife_inv: Vector2 = Vector2(1, 3 + 8) * the_texture_size
# lowaral_shield
var id_lowaral_shield: int = 2 + 8 + (inventory_row * 5)
var id_lowaral_shield_price: int = 125 * recipe_shield_count
var atlas_lowaral_shield_inv: Vector2 = Vector2(1, 4 + 8) * the_texture_size

# iena
var id_iena: int = 3 + (inventory_row * 3)
var id_iena_price: int = 4 * (1000 ** 1)
var atlas_iena_inv: Vector2 = Vector2(2 + 8, 7) * the_texture_size
# iena_pick
var id_iena_pick: int = 3 + 8 + (inventory_row * 3)
var id_iena_pick_price: int = 4 * recipe_pick_count * (1000 ** 1)
var atlas_iena_pick_inv: Vector2 = Vector2(2, 2 + 8) * the_texture_size
# iena_knife
var id_iena_knife: int = 3 + 8 + (inventory_row * 4)
var id_iena_knife_price: int = 4 * recipe_knife_count * (1000 ** 1)
var atlas_iena_knife_inv: Vector2 = Vector2(2, 3 + 8) * the_texture_size
# iena_shield
var id_iena_shield: int = 3 + 8 + (inventory_row * 5)
var id_iena_shield_price: int = 4 * recipe_shield_count * (1000 ** 1)
var atlas_iena_shield_inv: Vector2 = Vector2(2, 4 + 8) * the_texture_size

# midaral
var id_midaral: int = 4 + (inventory_row * 3)
var id_midaral_price: int = 125 * (1000 ** 1)
var atlas_midaral_inv: Vector2 = Vector2(3 + 8, 7) * the_texture_size
# midaral_pick
var id_midaral_pick: int = 4 + 8 + (inventory_row * 3)
var id_midaral_pick_price: int = 125 * recipe_pick_count * (1000 ** 1)
var atlas_midaral_pick_inv: Vector2 = Vector2(3, 2 + 8) * the_texture_size
# midaral_knife
var id_midaral_knife: int = 4 + 8 + (inventory_row * 4)
var id_midaral_knife_price: int = 125 * recipe_knife_count * (1000 ** 1)
var atlas_midaral_knife_inv: Vector2 = Vector2(3, 3 + 8) * the_texture_size
# midaral_shield
var id_midaral_shield: int = 4 + 8 + (inventory_row * 5)
var id_midaral_shield_price: int = 125 * recipe_shield_count * (1000 ** 1)
var atlas_midaral_shield_inv: Vector2 = Vector2(3, 4 + 8) * the_texture_size

# graize
var id_graize: int = 5 + (inventory_row * 3)
var id_graize_price: int = 4 * (1000 ** 2)
var atlas_graize_inv: Vector2 = Vector2(4 + 8, 7) * the_texture_size
# graize_pick
var id_graize_pick: int = 5 + 8 + (inventory_row * 3)
var id_graize_pick_price: int = 4 * recipe_pick_count * (1000 ** 2)
var atlas_graize_pick_inv: Vector2 = Vector2(4, 2 + 8) * the_texture_size
# graize_knife
var id_graize_knife: int = 5 + 8 + (inventory_row * 4)
var id_graize_knife_price: int = 4 * recipe_knife_count * (1000 ** 2)
var atlas_graize_knife_inv: Vector2 = Vector2(4, 3 + 8) * the_texture_size
# graize_shield
var id_graize_shield: int = 5 + 8 + (inventory_row * 5)
var id_graize_shield_price: int = 4 * recipe_shield_count * (1000 ** 2)
var atlas_graize_shield_inv: Vector2 = Vector2(4, 4 + 8) * the_texture_size

# higaral
var id_higaral: int = 6 + (inventory_row * 3)
var id_higaral_price: int = 125 * (1000 ** 2)
var atlas_higaral_inv: Vector2 = Vector2(5 + 8, 7) * the_texture_size
# higaral_pick
var id_higaral_pick: int = 6 + 8 + (inventory_row * 3)
var id_higaral_pick_price: int = 125 * recipe_pick_count * (1000 ** 2)
var atlas_higaral_pick_inv: Vector2 = Vector2(5, 2 + 8) * the_texture_size
# higaral_knife
var id_higaral_knife: int = 6 + 8 + (inventory_row * 4)
var id_higaral_knife_price: int = 125 * recipe_knife_count * (1000 ** 2)
var atlas_higaral_knife_inv: Vector2 = Vector2(5, 3 + 8) * the_texture_size
# higaral_shield
var id_higaral_shield: int = 6 + 8 + (inventory_row * 5)
var id_higaral_shield_price: int = 125 * recipe_shield_count * (1000 ** 2)
var atlas_higaral_shield_inv: Vector2 = Vector2(5, 4 + 8) * the_texture_size

# adanto
var id_adanto: int = 7 + (inventory_row * 3)
var id_adanto_price: int = 4 * (1000 ** 3)
var atlas_adanto_inv: Vector2 = Vector2(6 + 8, 7) * the_texture_size
# adanto_pick
var id_adanto_pick: int = 7 + 8 + (inventory_row * 3)
var id_adanto_pick_price: int = 4 * recipe_pick_count * (1000 ** 3)
var atlas_adanto_pick_inv: Vector2 = Vector2(6, 2 + 8) * the_texture_size
# adanto_knife
var id_adanto_knife: int = 7 + 8 + (inventory_row * 4)
var id_adanto_knife_price: int = 4 * recipe_knife_count * (1000 ** 3)
var atlas_adanto_knife_inv: Vector2 = Vector2(6, 3 + 8) * the_texture_size
# adanto_shield
var id_adanto_shield: int = 7 + 8 + (inventory_row * 5)
var id_adanto_shield_price: int = 4 * recipe_shield_count * (1000 ** 3)
var atlas_adanto_shield_inv: Vector2 = Vector2(6, 4 + 8) * the_texture_size

# maxaral
var id_maxaral: int = 8 + (inventory_row * 3)
var id_maxaral_price: int = 125 * (1000 ** 3)
var atlas_maxaral_inv: Vector2 = Vector2(7 + 8, 7) * the_texture_size
# maxaral_pick
var id_maxaral_pick: int = 8 + 8 + (inventory_row * 3)
var id_maxaral_pick_price: int = 125 * recipe_pick_count * (1000 ** 3)
var atlas_maxaral_pick_inv: Vector2 = Vector2(7, 2 + 8) * the_texture_size
# maxaral_knife
var id_maxaral_knife: int = 8 + 8 + (inventory_row * 4)
var id_maxaral_knife_price: int = 125 * recipe_knife_count * (1000 ** 3)
var atlas_maxaral_knife_inv: Vector2 = Vector2(7, 3 + 8) * the_texture_size
# maxaral_shield
var id_maxaral_shield: int = 8 + 8 + (inventory_row * 5)
var id_maxaral_shield_price: int = 125 * recipe_shield_count * (1000 ** 3)
var atlas_maxaral_shield_inv: Vector2 = Vector2(7, 4 + 8) * the_texture_size
