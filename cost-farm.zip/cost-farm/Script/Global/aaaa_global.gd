extends Node

var the_texture_size: int = 16
var tile_size0: int = 80
var inventory_row: int = 20

var atlas_dirt: Vector2 = Vector2(8, 0) * the_texture_size
var atlas_dirt_dark: Vector2 = Vector2(9, 0) * the_texture_size

# scene
var id_scene_farm: int = 1
# plant
var atlas_plant_s_0: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_1: Vector2 = Vector2(1, 0) * the_texture_size
var atlas_plant_s_2: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_3: Vector2 = Vector2(3, 0) * the_texture_size
var atlas_plant_s_4: Vector2 = Vector2(4, 0) * the_texture_size
var atlas_plant_s_5: Vector2 = Vector2(5, 0) * the_texture_size
var atlas_plant_seed: Vector2 = Vector2(1, 0) * the_texture_size
# karat
var id_karat: int = 1
var id_karat_seed: int = id_karat + (inventory_row * 1)
var atlas_karat_inv: Vector2 = Vector2(0, 0) * the_texture_size
var atlas_karat_seed_inv: Vector2 = atlas_karat_inv + atlas_plant_seed
var atlas_karat_plant: Vector2 = atlas_karat_inv + atlas_plant_s_0
var karat_grow_speed: float = 100
# tamaso
var id_tamaso: int = 2
var id_tamaso_seed: int = id_tamaso + (inventory_row * 1)
var atlas_tamaso_inv: Vector2 = Vector2(0, 1) * the_texture_size
var atlas_tamaso_seed_inv: Vector2 = atlas_tamaso_inv + atlas_plant_seed
var atlas_tamaso_plant: Vector2 = atlas_tamaso_inv + atlas_plant_s_0
var tamaso_grow_speed: float = 100
