extends Node

var the_texture_size: int = 16
var tile_size0: int = 80
var inventory_row: int = 20
var inventory_page: int = inventory_row * 3

var atlas_false: Vector2 = Vector2(5 + 8, 2 + 8) * the_texture_size
var atlas_green_edge: Vector2 = Vector2(7 + 8, 0) * the_texture_size
# tile
var atlas_dirt: Vector2 = Vector2(0 + 8, 0) * the_texture_size
var atlas_dirt_dark: Vector2 = Vector2(1 + 8, 0) * the_texture_size
var atlas_river_tile: Vector2 = Vector2(0 + 8, 1) * the_texture_size
var atlas_river_tile_dark: Vector2 = Vector2(1 + 8, 1) * the_texture_size
var atlas_wood_tile: Vector2 = Vector2(2 + 8, 5) * the_texture_size
var atlas_wood_tile_dark: Vector2 = Vector2(3 + 8, 5) * the_texture_size
var atlas_dirt_select: Vector2 = Vector2(5 + 8, 0) * the_texture_size
# time ################################################################
var time_day_in_month: int = 30
var time_month_in_year: int = 12
var time_day_in_year: int = time_day_in_month * time_month_in_year
# scene ################################################################
var id_scene_house: int = 1
var id_scene_shop: int = 2
var id_scene_farm: int = 3
var id_scene_mine: int = 4
var id_scene_river: int = 5
var id_scene_wood: int = 6
# new game ################################################################
var start_money: int = 180
var money_work_lvl_multiplier: int = 3
# people ################################################################
var people_age_parent_min: int = 24 * time_day_in_year
var people_age_parent_max: int = 36 * time_day_in_year
var people_age_parent_g_gap: int = 30 * time_day_in_year
# work
var people_work_not_age: int = 60 * time_day_in_year
var id_people_work_not: int = 1001
var id_people_work_not_money: int = 4
var id_people_work_farmer: int = 1
var id_people_work_farmer_money: int = 20
var id_people_work_fisher: int = 2
var id_people_work_fisher_money: int = 19
var id_people_work_miner: int = 3
var id_people_work_miner_money: int = 18
var id_people_work_wooder: int = 4
var id_people_work_wooder_money: int = 17
var id_people_work_cooker: int = 5
var id_people_work_cooker_money: int = 16

# item ################################################################
# plant ################################################################
var atlas_plant_s_0: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_1: Vector2 = Vector2(1, 0) * the_texture_size
var atlas_plant_s_2: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_3: Vector2 = Vector2(3, 0) * the_texture_size
var atlas_plant_s_4: Vector2 = Vector2(4, 0) * the_texture_size
var atlas_plant_s_5: Vector2 = Vector2(5, 0) * the_texture_size
var atlas_plant_seed: Vector2 = Vector2(1, 0) * the_texture_size
# karat 25k
var id_karat: int = 1
var id_karat_price: int = 25
var id_karat_seed: int = id_karat + (inventory_row * 1)
var id_karat_seed_price: int = 1
var atlas_karat_inv: Vector2 = Vector2(0, 0) * the_texture_size
var atlas_karat_seed_inv: Vector2 = atlas_karat_inv + atlas_plant_seed
var atlas_karat_plant: Vector2 = atlas_karat_inv + atlas_plant_s_0
var karat_grow_speed: int = 20
var karat_harvest_count: int = 50
# tamaso 32.2k
var id_tamaso: int = 2
var id_tamaso_price: int = 28
var id_tamaso_seed: int = id_tamaso + (inventory_row * 1)
var id_tamaso_seed_price: int = 5
var atlas_tamaso_inv: Vector2 = Vector2(0, 1) * the_texture_size
var atlas_tamaso_seed_inv: Vector2 = atlas_tamaso_inv + atlas_plant_seed
var atlas_tamaso_plant: Vector2 = atlas_tamaso_inv + atlas_plant_s_0
var tamaso_grow_speed: int = 23
var tamaso_harvest_count: int = 50
# patrak 150k
var id_patrak: int = 3
var id_patrak_price: int = 50
var id_patrak_seed: int = id_patrak + (inventory_row * 1)
var id_patrak_seed_price: int = 50
var atlas_patrak_inv: Vector2 = Vector2(0, 2) * the_texture_size
var atlas_patrak_seed_inv: Vector2 = atlas_patrak_inv + atlas_plant_seed
var atlas_patrak_plant: Vector2 = atlas_patrak_inv + atlas_plant_s_0
var patrak_grow_speed: int = 30
var patrak_harvest_count: int = 100
# apos 125k
var id_apos: int = 4
var id_apos_price: int = 200
var id_apos_seed: int = id_apos + (inventory_row * 1)
var id_apos_seed_price: int = 60
var atlas_apos_inv: Vector2 = Vector2(0, 3) * the_texture_size
var atlas_apos_seed_inv: Vector2 = atlas_apos_inv + atlas_plant_seed
var atlas_apos_plant: Vector2 = atlas_apos_inv + atlas_plant_s_0
var apos_grow_speed: int = 25
var apos_harvest_count: int = 25
# whaat 8m
var id_whaat: int = 5
var id_whaat_price: int = 10000
var id_whaat_seed: int = id_whaat + (inventory_row * 1)
var id_whaat_seed_price: int = 15000
var atlas_whaat_inv: Vector2 = Vector2(0, 4) * the_texture_size
var atlas_whaat_seed_inv: Vector2 = atlas_whaat_inv + atlas_plant_seed
var atlas_whaat_plant: Vector2 = atlas_whaat_inv + atlas_plant_s_0
var whaat_grow_speed: int = 80
var whaat_harvest_count: int = 10
# garn 6m
var id_garn: int = 6
var id_garn_price: int = 30000
var id_garn_seed: int = id_garn + (inventory_row * 1)
var id_garn_seed_price: int = 18000
var atlas_garn_inv: Vector2 = Vector2(0, 5) * the_texture_size
var atlas_garn_seed_inv: Vector2 = atlas_garn_inv + atlas_plant_seed
var atlas_garn_plant: Vector2 = atlas_garn_inv + atlas_plant_s_0
var garn_grow_speed: int = 40
var garn_harvest_count: int = 5
# graize_frizet 200m
var id_graize_frizet: int = 7
var id_graize_frizet_price: int = 4 * (1000 ** 2)
var id_graize_frizet_seed: int = id_graize_frizet + (inventory_row * 1)
var id_graize_frizet_seed_price: int = 10 * (1000 ** 2)
var atlas_graize_frizet_inv: Vector2 = Vector2(0, 6) * the_texture_size
var atlas_graize_frizet_seed_inv: Vector2 = atlas_graize_frizet_inv + atlas_plant_seed
var atlas_graize_frizet_plant: Vector2 = atlas_graize_frizet_inv + atlas_plant_s_0
var graize_frizet_grow_speed: int = 10
var graize_frizet_harvest_count: int = 5
# yume_karst_faw 12b
var id_yume_karst_faw: int = 8
var id_yume_karst_faw_price: int = 12 * (1000 ** 3)
var id_yume_karst_faw_seed: int = id_yume_karst_faw + (inventory_row * 1)
var id_yume_karst_faw_seed_price: int = 1 * (1000 ** 3)
var atlas_yume_karst_faw_inv: Vector2 = Vector2(0, 7) * the_texture_size
var atlas_yume_karst_faw_seed_inv: Vector2 = atlas_yume_karst_faw_inv + atlas_plant_seed
var atlas_yume_karst_faw_plant: Vector2 = atlas_yume_karst_faw_inv + atlas_plant_s_0
var yume_karst_faw_grow_speed: int = 1
var yume_karst_faw_harvest_count: int = 1

# fert ################################################################
var atlas_bag_0_inv: Vector2 = Vector2(0, 0 + 8) * the_texture_size
var atlas_bag_low_inv: Vector2 = Vector2(1, 0 + 8) * the_texture_size
var atlas_bag_mid_inv: Vector2 = Vector2(2, 0 + 8) * the_texture_size
var atlas_bag_high_inv: Vector2 = Vector2(3, 0 + 8) * the_texture_size
var atlas_bag_max_inv: Vector2 = Vector2(4, 0 + 8) * the_texture_size

var atlas_fert_speed_inv: Vector2 = Vector2(5, 0 + 8) * the_texture_size
var atlas_fert_size_inv: Vector2 = Vector2(6, 0 + 8) * the_texture_size

var id_fert_speed_low: int = 1 + (inventory_row * 2)
var id_fert_speed_low_price: int = 600
var fert_speed_low_value: float = 2.0
var id_fert_speed_mid: int = 2 + (inventory_row * 2)
var id_fert_speed_mid_price: int = 4000
var fert_speed_mid_value: float = 4.0
var id_fert_speed_high: int = 3 + (inventory_row * 2)
var id_fert_speed_high_price: int = 360000
var fert_speed_high_value: float = 20.0
var id_fert_speed_max: int = 4 + (inventory_row * 2)
var id_fert_speed_max_price: int = 30000000
var fert_speed_max_value: float = 100.0
var id_fert_size_low: int = 5 + (inventory_row * 2)
var id_fert_size_low_price: int = 900
var fert_size_low_value: float = 2.0
var id_fert_size_mid: int = 6 + (inventory_row * 2)
var id_fert_size_mid_price: int = 6000
var fert_size_mid_value: float = 4.0
var id_fert_size_high: int = 7 + (inventory_row * 2)
var id_fert_size_high_price: int = 540000
var fert_size_high_value: float = 20.0
var id_fert_size_max: int = 8 + (inventory_row * 2)
var id_fert_size_max_price: int = 45000000
var fert_size_max_value: float = 100.0
# ect ################################################################
# recipe #
var recipe_wood_count0: int = 10
var recipe_wood_count1: int = 5
var recipe_pick_count: int = 12
var recipe_knife_count: int = 22
var recipe_shield_count: int = 29
# shovel
var id_shovel: int = 20
var id_shovel_price: int = 18
var atlas_shovel_inv: Vector2 = Vector2(1, 1 + 8) * the_texture_size
# axe
var id_axe: int = 20 + (inventory_row * 1)
var id_axe_price: int = 28
var atlas_axe_inv: Vector2 = Vector2(2, 1 + 8) * the_texture_size
# resource #
# wood
var id_wood: int = 20 + (inventory_row * 2)
var id_wood_price: int = 1
var atlas_wood_inv: Vector2 = Vector2(4 + 8, 5) * the_texture_size
# fish ################################################################
# bait
var id_bait: int = 17 + (inventory_row * 0)
var id_bait_price: int = 8
var atlas_bait_inv: Vector2 = Vector2(4, 1 + 8) * the_texture_size
# fish_rod
var id_fish_rod: int = 18 + (inventory_row * 0)
var id_fish_rod_price: int = 18
var atlas_fish_rod_inv: Vector2 = Vector2(3, 1 + 8) * the_texture_size
# crab_pot
var id_crab_pot: int = 19 + (inventory_row * 0)
var id_crab_pot_price: int = 95
var atlas_crab_pot_inv: Vector2 = Vector2(5, 1 + 8) * the_texture_size
# fish
var id_fish: int = 18 + (inventory_row * 1)
var id_fish_price: int = 80
var atlas_fish_inv: Vector2 = Vector2(0 + 8, 3) * the_texture_size
# crab
var id_crab: int = 19 + (inventory_row * 1)
var id_crab_price: int = 35
var atlas_crab_inv: Vector2 = Vector2(1 + 8, 3) * the_texture_size
# mineral ################################################################
# stone
var id_stone: int = 1 + (inventory_row * 5)
var id_stone_price: int = 1
var atlas_stone_inv: Vector2 = Vector2(0 + 8, 5) * the_texture_size
var atlas_stair: Vector2 = Vector2(2 + 8, 4) * the_texture_size

# cese
var id_cese: int = 1 + (inventory_row * 3)
var id_cese_price: int = 4
var atlas_cese_inv: Vector2 = Vector2(0 + 8, 7) * the_texture_size
var atlas_cese_stone: Vector2 = Vector2(0 + 8, 6) * the_texture_size
# cese_pick
var id_cese_pick: int = 1 + 8 + (inventory_row * 3)
var id_cese_pick_price: int = 4 * recipe_pick_count
var atlas_cese_pick_inv: Vector2 = Vector2(0, 2 + 8) * the_texture_size
# cese_knife
var id_cese_knife: int = 1 + 8 + (inventory_row * 4)
var id_cese_knife_price: int = 4 * recipe_knife_count
var atlas_cese_knife_inv: Vector2 = Vector2(0, 3 + 8) * the_texture_size
# cese_shield
var id_cese_shield: int = 1 + 8 + (inventory_row * 5)
var id_cese_shield_price: int = 4 * recipe_shield_count
var atlas_cese_shield_inv: Vector2 = Vector2(0, 4 + 8) * the_texture_size

# lowaral
var id_lowaral: int = 2 + (inventory_row * 3)
var id_lowaral_price: int = 125
var atlas_lowaral_inv: Vector2 = Vector2(1 + 8, 7) * the_texture_size
var atlas_lowaral_stone: Vector2 = Vector2(1 + 8, 6) * the_texture_size
# lowaral_pick
var id_lowaral_pick: int = 2 + 8 + (inventory_row * 3)
var id_lowaral_pick_price: int = 125 * recipe_pick_count
var atlas_lowaral_pick_inv: Vector2 = Vector2(1, 2 + 8) * the_texture_size
# lowaral_knife
var id_lowaral_knife: int = 2 + 8 + (inventory_row * 4)
var id_lowaral_knife_price: int = 125 * recipe_knife_count
var atlas_lowaral_knife_inv: Vector2 = Vector2(1, 3 + 8) * the_texture_size
# lowaral_shield
var id_lowaral_shield: int = 2 + 8 + (inventory_row * 5)
var id_lowaral_shield_price: int = 125 * recipe_shield_count
var atlas_lowaral_shield_inv: Vector2 = Vector2(1, 4 + 8) * the_texture_size

# iena
var id_iena: int = 3 + (inventory_row * 3)
var id_iena_price: int = 4 * (1000 ** 1)
var atlas_iena_inv: Vector2 = Vector2(2 + 8, 7) * the_texture_size
var atlas_iena_stone: Vector2 = Vector2(2 + 8, 6) * the_texture_size
# iena_pick
var id_iena_pick: int = 3 + 8 + (inventory_row * 3)
var id_iena_pick_price: int = 4 * recipe_pick_count * (1000 ** 1)
var atlas_iena_pick_inv: Vector2 = Vector2(2, 2 + 8) * the_texture_size
# iena_knife
var id_iena_knife: int = 3 + 8 + (inventory_row * 4)
var id_iena_knife_price: int = 4 * recipe_knife_count * (1000 ** 1)
var atlas_iena_knife_inv: Vector2 = Vector2(2, 3 + 8) * the_texture_size
# iena_shield
var id_iena_shield: int = 3 + 8 + (inventory_row * 5)
var id_iena_shield_price: int = 4 * recipe_shield_count * (1000 ** 1)
var atlas_iena_shield_inv: Vector2 = Vector2(2, 4 + 8) * the_texture_size

# midaral
var id_midaral: int = 4 + (inventory_row * 3)
var id_midaral_price: int = 125 * (1000 ** 1)
var atlas_midaral_inv: Vector2 = Vector2(3 + 8, 7) * the_texture_size
var atlas_midaral_stone: Vector2 = Vector2(3 + 8, 6) * the_texture_size
# midaral_pick
var id_midaral_pick: int = 4 + 8 + (inventory_row * 3)
var id_midaral_pick_price: int = 125 * recipe_pick_count * (1000 ** 1)
var atlas_midaral_pick_inv: Vector2 = Vector2(3, 2 + 8) * the_texture_size
# midaral_knife
var id_midaral_knife: int = 4 + 8 + (inventory_row * 4)
var id_midaral_knife_price: int = 125 * recipe_knife_count * (1000 ** 1)
var atlas_midaral_knife_inv: Vector2 = Vector2(3, 3 + 8) * the_texture_size
# midaral_shield
var id_midaral_shield: int = 4 + 8 + (inventory_row * 5)
var id_midaral_shield_price: int = 125 * recipe_shield_count * (1000 ** 1)
var atlas_midaral_shield_inv: Vector2 = Vector2(3, 4 + 8) * the_texture_size

# graize
var id_graize: int = 5 + (inventory_row * 3)
var id_graize_price: int = 4 * (1000 ** 2)
var atlas_graize_inv: Vector2 = Vector2(4 + 8, 7) * the_texture_size
var atlas_graize_stone: Vector2 = Vector2(4 + 8, 6) * the_texture_size
# graize_pick
var id_graize_pick: int = 5 + 8 + (inventory_row * 3)
var id_graize_pick_price: int = 4 * recipe_pick_count * (1000 ** 2)
var atlas_graize_pick_inv: Vector2 = Vector2(4, 2 + 8) * the_texture_size
# graize_knife
var id_graize_knife: int = 5 + 8 + (inventory_row * 4)
var id_graize_knife_price: int = 4 * recipe_knife_count * (1000 ** 2)
var atlas_graize_knife_inv: Vector2 = Vector2(4, 3 + 8) * the_texture_size
# graize_shield
var id_graize_shield: int = 5 + 8 + (inventory_row * 5)
var id_graize_shield_price: int = 4 * recipe_shield_count * (1000 ** 2)
var atlas_graize_shield_inv: Vector2 = Vector2(4, 4 + 8) * the_texture_size

# higaral
var id_higaral: int = 6 + (inventory_row * 3)
var id_higaral_price: int = 125 * (1000 ** 2)
var atlas_higaral_inv: Vector2 = Vector2(5 + 8, 7) * the_texture_size
var atlas_higaral_stone: Vector2 = Vector2(5 + 8, 6) * the_texture_size
# higaral_pick
var id_higaral_pick: int = 6 + 8 + (inventory_row * 3)
var id_higaral_pick_price: int = 125 * recipe_pick_count * (1000 ** 2)
var atlas_higaral_pick_inv: Vector2 = Vector2(5, 2 + 8) * the_texture_size
# higaral_knife
var id_higaral_knife: int = 6 + 8 + (inventory_row * 4)
var id_higaral_knife_price: int = 125 * recipe_knife_count * (1000 ** 2)
var atlas_higaral_knife_inv: Vector2 = Vector2(5, 3 + 8) * the_texture_size
# higaral_shield
var id_higaral_shield: int = 6 + 8 + (inventory_row * 5)
var id_higaral_shield_price: int = 125 * recipe_shield_count * (1000 ** 2)
var atlas_higaral_shield_inv: Vector2 = Vector2(5, 4 + 8) * the_texture_size

# adanto
var id_adanto: int = 7 + (inventory_row * 3)
var id_adanto_price: int = 4 * (1000 ** 3)
var atlas_adanto_inv: Vector2 = Vector2(6 + 8, 7) * the_texture_size
var atlas_adanto_stone: Vector2 = Vector2(6 + 8, 6) * the_texture_size
# adanto_pick
var id_adanto_pick: int = 7 + 8 + (inventory_row * 3)
var id_adanto_pick_price: int = 4 * recipe_pick_count * (1000 ** 3)
var atlas_adanto_pick_inv: Vector2 = Vector2(6, 2 + 8) * the_texture_size
# adanto_knife
var id_adanto_knife: int = 7 + 8 + (inventory_row * 4)
var id_adanto_knife_price: int = 4 * recipe_knife_count * (1000 ** 3)
var atlas_adanto_knife_inv: Vector2 = Vector2(6, 3 + 8) * the_texture_size
# adanto_shield
var id_adanto_shield: int = 7 + 8 + (inventory_row * 5)
var id_adanto_shield_price: int = 4 * recipe_shield_count * (1000 ** 3)
var atlas_adanto_shield_inv: Vector2 = Vector2(6, 4 + 8) * the_texture_size

# maxaral
var id_maxaral: int = 8 + (inventory_row * 3)
var id_maxaral_price: int = 125 * (1000 ** 3)
var atlas_maxaral_inv: Vector2 = Vector2(7 + 8, 7) * the_texture_size
var atlas_maxaral_stone: Vector2 = Vector2(7 + 8, 6) * the_texture_size
# maxaral_pick
var id_maxaral_pick: int = 8 + 8 + (inventory_row * 3)
var id_maxaral_pick_price: int = 125 * recipe_pick_count * (1000 ** 3)
var atlas_maxaral_pick_inv: Vector2 = Vector2(7, 2 + 8) * the_texture_size
# maxaral_knife
var id_maxaral_knife: int = 8 + 8 + (inventory_row * 4)
var id_maxaral_knife_price: int = 125 * recipe_knife_count * (1000 ** 3)
var atlas_maxaral_knife_inv: Vector2 = Vector2(7, 3 + 8) * the_texture_size
# maxaral_shield
var id_maxaral_shield: int = 8 + 8 + (inventory_row * 5)
var id_maxaral_shield_price: int = 125 * recipe_shield_count * (1000 ** 3)
var atlas_maxaral_shield_inv: Vector2 = Vector2(7, 4 + 8) * the_texture_size
# permit ################################################################
# permit_farm
var id_permit_farm: int = 16 + (inventory_row * 0)
var id_permit_farm_price: int = 60000
var atlas_permit_farm_inv: Vector2 = Vector2(5 + 8, 5) * the_texture_size
# permit_mine
var id_permit_mine: int = 16 + (inventory_row * 1)
var id_permit_mine_price: int = 2000
var atlas_permit_mine_inv: Vector2 = Vector2(6 + 8, 5) * the_texture_size
# permit_wood
var id_permit_wood: int = 16 + (inventory_row * 2)
var id_permit_wood_price: int = 500
var atlas_permit_wood_inv: Vector2 = Vector2(7 + 8, 5) * the_texture_size
# permit_fish
var id_permit_fish: int = 17 + (inventory_row * 1)
var id_permit_fish_price: int = 400
var atlas_permit_fish_inv: Vector2 = Vector2(5 + 8, 4) * the_texture_size
# permit_crab
var id_permit_crab: int = 17 + (inventory_row * 2)
var id_permit_crab_price: int = 12000
var atlas_permit_crab_inv: Vector2 = Vector2(6 + 8, 4) * the_texture_size
