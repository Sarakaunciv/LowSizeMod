extends Node

var the_texture_size: int = 16
var tile_size0: int = 80
var inventory_row: int = 20

var atlas_dirt: Vector2 = Vector2(8, 0) * the_texture_size
var atlas_dirt_dark: Vector2 = Vector2(9, 0) * the_texture_size

# scene
var id_scene_farm: int = 1
# plant
var atlas_plant_s_0: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_1: Vector2 = Vector2(1, 0) * the_texture_size
var atlas_plant_s_2: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_3: Vector2 = Vector2(3, 0) * the_texture_size
var atlas_plant_s_4: Vector2 = Vector2(4, 0) * the_texture_size
var atlas_plant_s_5: Vector2 = Vector2(5, 0) * the_texture_size
var atlas_plant_seed: Vector2 = Vector2(1, 0) * the_texture_size
# karat
var id_karat: int = 1
var id_karat_price: int = 45
var id_karat_seed: int = id_karat + (inventory_row * 1)
var id_karat_seed_price: int = 2
var atlas_karat_inv: Vector2 = Vector2(0, 0) * the_texture_size
var atlas_karat_seed_inv: Vector2 = atlas_karat_inv + atlas_plant_seed
var atlas_karat_plant: Vector2 = atlas_karat_inv + atlas_plant_s_0
var karat_grow_speed: int = 100
# tamaso
var id_tamaso: int = 2
var id_tamaso_price: int = 50
var id_tamaso_seed: int = id_tamaso + (inventory_row * 1)
var id_tamaso_seed_price: int = 4
var atlas_tamaso_inv: Vector2 = Vector2(0, 1) * the_texture_size
var atlas_tamaso_seed_inv: Vector2 = atlas_tamaso_inv + atlas_plant_seed
var atlas_tamaso_plant: Vector2 = atlas_tamaso_inv + atlas_plant_s_0
var tamaso_grow_speed: int = 100

# fert
var atlas_bag_0: Vector2 = Vector2(0, 8) * the_texture_size
var atlas_fert_low_inv: Vector2 = Vector2(1, 8) * the_texture_size
var atlas_fert_mid_inv: Vector2 = Vector2(2, 8) * the_texture_size
var atlas_fert_high_inv: Vector2 = Vector2(3, 8) * the_texture_size
var atlas_fert_max_inv: Vector2 = Vector2(4, 8) * the_texture_size

var atlas_fert_speed_inv: Vector2 = Vector2(5, 8) * the_texture_size
var atlas_fert_size_inv: Vector2 = Vector2(6, 8) * the_texture_size

var id_fert_speed_low: int = 1 + (inventory_row * 2)
var id_fert_speed_low_price: int = 650
var fert_speed_low_value: float = 2.0
var id_fert_speed_mid: int = 2 + (inventory_row * 2)
var id_fert_speed_mid_price: int = 4000
var fert_speed_mid_value: float = 4.0
var id_fert_speed_high: int = 3 + (inventory_row * 2)
var id_fert_speed_high_price: int = 33000
var fert_speed_high_value: float = 20.0
var id_fert_speed_max: int = 4 + (inventory_row * 2)
var id_fert_speed_max_price: int = 300000
var fert_speed_max_value: float = 100.0
var id_fert_size_low: int = 5 + (inventory_row * 2)
var id_fert_size_low_price: int = 850
var fert_size_low_value: float = 2.0
var id_fert_size_mid: int = 6 + (inventory_row * 2)
var id_fert_size_mid_price: int = 5800
var fert_size_mid_value: float = 4.0
var id_fert_size_high: int = 7 + (inventory_row * 2)
var id_fert_size_high_price: int = 46200
var fert_size_high_value: float = 20.0
var id_fert_size_max: int = 8 + (inventory_row * 2)
var id_fert_size_max_price: int = 450000
var fert_size_max_value: float = 100.0
