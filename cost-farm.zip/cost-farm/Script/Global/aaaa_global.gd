extends Node

var the_texture_size: int = 16
var tile_size0: int = 80

var atlas_dirt: Vector2 = Vector2(8, 0) * the_texture_size
var atlas_dirt_dark: Vector2 = Vector2(9, 0) * the_texture_size

#plant
var atlas_plant_s_1: Vector2 = Vector2(1, 0) * the_texture_size
var atlas_plant_s_2: Vector2 = Vector2(2, 0) * the_texture_size
var atlas_plant_s_3: Vector2 = Vector2(3, 0) * the_texture_size
var atlas_plant_s_4: Vector2 = Vector2(4, 0) * the_texture_size
var atlas_plant_s_5: Vector2 = Vector2(5, 0) * the_texture_size
# karat
var id_karat: int = 1
var atlas_karat: Vector2 = Vector2(2, 0) * the_texture_size
var karat_grow_speed: float = 0.09
# tamaso
var id_tamaso: int = 2
var atlas_tamaso: Vector2 = Vector2(2, 1) * the_texture_size
var tamaso_grow_speed: float = 0.1
