extends Resource
class_name zzzz_resource

@export var farm_tile_0: Array[PackedScene]
@export var river_tile_0: Array[PackedScene]
@export var inv: Array
@export var people_0: Array[PackedScene]
