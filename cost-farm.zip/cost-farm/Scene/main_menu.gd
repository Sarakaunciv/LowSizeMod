extends Control

func _ready() -> void:
	pass #Save.load0()

func _on_start_b_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/new_game/new_game_menu.tscn")

func _on_quit_b_pressed() -> void:
	get_tree().quit()
