extends Control

func _ready() -> void:
	pass #Save.load0()

func _on_continue_pressed() -> void:
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		get_tree().change_scene_to_file("res://Scene/LocationScene/house.tscn")

var difficulty: int = 1
func _on_new_game_pressed() -> void:
	var del0 = DirAccess.open("res://Scene/SaveScene/")
	if FileAccess.file_exists("res://Scene/SaveScene/farm.tres"):
		del0.remove("farm.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		del0.remove("inv.tres")
	reset0()
	start0()
	start1()
	get_tree().change_scene_to_file("res://Scene/LocationScene/house.tscn")

func start0():
	match difficulty:
		1:
# money ################################################################
			AsdaInventory.money_low = 150#money_low
			AsdaInventory.money_mid = 0#money_mid
			AsdaInventory.money_high = 0#money_high
			AsdaInventory.money_max = 0#money_max
			# item
			# plant ################################################################
			AsdaInventory.karat = 10#karat
			AsdaInventory.karat_seed = 40#karat_seed
			
			AsdaInventory.tamaso = 2#tamaso
			AsdaInventory.tamaso_seed = 10#tamaso_seed
			# fert ################################################################
			AsdaInventory.fert_speed_low = 5#fert_speed_low
			AsdaInventory.fert_speed_mid = 0#fert_speed_mid
			AsdaInventory.fert_speed_high = 0#fert_speed_high
			AsdaInventory.fert_speed_max = 0#fert_speed_max
			
			AsdaInventory.fert_size_low = 0#fert_size_low
			AsdaInventory.fert_size_mid = 0#fert_size_mid
			AsdaInventory.fert_size_high = 0#fert_size_high
			AsdaInventory.fert_size_max = 0#fert_size_max
			# ect ################################################################
			AsdaInventory.shovel = 1#shovel
			AsdaInventory.axe = 1#axe
			
			AsdaInventory.wood = 10#wood
			# mineral ################################################################
			AsdaInventory.stone = 5#stone
			
			AsdaInventory.cese = 0#cese
			AsdaInventory.cese_pick = 0#cese_pick
			AsdaInventory.cese_knife = 0#cese_knife
			AsdaInventory.cese_shield = 0#cese_shield

func start1():
# stat ################################################################
# time
	AsdaInventory.time_min = 0#time_min
	AsdaInventory.time_hour = 0#time_hour
	AsdaInventory.time_day = 0#time_day
# health
	AsdaInventory.health_max = 1000000#health_max
	AsdaInventory.health = 1000000#health
# food
	AsdaInventory.food_max = 3000#food_max
	AsdaInventory.food = 3000#food
# energy
	AsdaInventory.energy_max = 1440#energy_max
	AsdaInventory.energy = 1440#energy
# ect ################################################################
	AsdaInventory.mine_floor = 0#mine_floor
	AsdaInventory.mine_floor_max = 0#mine_floor_max

func reset0():
# stat ################################################################
# time
	AsdaInventory.time_min = 0#time_min
	AsdaInventory.time_hour = 0#time_hour
	AsdaInventory.time_day = 0#time_day
# health
	AsdaInventory.health_max = 0#health_max
	AsdaInventory.health = 0#health
# food
	AsdaInventory.food_max = 0#food_max
	AsdaInventory.food = 0#food
# energy
	AsdaInventory.energy_max = 0#energy_max
	AsdaInventory.energy = 0#energy
	# ect ################################################################
	AsdaInventory.mine_floor = 0#mine_floor
	AsdaInventory.mine_floor_max = 0#mine_floor_max
	# money ################################################################
	AsdaInventory.money_low = 0#money_low
	AsdaInventory.money_mid = 0#money_mid
	AsdaInventory.money_high = 0#money_high
	AsdaInventory.money_max = 0#money_max
	# item
	# plant ################################################################
	AsdaInventory.karat = 0#karat
	AsdaInventory.karat_seed = 0#karat_seed
	
	AsdaInventory.tamaso = 0#tamaso
	AsdaInventory.tamaso_seed = 0#tamaso_seed
	# fert ################################################################
	AsdaInventory.fert_speed_low = 0#fert_speed_low
	AsdaInventory.fert_speed_mid = 0#fert_speed_mid
	AsdaInventory.fert_speed_high = 0#fert_speed_high
	AsdaInventory.fert_speed_max = 0#fert_speed_max
	
	AsdaInventory.fert_size_low = 0#fert_size_low
	AsdaInventory.fert_size_mid = 0#fert_size_mid
	AsdaInventory.fert_size_high = 0#fert_size_high
	AsdaInventory.fert_size_max = 0#fert_size_max
	# ect ################################################################
	AsdaInventory.shovel = 0#shovel
	AsdaInventory.axe = 0#axe
	
	AsdaInventory.wood = 0#wood
	# mineral ################################################################
	AsdaInventory.stone = 0#stone
	
	AsdaInventory.cese = 0#cese
	AsdaInventory.cese_pick = 0#cese_pick
	AsdaInventory.cese_knife = 0#cese_knife
	AsdaInventory.cese_shield = 0#cese_shield
	
	AsdaInventory.lowaral = 0#lowaral
	AsdaInventory.lowaral_pick = 0#lowaral_pick
	AsdaInventory.lowaral_knife = 0#lowaral_knife
	AsdaInventory.lowaral_shield = 0#lowaral_shield
	
	AsdaInventory.iena = 0#iena
	AsdaInventory.iena_pick = 0#iena_pick
	AsdaInventory.iena_knife = 0#iena_knife
	AsdaInventory.iena_shield = 0#iena_shield
	
	AsdaInventory.midaral = 0#midaral
	AsdaInventory.midaral_pick = 0#midaral_pick
	AsdaInventory.midaral_knife = 0#midaral_knife
	AsdaInventory.midaral_shield = 0#midaral_shield
	
	AsdaInventory.graize = 0#graize
	AsdaInventory.graize_pick = 0#graize_pick
	AsdaInventory.graize_knife = 0#graize_knife
	AsdaInventory.graize_shield = 0#graize_shield
	
	AsdaInventory.higaral = 0#higaral
	AsdaInventory.higaral_pick = 0#higaral_pick
	AsdaInventory.higaral_knife = 0#higaral_knife
	AsdaInventory.higaral_shield = 0#higaral_shield
	
	AsdaInventory.adanto = 0#adanto
	AsdaInventory.adanto_pick = 0#adanto_pick
	AsdaInventory.adanto_knife = 0#adanto_knife
	AsdaInventory.adanto_shield = 0#adanto_shield
	
	AsdaInventory.maxaral = 0#maxaral
	AsdaInventory.maxaral_pick = 0#maxaral_pick
	AsdaInventory.maxaral_knife = 0#maxaral_knife
	AsdaInventory.maxaral_shield = 0#maxaral_shield
