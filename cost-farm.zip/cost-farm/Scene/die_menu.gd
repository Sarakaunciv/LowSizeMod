extends Control

func _ready() -> void:
	pass

func _on_accept_death_pressed() -> void:
	var del0 = DirAccess.open("res://Scene/SaveScene/")
	if FileAccess.file_exists("res://Scene/SaveScene/farm.tres"):
		del0.remove("farm.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		del0.remove("inv.tres")
	get_tree().change_scene_to_file("res://Scene/main_menu.tscn")
