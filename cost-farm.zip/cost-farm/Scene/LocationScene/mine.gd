extends Node2D

var scene_id: int = AaaaGlobal.id_scene_mine
var pickaxe_power: int = 1
func _ready() -> void:
	await get_tree().create_timer(0.1).timeout
	update0()
	mine_tile_build()

func update0():
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.cese_pick * AaaaGlobal.id_cese_price)
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.lowaral_pick * AaaaGlobal.id_lowaral_price)
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.iena_pick * AaaaGlobal.id_iena_price)
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.midaral_pick * AaaaGlobal.id_midaral_price)
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.graize_pick * AaaaGlobal.id_graize_price)
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.higaral_pick * AaaaGlobal.id_higaral_price)
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.adanto_pick * AaaaGlobal.id_adanto_price)
	print(pickaxe_power)
	pickaxe_power += (AsdaInventory.maxaral_pick * AaaaGlobal.id_maxaral_price)
	print(pickaxe_power)

@onready var mine_tile_0: Node2D = $mine_tile_0
var mine_tile = load("res://Script/Main/mine/mine_tile.tscn")
func mine_tile_build():
	for del0x in range(20):
		for del0y in range(10):
			var del0tile = mine_tile.instantiate()
			mine_tile_0.call_deferred("add_child", del0tile)
			del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)
