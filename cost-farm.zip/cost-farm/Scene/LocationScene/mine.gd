extends Node2D

var scene_id: int = AaaaGlobal.id_scene_mine
var pickaxe_power: int = 1
var attack_multiplier: int = 1
func _ready() -> void:
	await get_tree().create_timer(0.1).timeout
	update0()
	mine_tile_build()

func update0():
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.cese_pick * (40 ** 0.5)
	attack_multiplier += AsdaInventory.cese_pick * (25 ** 0.5)
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.lowaral_pick * (40 ** 1)
	attack_multiplier += AsdaInventory.lowaral_pick * (25 ** 1)
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.iena_pick * (40 ** 1.5)
	attack_multiplier += AsdaInventory.iena_pick * (25 ** 1.5)
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.midaral_pick * (40 ** 2)
	attack_multiplier += AsdaInventory.midaral_pick * (25 ** 2)
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.graize_pick * (40 ** 2.5)
	attack_multiplier += AsdaInventory.graize_pick * (25 ** 2.5)
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.higaral_pick * (40 ** 3)
	attack_multiplier += AsdaInventory.higaral_pick * (25 ** 3)
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.adanto_pick * (40 ** 3.5)
	attack_multiplier += AsdaInventory.adanto_pick * (25 ** 3.5)
	print(pickaxe_power, ", ", attack_multiplier)
	pickaxe_power += AsdaInventory.maxaral_pick * (40 ** 4)
	attack_multiplier += AsdaInventory.maxaral_pick * (25 ** 4)
	print(pickaxe_power, ", ", attack_multiplier)

@onready var mine_tile_0: Node2D = $mine_tile_0
var mine_tile = load("res://Script/Main/mine/mine_tile.tscn")
func mine_tile_build():
	for del0x in range(20):
		for del0y in range(10):
			var del0tile = mine_tile.instantiate()
			mine_tile_0.call_deferred("add_child", del0tile)
			del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)
