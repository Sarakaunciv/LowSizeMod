extends Node2D

@onready var ready_delay: Timer = $ready_delay

var scene_id: int = AaaaGlobal.id_scene_mine
var pick_power: int = 0
var pick_multiplier: int = 1
var knife_power: int = 0
var knife_multiplier: int = 1
var shield_power: int = 0
var shield_multiplier: int = 1
func _ready() -> void:
	AsdaInventory.set_mine_floor.connect(update1)
	AsdaInventory.set_mine_floor_max.connect(update2)
	ready_delay.timeout.connect(ready0)
	ready_delay.wait_time = 0.1
	ready_delay.one_shot = true
	ready_delay.start()

func ready0():
	update0()
	update1()
	mine_tile_build()

func update0():
# pick
	pick_power += AsdaInventory.shovel + AsdaInventory.axe
	
	pick_power += AsdaInventory.cese_pick * (40 ** 0.5)
	pick_multiplier += AsdaInventory.cese_pick * (25 ** 0.5)
	pick_power += AsdaInventory.lowaral_pick * (40 ** 1)
	pick_multiplier += AsdaInventory.lowaral_pick * (25 ** 1)
	pick_power += AsdaInventory.iena_pick * (40 ** 1.5)
	pick_multiplier += AsdaInventory.iena_pick * (25 ** 1.5)
	pick_power += AsdaInventory.midaral_pick * (40 ** 2)
	pick_multiplier += AsdaInventory.midaral_pick * (25 ** 2)
	pick_power += AsdaInventory.graize_pick * (40 ** 2.5)
	pick_multiplier += AsdaInventory.graize_pick * (25 ** 2.5)
	pick_power += AsdaInventory.higaral_pick * (40 ** 3)
	pick_multiplier += AsdaInventory.higaral_pick * (25 ** 3)
	pick_power += AsdaInventory.adanto_pick * (40 ** 3.5)
	pick_multiplier += AsdaInventory.adanto_pick * (25 ** 3.5)
	pick_power += AsdaInventory.maxaral_pick * (40 ** 4)
	pick_multiplier += AsdaInventory.maxaral_pick * (25 ** 4)
# knife
	knife_power += AsdaInventory.shovel + AsdaInventory.axe
	
	knife_power += AsdaInventory.cese_pick * (40 ** 0.5) / 4
	knife_multiplier += AsdaInventory.cese_pick * (25 ** 0.5) / 4
	knife_power += AsdaInventory.lowaral_pick * (40 ** 1) / 4
	knife_multiplier += AsdaInventory.lowaral_pick * (25 ** 1) / 4
	knife_power += AsdaInventory.iena_pick * (40 ** 1.5) / 4
	knife_multiplier += AsdaInventory.iena_pick * (25 ** 1.5) / 4
	knife_power += AsdaInventory.midaral_pick * (40 ** 2) / 4
	knife_multiplier += AsdaInventory.midaral_pick * (25 ** 2) / 4
	knife_power += AsdaInventory.graize_pick * (40 ** 2.5) / 4
	knife_multiplier += AsdaInventory.graize_pick * (25 ** 2.5) / 4
	knife_power += AsdaInventory.higaral_pick * (40 ** 3) / 4
	knife_multiplier += AsdaInventory.higaral_pick * (25 ** 3) / 4
	knife_power += AsdaInventory.adanto_pick * (40 ** 3.5) / 4
	knife_multiplier += AsdaInventory.adanto_pick * (25 ** 3.5) / 4
	knife_power += AsdaInventory.maxaral_pick * (40 ** 4) / 4
	knife_multiplier += AsdaInventory.maxaral_pick * (25 ** 4) / 4
	
	knife_power += AsdaInventory.cese_knife * (40 ** 0.5)
	knife_multiplier += AsdaInventory.cese_knife * (25 ** 0.5)
	knife_power += AsdaInventory.lowaral_knife * (40 ** 1)
	knife_multiplier += AsdaInventory.lowaral_knife * (25 ** 1)
	knife_power += AsdaInventory.iena_knife * (40 ** 1.5)
	knife_multiplier += AsdaInventory.iena_knife * (25 ** 1.5)
	knife_power += AsdaInventory.midaral_knife * (40 ** 2)
	knife_multiplier += AsdaInventory.midaral_knife * (25 ** 2)
	knife_power += AsdaInventory.graize_knife * (40 ** 2.5)
	knife_multiplier += AsdaInventory.graize_knife * (25 ** 2.5)
	knife_power += AsdaInventory.higaral_knife * (40 ** 3)
	knife_multiplier += AsdaInventory.higaral_knife * (25 ** 3)
	knife_power += AsdaInventory.adanto_knife * (40 ** 3.5)
	knife_multiplier += AsdaInventory.adanto_knife * (25 ** 3.5)
	knife_power += AsdaInventory.maxaral_knife * (40 ** 4)
	knife_multiplier += AsdaInventory.maxaral_knife * (25 ** 4)
# shield
	shield_power += AsdaInventory.shovel + AsdaInventory.axe
	
	shield_power += AsdaInventory.cese_shield * (40 ** 0.5)
	shield_multiplier += AsdaInventory.cese_shield * (25 ** 0.5)
	shield_power += AsdaInventory.lowaral_shield * (40 ** 1)
	shield_multiplier += AsdaInventory.lowaral_shield * (25 ** 1)
	shield_power += AsdaInventory.iena_shield * (40 ** 1.5)
	shield_multiplier += AsdaInventory.iena_shield * (25 ** 1.5)
	shield_power += AsdaInventory.midaral_shield * (40 ** 2)
	shield_multiplier += AsdaInventory.midaral_shield * (25 ** 2)
	shield_power += AsdaInventory.graize_shield * (40 ** 2.5)
	shield_multiplier += AsdaInventory.graize_shield * (25 ** 2.5)
	shield_power += AsdaInventory.higaral_shield * (40 ** 3)
	shield_multiplier += AsdaInventory.higaral_shield * (25 ** 3)
	shield_power += AsdaInventory.adanto_shield * (40 ** 3.5)
	shield_multiplier += AsdaInventory.adanto_shield * (25 ** 3.5)
	shield_power += AsdaInventory.maxaral_shield * (40 ** 4)
	shield_multiplier += AsdaInventory.maxaral_shield * (25 ** 4)

@onready var mine_tile_0: Node2D = $mine_tile_0
var mine_tile = load("res://Script/Main/mine/mine_tile.tscn")
func mine_tile_build():
	var mine_tile_1 = get_tree().get_nodes_in_group("mine_tile")
	for del0 in mine_tile_1:
		del0.queue_free()
	for del0x in range(20):
		for del0y in range(10):
			var del0tile = mine_tile.instantiate()
			mine_tile_0.call_deferred("add_child", del0tile)
			del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)

@onready var mine_floor: Label = $floor/ColorRect/mine_floor
func update1():
	mine_floor.text = str(AsdaInventory.mine_floor)
func _on_ba_pressed() -> void:
	AsdaInventory.add_mine_floor(10)
func _on_aa_pressed() -> void:
	AsdaInventory.add_mine_floor(1)
func _on_as_pressed() -> void:
	AsdaInventory.add_mine_floor(-1)
func _on_bs_pressed() -> void:
	AsdaInventory.add_mine_floor(-10)
func _on_reset_pressed() -> void:
	mine_tile_build()

func update2():
	AsdaInventory.add_mine_floor(1)
	mine_tile_build()
