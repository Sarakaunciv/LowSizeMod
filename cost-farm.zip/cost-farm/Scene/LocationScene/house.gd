extends Node2D

var scene_id: int = AaaaGlobal.id_scene_house

func _ready() -> void:
	pass

func _on_button_pressed() -> void:
	AsdaInventory.add_day(1)
