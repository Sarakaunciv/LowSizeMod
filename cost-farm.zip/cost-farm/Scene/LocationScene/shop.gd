extends Node2D

var scene_id: int = 2

func _ready() -> void:
	pass


func _on_d_pressed() -> void:
	AsdaInventory.add_money_low(-1000000000)


func _on_c_pressed() -> void:
	AsdaInventory.add_money_low(1000000000)


func _on_b_pressed() -> void:
	AsdaInventory.add_money_low(10000)


func _on_a_pressed() -> void:
	AsdaInventory.add_money_low(-10000)
