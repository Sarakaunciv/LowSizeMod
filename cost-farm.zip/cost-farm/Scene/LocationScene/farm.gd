extends Node2D

var scene_id: int = 1

func _ready() -> void:
	farm_tile_build()

var farm_tile = load("res://Script/Main/Farm/farm_tile.tscn")
@onready var farm_tile_0: Node2D = $farm_tile_0
func farm_tile_build():
	if FileAccess.file_exists("res://Scene/SaveScene/farm.tres"):
		var data = ResourceLoader.load("res://Scene/SaveScene/farm.tres") as zzzz_resource
		for del0 in data.farm_tile_0:
			var del0tile = del0.instantiate()
			farm_tile_0.call_deferred("add_child", del0tile)
			del0tile._ready()
	else:
		for del0x in range(20):
			for del0y in range(10):
				var del0tile = farm_tile.instantiate()
				if del0x % 2 == del0y % 2:
					del0tile.is_dark = false
				else:
					del0tile.is_dark = true
				farm_tile_0.call_deferred("add_child", del0tile)
				del0tile.position = Vector2(del0x * AaaaGlobal.tile_size0, del0y * AaaaGlobal.tile_size0)

func _on_button_pressed() -> void:
	AsasManager.add_day(1)
