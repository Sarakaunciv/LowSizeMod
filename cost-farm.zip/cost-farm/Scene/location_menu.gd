extends Control

func _ready() -> void:
	pass

func _on_farm_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/LocationScene/farm.tscn")

func _on_shop_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/LocationScene/shop.tscn")

func _on_house_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/LocationScene/house.tscn")

func _on_mine_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/LocationScene/mine.tscn")

	#get_tree().change_scene_to_file()
