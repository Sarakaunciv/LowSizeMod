extends Control

func _ready() -> void:
	pass

func _on_farm_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/LocationScene/farm.tscn")

func _on_shop_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/LocationScene/shop.tscn")

	#get_tree().change_scene_to_file()
