extends Button

@export var is_eneble: bool = false

func _ready() -> void:
	parent.disable0.connect(disable)
	action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS
	update0()

@onready var sprite_2d: Sprite2D = $Sprite2D
func update0():
	if is_eneble == true:
		sprite_2d.region_rect.position = AaaaGlobal.atlas_green_edge
	else:
		sprite_2d.region_rect.position = AaaaGlobal.atlas_false

func disable():
	is_eneble = false
	update0()
@onready var parent: Control = $".."
func _on_pressed() -> void:
	parent.disable()
	is_eneble = true
	update0()
