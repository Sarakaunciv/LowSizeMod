extends Button

@export var is_eneble: bool = true

func _ready() -> void:
	action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS
	update0()

@onready var sprite_2d: Sprite2D = $Sprite2D
func update0():
	if is_eneble == true:
		sprite_2d.region_rect.position = AaaaGlobal.atlas_green_edge
	else:
		sprite_2d.region_rect.position = AaaaGlobal.atlas_false

func _on_pressed() -> void:
	if is_eneble == true:
		is_eneble = false
	else:
		is_eneble = true
	update0()
