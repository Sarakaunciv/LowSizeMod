extends Control

signal disable0
func disable():
	disable0.emit()
