extends Control

var scene_id: int = 0

func _ready() -> void:
	pass

func _on_continue_pressed() -> void:
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		get_tree().change_scene_to_file("res://Scene/LocationScene/house.tscn")

@onready var user_interface: Node2D = $user_interface
func _on_new_game_pressed() -> void:
	var del0 = DirAccess.open("res://Scene/SaveScene/")
	if FileAccess.file_exists("res://Scene/SaveScene/farm.tres"):
		del0.remove("farm.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/river.tres"):
		del0.remove("river.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		del0.remove("inv.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/people.tres"):
		del0.remove("people.tres")
	var del0people = get_tree().get_nodes_in_group("people")
	for del1 in del0people:
		del1.queue_free()
	await get_tree().process_frame #safe
	reset0()
	get_work_id()
	get_work_lvl()
	start0()
	start1()
	start2()
	await get_tree().process_frame
	user_interface._on_location_pressed()

@onready var farmer: Button = $option/people/start_work_id/farmer
@onready var fisher: Button = $option/people/start_work_id/fisher
@onready var miner: Button = $option/people/start_work_id/miner
@onready var wooder: Button = $option/people/start_work_id/wooder
var work_id: int = 0
func get_work_id():
	if farmer.is_eneble == true:
		work_id = AaaaGlobal.id_people_work_farmer
	elif fisher.is_eneble == true:
		work_id = AaaaGlobal.id_people_work_fisher
	elif miner.is_eneble == true:
		work_id = AaaaGlobal.id_people_work_miner
	elif wooder.is_eneble == true:
		work_id = AaaaGlobal.id_people_work_wooder
@onready var start_work_lvl: Control = $option/people/start_work_lvl
var work_lvl: int = 0
func get_work_lvl():
	if start_work_lvl.del_count > 4 or start_work_lvl.del_power > 0:
		work_lvl = 4
	else:
		work_lvl = start_work_lvl.del_count - 1

var difficulty: int = 1
func start0():
# stat ################################################################
# time
	AsdaInventory.time_day = 0
	AsdaInventory.time_day += 0 * AaaaGlobal.time_day_in_month
	AsdaInventory.time_day += 18 * AaaaGlobal.time_day_in_year
# money ################################################################
	match work_lvl:
		0:
			AsdaInventory.add_money_low(AaaaGlobal.start_money)
		1:
			AsdaInventory.add_money_low(AaaaGlobal.start_money * (AaaaGlobal.money_work_lvl_multiplier ** 1))
		2:
			AsdaInventory.add_money_low(AaaaGlobal.start_money * (AaaaGlobal.money_work_lvl_multiplier ** 2))
		3:
			AsdaInventory.add_money_low(AaaaGlobal.start_money * (AaaaGlobal.money_work_lvl_multiplier ** 3))
		4:
			AsdaInventory.add_money_low(AaaaGlobal.start_money * (AaaaGlobal.money_work_lvl_multiplier ** 4))
# item
	match work_id:
		AaaaGlobal.id_people_work_farmer:
# plant ################################################################
			AsdaInventory.karat = 10
			AsdaInventory.karat_seed = 40
			
			AsdaInventory.tamaso = 2
			AsdaInventory.tamaso_seed = 10
# fert ################################################################
			AsdaInventory.fert_speed_low = 5
			AsdaInventory.fert_speed_mid = 0
			AsdaInventory.fert_speed_high = 0
			AsdaInventory.fert_speed_max = 0
			
			AsdaInventory.fert_size_low = 0
			AsdaInventory.fert_size_mid = 0
			AsdaInventory.fert_size_high = 0
			AsdaInventory.fert_size_max = 0
# ect ################################################################
			AsdaInventory.shovel = 1
			AsdaInventory.axe = 1
			
			AsdaInventory.wood = 20
# fish ################################################################
			AsdaInventory.bait = 0
			AsdaInventory.fish_rod = 1
			AsdaInventory.crab_pot = 0
			AsdaInventory.fish = 0
			AsdaInventory.crab = 0
# mineral ################################################################
			AsdaInventory.stone = 20
			
			AsdaInventory.cese = 0
			AsdaInventory.cese_pick = 0
			AsdaInventory.cese_knife = 0
			AsdaInventory.cese_shield = 0
# permit ################################################################
			AsdaInventory.permit_farm = 1
			AsdaInventory.permit_mine = 0
			AsdaInventory.permit_wood = 1
			AsdaInventory.permit_fish = 1
			AsdaInventory.permit_crab = 0
		AaaaGlobal.id_people_work_fisher:
# ect ################################################################
			AsdaInventory.axe = 1
			
			AsdaInventory.wood = 20
# fish ################################################################
			AsdaInventory.bait = 20
			AsdaInventory.fish_rod = 1
			AsdaInventory.crab_pot = 10
			AsdaInventory.fish = 3
			AsdaInventory.crab = 5
# mineral ################################################################
			AsdaInventory.stone = 20
# permit ################################################################
			AsdaInventory.permit_wood = 1
			AsdaInventory.permit_fish = 1
			AsdaInventory.permit_crab = 1
		AaaaGlobal.id_people_work_miner:
# plant ################################################################
			AsdaInventory.karat = 20
# ect ################################################################
			AsdaInventory.axe = 1
			
			AsdaInventory.wood = 20
# mineral ################################################################
			AsdaInventory.stone = 40
			
			AsdaInventory.cese = 10
			AsdaInventory.cese_pick = 1
			AsdaInventory.cese_knife = 0
			AsdaInventory.cese_shield = 1
# permit ################################################################
			AsdaInventory.permit_mine = 1
		AaaaGlobal.id_people_work_wooder:
# plant ################################################################
			AsdaInventory.karat = 20
# ect ################################################################
			AsdaInventory.axe = 4
			
			AsdaInventory.wood = 40
# mineral ################################################################
			AsdaInventory.stone = 20
# permit ################################################################
			AsdaInventory.permit_wood = 2
func start1():
# stat ################################################################
# time
	AsdaInventory.time_min = 0
	AsdaInventory.time_hour = 6
# health
	AsdaInventory.health_max = 1000000
	AsdaInventory.health = 1000000
# food
	AsdaInventory.food_max = 3000
	AsdaInventory.food = 3000
# energy
	AsdaInventory.energy_max = 1440
	AsdaInventory.energy = 1440
# ect ################################################################
	AsdaInventory.mine_floor = 0
	AsdaInventory.mine_floor_max = 0

@onready var dad: Button = $option/people/start_people/dad
@onready var gdad1: Button = $option/people/start_people/gdad1
@onready var gdad2: Button = $option/people/start_people/gdad2
@onready var mom: Button = $option/people/start_people/mom
@onready var gmom1: Button = $option/people/start_people/gmom1
@onready var gmom2: Button = $option/people/start_people/gmom2
var ple_a_pr_min: int = 0
var ple_a_pr_max: int = 0
var ple_a_pr_g_min: int = 0
var ple_a_pr_g_max: int = 0
func start2():
	ple_a_pr_min = AsdaInventory.time_day + AaaaGlobal.people_age_parent_min
	ple_a_pr_max = AsdaInventory.time_day + AaaaGlobal.people_age_parent_max
	ple_a_pr_g_min = AsdaInventory.time_day + AaaaGlobal.people_age_parent_min + AaaaGlobal.people_age_parent_g_gap
	ple_a_pr_g_max = AsdaInventory.time_day + AaaaGlobal.people_age_parent_max + AaaaGlobal.people_age_parent_g_gap
	if dad.is_eneble == true:
		AsasManager.build_people("dad", randi_range(ple_a_pr_min, ple_a_pr_max), work_id, work_lvl)
	if gdad1.is_eneble == true:
		AsasManager.build_people("gdad1", randi_range(ple_a_pr_g_min, ple_a_pr_g_max), work_id, work_lvl)
	if gdad2.is_eneble == true:
		AsasManager.build_people("gdad2", randi_range(ple_a_pr_g_min, ple_a_pr_g_max), work_id, work_lvl)
	if mom.is_eneble == true:
		AsasManager.build_people("mom", randi_range(ple_a_pr_min, ple_a_pr_max), work_id, work_lvl)
	if gmom1.is_eneble == true:
		AsasManager.build_people("gmom1", randi_range(ple_a_pr_g_min, ple_a_pr_g_max), work_id, work_lvl)
	if gmom2.is_eneble == true:
		AsasManager.build_people("gmom2", randi_range(ple_a_pr_g_min, ple_a_pr_g_max), work_id, work_lvl)

func reset0():
# stat ################################################################
# time
	AsdaInventory.time_min = 0
	AsdaInventory.time_hour = 0
	AsdaInventory.time_day = 0
# health
	AsdaInventory.health_max = 0
	AsdaInventory.health = 0
# food
	AsdaInventory.food_max = 0
	AsdaInventory.food = 0
# energy
	AsdaInventory.energy_max = 0
	AsdaInventory.energy = 0
# ect ################################################################
	AsdaInventory.mine_floor = 0
	AsdaInventory.mine_floor_max = 0
# money ################################################################
	AsdaInventory.money_low = 0
	AsdaInventory.money_mid = 0
	AsdaInventory.money_high = 0
	AsdaInventory.money_max = 0
# item
# plant ################################################################
	AsdaInventory.karat = 0
	AsdaInventory.karat_seed = 0
	
	AsdaInventory.tamaso = 0
	AsdaInventory.tamaso_seed = 0
	
	AsdaInventory.patrak = 0
	AsdaInventory.patrak_seed = 0
	
	AsdaInventory.apos = 0
	AsdaInventory.apos_seed = 0
	
	AsdaInventory.whaat = 0
	AsdaInventory.whaat_seed = 0
	
	AsdaInventory.garn = 0
	AsdaInventory.garn_seed = 0
	
	AsdaInventory.graize_frizet = 0
	AsdaInventory.graize_frizet_seed = 0
	
	AsdaInventory.yume_karst_faw = 0
	AsdaInventory.yume_karst_faw_seed = 0
# fert ################################################################
	AsdaInventory.fert_speed_low = 0
	AsdaInventory.fert_speed_mid = 0
	AsdaInventory.fert_speed_high = 0
	AsdaInventory.fert_speed_max = 0
	
	AsdaInventory.fert_size_low = 0
	AsdaInventory.fert_size_mid = 0
	AsdaInventory.fert_size_high = 0
	AsdaInventory.fert_size_max = 0
# ect ################################################################
	AsdaInventory.shovel = 0
	AsdaInventory.axe = 0
	
	AsdaInventory.wood = 0
# fish ################################################################
	AsdaInventory.bait = 0
	AsdaInventory.fish_rod = 0
	AsdaInventory.crab_pot = 0
	AsdaInventory.fish = 0
	AsdaInventory.crab = 0
# mineral ################################################################
	AsdaInventory.stone = 0
	
	AsdaInventory.cese = 0
	AsdaInventory.cese_pick = 0
	AsdaInventory.cese_knife = 0
	AsdaInventory.cese_shield = 0
	
	AsdaInventory.lowaral = 0
	AsdaInventory.lowaral_pick = 0
	AsdaInventory.lowaral_knife = 0
	AsdaInventory.lowaral_shield = 0
	
	AsdaInventory.iena = 0
	AsdaInventory.iena_pick = 0
	AsdaInventory.iena_knife = 0
	AsdaInventory.iena_shield = 0
	
	AsdaInventory.midaral = 0
	AsdaInventory.midaral_pick = 0
	AsdaInventory.midaral_knife = 0
	AsdaInventory.midaral_shield = 0
	
	AsdaInventory.graize = 0
	AsdaInventory.graize_pick = 0
	AsdaInventory.graize_knife = 0
	AsdaInventory.graize_shield = 0
	
	AsdaInventory.higaral = 0
	AsdaInventory.higaral_pick = 0
	AsdaInventory.higaral_knife = 0
	AsdaInventory.higaral_shield = 0
	
	AsdaInventory.adanto = 0
	AsdaInventory.adanto_pick = 0
	AsdaInventory.adanto_knife = 0
	AsdaInventory.adanto_shield = 0
	
	AsdaInventory.maxaral = 0
	AsdaInventory.maxaral_pick = 0
	AsdaInventory.maxaral_knife = 0
	AsdaInventory.maxaral_shield = 0
# permit ################################################################
	AsdaInventory.permit_farm = 0
	AsdaInventory.permit_mine = 0
	AsdaInventory.permit_wood = 0
	AsdaInventory.permit_fish = 0
	AsdaInventory.permit_crab = 0
