extends Control

var scene_id: int = 0

func _ready() -> void:
	pass

func _on_continue_pressed() -> void:
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		get_tree().change_scene_to_file("res://Scene/LocationScene/house.tscn")

@onready var user_interface: Node2D = $user_interface
var difficulty: int = 1
func _on_new_game_pressed() -> void:
	var del0 = DirAccess.open("res://Scene/SaveScene/")
	if FileAccess.file_exists("res://Scene/SaveScene/farm.tres"):
		del0.remove("farm.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/river.tres"):
		del0.remove("river.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/inv.tres"):
		del0.remove("inv.tres")
	if FileAccess.file_exists("res://Scene/SaveScene/people.tres"):
		del0.remove("people.tres")
	reset0()
	start0()
	start1()
	start2()
	await get_tree().process_frame
	user_interface._on_location_pressed()
	#get_tree().change_scene_to_file("res://Scene/LocationScene/house.tscn")

func start0():
	match difficulty:
		1:
# stat ################################################################
# time
			AsdaInventory.time_day = 0
			AsdaInventory.time_day += 0 * AaaaGlobal.time_day_in_month
			AsdaInventory.time_day += 18 * AaaaGlobal.time_day_in_year
# money ################################################################
			AsdaInventory.money_low = 150
			AsdaInventory.money_mid = 0
			AsdaInventory.money_high = 0
			AsdaInventory.money_max = 0
# item
# plant ################################################################
			AsdaInventory.karat = 10
			AsdaInventory.karat_seed = 40
			
			AsdaInventory.tamaso = 2
			AsdaInventory.tamaso_seed = 10
# fert ################################################################
			AsdaInventory.fert_speed_low = 5
			AsdaInventory.fert_speed_mid = 0
			AsdaInventory.fert_speed_high = 0
			AsdaInventory.fert_speed_max = 0
			
			AsdaInventory.fert_size_low = 0
			AsdaInventory.fert_size_mid = 0
			AsdaInventory.fert_size_high = 0
			AsdaInventory.fert_size_max = 0
# ect ################################################################
			AsdaInventory.shovel = 1
			AsdaInventory.axe = 1
			
			AsdaInventory.wood = 20
# fish ################################################################
			AsdaInventory.bait = 0
			AsdaInventory.fish_rod = 1
			AsdaInventory.crab_pot = 0
			AsdaInventory.fish = 0
			AsdaInventory.crab = 0
# mineral ################################################################
			AsdaInventory.stone = 20
			
			AsdaInventory.cese = 0
			AsdaInventory.cese_pick = 0
			AsdaInventory.cese_knife = 0
			AsdaInventory.cese_shield = 0
# permit ################################################################
			AsdaInventory.permit_farm = 1
			AsdaInventory.permit_mine = 0
			AsdaInventory.permit_wood = 1
			AsdaInventory.permit_fish = 1
			AsdaInventory.permit_crab = 0
func start1():
# stat ################################################################
# time
	AsdaInventory.time_min = 0
	AsdaInventory.time_hour = 6
# health
	AsdaInventory.health_max = 1000000
	AsdaInventory.health = 1000000
# food
	AsdaInventory.food_max = 3000
	AsdaInventory.food = 3000
# energy
	AsdaInventory.energy_max = 1440
	AsdaInventory.energy = 1440
# ect ################################################################
	AsdaInventory.mine_floor = 0
	AsdaInventory.mine_floor_max = 0

@onready var dad: Button = $option/people/dad
@onready var gdad1: Button = $option/people/gdad1
@onready var gdad2: Button = $option/people/gdad2
@onready var mom: Button = $option/people/mom
@onready var gmom1: Button = $option/people/gmom1
@onready var gmom2: Button = $option/people/gmom2
func start2():
	if dad.is_eneble == true:
		AsasManager.build_people("dad", randi_range(14400, 18000), 10)
	if gdad1.is_eneble == true:
		AsasManager.build_people("gdad1", randi_range(14400 * 2, 18000 * 2), 5)
	if gdad2.is_eneble == true:
		AsasManager.build_people("gdad2", randi_range(14400 * 2, 18000 * 2), 5)
	if mom.is_eneble == true:
		AsasManager.build_people("mom", randi_range(14400, 18000), 10)
	if gmom1.is_eneble == true:
		AsasManager.build_people("gmom1", randi_range(14400 * 2, 18000 * 2), 5)
	if gmom2.is_eneble == true:
		AsasManager.build_people("gmom2", randi_range(14400 * 2, 18000 * 2), 5)

func reset0():
# stat ################################################################
# time
	AsdaInventory.time_min = 0
	AsdaInventory.time_hour = 0
	AsdaInventory.time_day = 0
# health
	AsdaInventory.health_max = 0
	AsdaInventory.health = 0
# food
	AsdaInventory.food_max = 0
	AsdaInventory.food = 0
# energy
	AsdaInventory.energy_max = 0
	AsdaInventory.energy = 0
# ect ################################################################
	AsdaInventory.mine_floor = 0
	AsdaInventory.mine_floor_max = 0
# money ################################################################
	AsdaInventory.money_low = 0
	AsdaInventory.money_mid = 0
	AsdaInventory.money_high = 0
	AsdaInventory.money_max = 0
# item
# plant ################################################################
	AsdaInventory.karat = 0
	AsdaInventory.karat_seed = 0
	
	AsdaInventory.tamaso = 0
	AsdaInventory.tamaso_seed = 0
	
	AsdaInventory.patrak = 0
	AsdaInventory.patrak_seed = 0
	
	AsdaInventory.apos = 0
	AsdaInventory.apos_seed = 0
	
	AsdaInventory.whaat = 0
	AsdaInventory.whaat_seed = 0
	
	AsdaInventory.garn = 0
	AsdaInventory.garn_seed = 0
	
	AsdaInventory.graize_frizet = 0
	AsdaInventory.graize_frizet_seed = 0
	
	AsdaInventory.yume_karst_faw = 0
	AsdaInventory.yume_karst_faw_seed = 0
# fert ################################################################
	AsdaInventory.fert_speed_low = 0
	AsdaInventory.fert_speed_mid = 0
	AsdaInventory.fert_speed_high = 0
	AsdaInventory.fert_speed_max = 0
	
	AsdaInventory.fert_size_low = 0
	AsdaInventory.fert_size_mid = 0
	AsdaInventory.fert_size_high = 0
	AsdaInventory.fert_size_max = 0
# ect ################################################################
	AsdaInventory.shovel = 0
	AsdaInventory.axe = 0
	
	AsdaInventory.wood = 0
# fish ################################################################
	AsdaInventory.bait = 0
	AsdaInventory.fish_rod = 0
	AsdaInventory.crab_pot = 0
	AsdaInventory.fish = 0
	AsdaInventory.crab = 0
# mineral ################################################################
	AsdaInventory.stone = 0
	
	AsdaInventory.cese = 0
	AsdaInventory.cese_pick = 0
	AsdaInventory.cese_knife = 0
	AsdaInventory.cese_shield = 0
	
	AsdaInventory.lowaral = 0
	AsdaInventory.lowaral_pick = 0
	AsdaInventory.lowaral_knife = 0
	AsdaInventory.lowaral_shield = 0
	
	AsdaInventory.iena = 0
	AsdaInventory.iena_pick = 0
	AsdaInventory.iena_knife = 0
	AsdaInventory.iena_shield = 0
	
	AsdaInventory.midaral = 0
	AsdaInventory.midaral_pick = 0
	AsdaInventory.midaral_knife = 0
	AsdaInventory.midaral_shield = 0
	
	AsdaInventory.graize = 0
	AsdaInventory.graize_pick = 0
	AsdaInventory.graize_knife = 0
	AsdaInventory.graize_shield = 0
	
	AsdaInventory.higaral = 0
	AsdaInventory.higaral_pick = 0
	AsdaInventory.higaral_knife = 0
	AsdaInventory.higaral_shield = 0
	
	AsdaInventory.adanto = 0
	AsdaInventory.adanto_pick = 0
	AsdaInventory.adanto_knife = 0
	AsdaInventory.adanto_shield = 0
	
	AsdaInventory.maxaral = 0
	AsdaInventory.maxaral_pick = 0
	AsdaInventory.maxaral_knife = 0
	AsdaInventory.maxaral_shield = 0
# permit ################################################################
	AsdaInventory.permit_farm = 0
	AsdaInventory.permit_mine = 0
	AsdaInventory.permit_wood = 0
	AsdaInventory.permit_fish = 0
	AsdaInventory.permit_crab = 0
