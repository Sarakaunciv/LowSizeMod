﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories
{
    public class ArachnaFlameCharm : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 30;
            Item.height = 30;
            Item.defense = 45;
            Item.value = Item.buyPrice(5, 0, 0, 0);
            Item.rare = ItemRarityID.Yellow;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.lifeRegen += 5;
            
			player.pStone = true;
			
            player.longInvince = true;
			
            player.fireWalk = true;
			
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.Webbed] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.OnFire3] = true;
            player.buffImmune[BuffID.Chilled] = true;
            player.buffImmune[BuffID.Frozen] = true;
            player.buffImmune[BuffID.Frostburn] = true;
            player.buffImmune[BuffID.Frostburn2] = true;
            player.buffImmune[BuffID.CursedInferno] = true;
            player.buffImmune[BuffID.ShadowFlame] = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.CharmofMyths, 1)
				.AddIngredient(ItemID.CrossNecklace, 1)
				.AddIngredient(ItemID.ShadowFlameKnife, 1)
				.AddIngredient(ItemID.HellstoneBar, 20)
				.AddIngredient(ItemID.IceBlock, 100)
				.AddIngredient(ItemID.CursedFlame, 20)
				.AddIngredient(ItemID.SpiderFang, 20)
				.AddTile(TileID.MythrilAnvil)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.CharmofMyths, 1)
				.AddIngredient(ItemID.CrossNecklace, 1)
				.AddIngredient(ItemID.ShadowFlameBow, 1)
				.AddIngredient(ItemID.HellstoneBar, 20)
				.AddIngredient(ItemID.IceBlock, 100)
				.AddIngredient(ItemID.CursedFlame, 20)
				.AddIngredient(ItemID.SpiderFang, 20)
				.AddTile(TileID.MythrilAnvil)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.CharmofMyths, 1)
				.AddIngredient(ItemID.CrossNecklace, 1)
				.AddIngredient(ItemID.ShadowFlameHexDoll, 1)
				.AddIngredient(ItemID.HellstoneBar, 20)
				.AddIngredient(ItemID.IceBlock, 100)
				.AddIngredient(ItemID.CursedFlame, 20)
				.AddIngredient(ItemID.SpiderFang, 20)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
