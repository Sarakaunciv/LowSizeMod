﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories.BUF;
using Kadrill.Accessories;

namespace Kadrill.Accessories
{
    public class PlateNebula : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 26;
            Item.height = 26;
            Item.defense = 20;
            Item.value = Item.buyPrice(10, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.AddBuff(ModContent.BuffType<EffectNebula>(), 5);
			
            player.buffImmune[BuffID.ManaSickness] = true;
            player.statManaMax2 *= 8;
            player.manaFlower = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.FragmentNebula, 40)
				.AddIngredient(ItemID.LunarBar, 40)
				.AddIngredient<StellarTablet>()
				.AddTile(TileID.LunarCraftingStation)
				.Register();
		}
    }
}
