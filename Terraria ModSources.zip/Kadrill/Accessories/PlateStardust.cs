﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories.BUF;
using Kadrill.Accessories;

namespace Kadrill.Accessories
{
    public class PlateStardust : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 26;
            Item.height = 26;
            Item.defense = 10;
            Item.value = Item.buyPrice(10, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.AddBuff(ModContent.BuffType<EffectStardust>(), 5);
			
            player.AddBuff(ModContent.BuffType<BigHive>(), 5);
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.FragmentStardust, 40)
				.AddIngredient(ItemID.LunarBar, 40)
				.AddIngredient<LargeHive>()
				.AddTile(TileID.LunarCraftingStation)
				.Register();
		}
    }
}
