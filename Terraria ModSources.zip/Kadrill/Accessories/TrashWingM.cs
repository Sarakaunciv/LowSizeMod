﻿using Kadrill.Accessories.BUF;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Kadrill.Accessories
{
    public class TrashWingM : ModMount
    {
        public override void SetStaticDefaults()
        {
            MountData.spawnDust = 1;
            MountData.spawnDustNoGravity = true;
            MountData.buff = ModContent.BuffType<TrashWingB>();
            MountData.heightBoost = 0;
            MountData.flightTimeMax = int.MaxValue;
            MountData.fatigueMax = int.MaxValue;
            MountData.fallDamage = 0f;
            MountData.usesHover = true;
            MountData.runSpeed = 12f;
            MountData.dashSpeed = 12f;
            MountData.acceleration = 1f;
            MountData.swimSpeed = 12f;
            MountData.jumpHeight = 8;
            MountData.jumpSpeed = 8f;
            MountData.blockExtraJumps = true;
            MountData.totalFrames = 5;

            int[] verticalOffsets = new int[MountData.totalFrames];
            for (int l = 0; l < verticalOffsets.Length; l++)
                verticalOffsets[l] = 0;

            MountData.playerYOffsets = verticalOffsets;
            MountData.xOffset = -8;
            MountData.bodyFrame = 5;
            MountData.yOffset = 0;
            MountData.playerHeadOffset = 0;
            MountData.standingFrameCount = 5;
            MountData.standingFrameDelay = 5;
            MountData.standingFrameStart = 0;
            MountData.runningFrameCount = 5;
            MountData.runningFrameDelay = 5;
            MountData.runningFrameStart = 0;
            MountData.flyingFrameCount = 5;
            MountData.flyingFrameDelay = 5;
            MountData.flyingFrameStart = 0;
            MountData.inAirFrameCount = 5;
            MountData.inAirFrameDelay = 5;
            MountData.inAirFrameStart = 0;
            MountData.idleFrameCount = 5;
            MountData.idleFrameDelay = 5;
            MountData.idleFrameStart = 0;
            MountData.idleFrameLoop = true;
            MountData.swimFrameCount = 5;
            MountData.swimFrameDelay = 5;
            MountData.swimFrameStart = 0;
            if (Main.netMode != NetmodeID.Server)
            {
                MountData.textureWidth = MountData.backTexture.Width();
                MountData.textureHeight = MountData.backTexture.Height();
            }
        }

        public override bool Draw(List<DrawData> playerDrawData, int drawType, Player drawPlayer, ref Texture2D texture, ref Texture2D glowTexture, ref Vector2 drawPosition, ref Rectangle frame, ref Color drawColor, ref Color glowColor, ref float rotation, ref SpriteEffects spriteEffects, ref Vector2 drawOrigin, ref float drawScale, float shadow)
        {
            rotation = drawPlayer.velocity.X * 0.004f;
            drawPlayer.fullRotation = rotation;
            frame = texture.Frame(1, 5, 0, (int)(Main.GlobalTimeWrappedHourly * 13f) % 5);
            return true;
        }
    }
}
