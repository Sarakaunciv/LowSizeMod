﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class NiNightsEdge : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.NightsEdge);
			
            Item.damage *= 3;
            Item.value = Item.buyPrice(0, 20, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            if (player.altFunctionUse == 2)
            {
            }
            else
            {
                float adjustedItemScale = Item.scale;
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 4f, player.itemAnimationMax * 2f, adjustedItemScale * 1.5f);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 3.6f, player.itemAnimationMax * 1.8f, adjustedItemScale * 1.4f);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 3.2f, player.itemAnimationMax * 1.6f, adjustedItemScale * 1.3f);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2.8f, player.itemAnimationMax * 1.4f, adjustedItemScale * 1.2f);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2.4f, player.itemAnimationMax * 1.2f, adjustedItemScale * 1.1f);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2f, player.itemAnimationMax, adjustedItemScale);
                NetMessage.SendData(MessageID.PlayerControls, -1, -1, null, player.whoAmI);
            }

            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.NightsEdge, 1)
				.AddIngredient(ItemID.Muramasa, 8)
				.AddTile(TileID.Anvils)
				.Register();
		}
    }
}
