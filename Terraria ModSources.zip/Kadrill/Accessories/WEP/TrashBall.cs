﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Kadrill.Accessories.WEP;
using Kadrill.Accessories.CRA;

namespace Kadrill.Accessories.WEP
{
    public class TrashBall : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
            Item.width = 8;
            Item.height = 28;
            Item.damage = 80;
            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
			
            Item.useTime = Item.useAnimation = 5;
            Item.shootSpeed = 25f;
            Item.shoot = ModContent.ProjectileType<TrashBallP>();
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Swing;
            Item.noMelee = true;
            Item.noUseGraphic = true;
            Item.UseSound = SoundID.Item1;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<RecycledTrash>(1000)
				.AddTile(TileID.Anvils)
				.Register();
		}
    }
}
