﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class HellStorm : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.Flamethrower);
			
            Item.width = 70;
            Item.height = 70;
            Item.damage *= 30;
            Item.DamageType = DamageClass.Ranged;
            Item.knockBack = 5f;
            Item.value = Item.buyPrice(0, 50, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }
		
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 destination = player.MountedCenter;
            position = destination;
            Vector2 cachedPosition = position;
            float maxRandomOffset = 80f;
            int totalProjectiles = 3;
            for (int i = 0; i < totalProjectiles; i++)
            {
                position.X += MathHelper.Lerp(0f, 0f, i / (float)(totalProjectiles - 1));
                velocity = ((Main.MouseWorld + Main.rand.NextVector2Circular(maxRandomOffset, maxRandomOffset)) - position).SafeNormalize(Vector2.UnitY) * (Item.shootSpeed * 2);
                Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI);
                position = cachedPosition;
            }
            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.Flamethrower, 1)
				.AddIngredient(ItemID.ChlorophyteBar, 24)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
