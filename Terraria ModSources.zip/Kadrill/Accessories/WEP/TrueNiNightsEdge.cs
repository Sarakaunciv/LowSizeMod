﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class TrueNiNightsEdge : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.TrueNightsEdge);
			
            Item.damage *= 3;
            Item.value = Item.buyPrice(0, 50, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }
		
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 destination = player.MountedCenter;
            position = destination;
            Vector2 cachedPosition = position;
            float adjustedItemScale = Item.scale;
			
            Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2, player.itemAnimationMax, adjustedItemScale * 1.2f);
            Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2, player.itemAnimationMax, adjustedItemScale);
            Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.NightsEdge, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2, player.itemAnimationMax, adjustedItemScale * 0.8f);
				
            velocity = (Main.MouseWorld - position).SafeNormalize(Vector2.UnitY) * 20f;
            Projectile.NewProjectile(source, position, velocity, ProjectileID.TrueNightsEdge, damage * 3, knockback, player.whoAmI, (float)player.direction * player.gravDir, player.itemAnimationMax, adjustedItemScale * 1.2f);

            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<NiNightsEdge>()
				.AddIngredient(ItemID.SoulofFright, 27)
				.AddIngredient(ItemID.SoulofMight, 27)
				.AddIngredient(ItemID.SoulofSight, 27)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
