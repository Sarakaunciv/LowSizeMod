﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class TrashBallP : ModProjectile, ILocalizedModType
    {
        public new string LocalizationCategory => "Projectiles";
		
        public override void SetDefaults()
        {
			Projectile.CloneDefaults(ProjectileID.RottenEgg);
			
            Projectile.friendly = true;
            Projectile.hostile = true;
            Projectile.penetrate = -1;
            Projectile.timeLeft = 300;
        }
    }
}
