﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Kadrill.Accessories.WEP;

namespace Kadrill.Accessories.WEP
{
    public class Akai : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
            Item.width = 64;
            Item.height = 64;
            Item.damage = 6640;
            Item.useTime = 10;
            Item.useAnimation = 10;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.useTurn = false;
            Item.DamageType = DamageClass.Melee;
            Item.mana = 200;
            Item.knockBack = 15f;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
            Item.noMelee = true;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Lime;
            Item.shoot = ModContent.ProjectileType<AkaiP>();
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
                float adjustedItemScale = Item.scale;
            if (player.altFunctionUse == 2)
            {
            }
            else
            {
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ModContent.ProjectileType<AkaiP>(), damage * 2, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2f, player.itemAnimationMax * 2f, adjustedItemScale * 1.5f);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ModContent.ProjectileType<AkaiP2>(), damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2f, player.itemAnimationMax * 3f, adjustedItemScale);
                NetMessage.SendData(MessageID.PlayerControls, -1, -1, null, player.whoAmI);
            }

            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.BrokenHeroSword, 1)
				.AddIngredient(ItemID.FragmentSolar, 500)
				.AddIngredient(ItemID.LunarBar, 60)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
