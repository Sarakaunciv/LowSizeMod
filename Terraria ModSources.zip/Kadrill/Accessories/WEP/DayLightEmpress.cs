﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class DayLightEmpress : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
            Item.width = 70;
            Item.height = 70;
            Item.DamageType = DamageClass.Ranged;
            Item.mana = 50;
            Item.damage = 500;
            Item.knockBack = 1f;
            Item.shootSpeed = 15f;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
			
            Item.useTime = 6;
			Item.useAnimation = 6;
            Item.shoot = ProjectileID.FairyQueenMagicItemShot;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Shoot;
            Item.UseSound = SoundID.Item1;
        }
		
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 destination = player.MountedCenter;
            position = destination;
            Vector2 cachedPosition = position;
            float maxRandomOffset = 160f;
            int totalProjectiles = 5;
            for (int i = 0; i < totalProjectiles; i++)
            {
                position.X += MathHelper.Lerp(0f, 0f, i / (float)(totalProjectiles - 1));
                velocity = ((Main.MouseWorld + Main.rand.NextVector2Circular(maxRandomOffset, maxRandomOffset)) - position).SafeNormalize(Vector2.UnitY) * Item.shootSpeed;
                Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI);
                position = cachedPosition;
            }
            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.FairyQueenMagicItem, 1)
				.AddIngredient(ItemID.PiercingStarlight, 1)
				.AddIngredient(ItemID.RainbowWhip, 1)
				.AddIngredient(ItemID.FairyQueenRangedItem, 1)
				.AddIngredient(ItemID.HallowedBar, 1000)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
