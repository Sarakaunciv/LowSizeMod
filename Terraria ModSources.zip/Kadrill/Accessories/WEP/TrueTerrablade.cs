﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class TrueTerrablade : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.TerraBlade);
			
            Item.damage *= 3;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }
		
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 destination = player.MountedCenter;
            position = destination;
            Vector2 cachedPosition = position;
            float adjustedItemScale = Item.scale;
            int totalProjectiles = 6;
			
            Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.TerraBlade2, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2, player.itemAnimationMax, adjustedItemScale * 1.2f);
            Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.TerraBlade2, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2, player.itemAnimationMax, adjustedItemScale);
            Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.TerraBlade2, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2, player.itemAnimationMax, adjustedItemScale * 0.8f);
				
            for (int i = 0; i < totalProjectiles; i++)
            {
                position.X += MathHelper.Lerp(0f, 0f, i / (float)(totalProjectiles - 1));
                velocity = (Main.MouseWorld - position).SafeNormalize(Vector2.UnitY) * (i*4 + 50);
                Projectile.NewProjectile(source, position, velocity, ProjectileID.TerraBlade2Shot, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir, player.itemAnimationMax, adjustedItemScale + (i * 0.2f));
                position = cachedPosition;
            }
            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<TrueNiNightsEdge>()
				.AddIngredient<TrueExExcalibur>()
				.AddIngredient(ItemID.BrokenHeroSword, 9)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
