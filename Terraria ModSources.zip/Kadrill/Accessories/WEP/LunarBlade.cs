﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Kadrill.Accessories.WEP;

namespace Kadrill.Accessories.WEP
{
    public class LunarBlade : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.EmpressBlade);
            Item.width = Item.height = 48;
            Item.mana = 18;

            Item.useTime = Item.useAnimation = 20;
            Item.DamageType = DamageClass.Summon;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.autoReuse = true;
            Item.noMelee = true;
			
            Item.damage = 1800;
            Item.knockBack = 1f;
            Item.buffType = BuffID.EmpressBlade;
            Item.buffTime = 216000;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.EmpressBlade, 1)
				.AddIngredient(ItemID.LunarBar, 200)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
