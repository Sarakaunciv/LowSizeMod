﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class WarthOfDolphin : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.SDMG);
			
            Item.damage *= 2;
            Item.DamageType = DamageClass.Ranged;
            Item.knockBack = 1f;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Orange;
        }
		
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 destination = player.MountedCenter;
            position = destination + Main.rand.NextVector2Circular(10, 10);
            Vector2 cachedPosition = position;
            float maxRandomOffset = 40f;
            int totalProjectiles = 4;
            for (int i = 0; i < totalProjectiles; i++)
            {
                position.X += MathHelper.Lerp(0f, 0f, i / (float)(totalProjectiles - 1));
                velocity = ((Main.MouseWorld + Main.rand.NextVector2Circular(maxRandomOffset, maxRandomOffset)) - position).SafeNormalize(Vector2.UnitY) * (Item.shootSpeed * 2);
                Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI);
                position = cachedPosition;
            }
            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<AngerShark>()
				.AddIngredient(ItemID.SDMG, 1)
				.AddIngredient(ItemID.LunarBar, 20)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
