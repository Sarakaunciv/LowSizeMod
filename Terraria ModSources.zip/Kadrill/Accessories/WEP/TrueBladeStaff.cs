﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class TrueBladeStaff : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.Smolstar);
			
            Item.damage *= 10;
            Item.knockBack = 1f;
            Item.buffType = BuffID.Smolstar;
            Item.buffTime = 216000;
            Item.useTime = Item.useAnimation = 20;
            Item.value = Item.buyPrice(0, 50, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.Smolstar, 1)
				.AddIngredient(ItemID.BrokenHeroSword, 1)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
