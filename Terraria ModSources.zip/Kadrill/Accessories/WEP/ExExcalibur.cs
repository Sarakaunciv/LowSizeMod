﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.WEP
{
    public class ExExcalibur : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Weapons";
		
        public override void SetDefaults()
        {
			Item.CloneDefaults(ItemID.Excalibur);
			
            Item.damage *= 3;
            Item.value = Item.buyPrice(0, 23, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            if (player.altFunctionUse == 2)
            {
            }
            else
            {
                float adjustedItemScale = Item.scale;
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.Excalibur, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2f, player.itemAnimationMax, adjustedItemScale * 1.2f);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.Excalibur, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2f, player.itemAnimationMax, adjustedItemScale);
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction, 5f), ProjectileID.Excalibur, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir * 2f, player.itemAnimationMax, adjustedItemScale * 0.8f);
                NetMessage.SendData(MessageID.PlayerControls, -1, -1, null, player.whoAmI);
            }

            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.Excalibur, 1)
				.AddIngredient(ItemID.HallowedBar, 96)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
