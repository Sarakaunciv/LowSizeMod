﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories.CRA;

namespace Kadrill.Accessories
{
    public class TrashClock : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 26;
            Item.height = 26;
            Item.value = Item.buyPrice(0, 50, 0, 0);
            Item.rare = ItemRarityID.Red;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.breathCD = 0;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<RecycledTrash>(9999)
				.AddTile(TileID.Anvils)
				.Register();
		}
    }
}
