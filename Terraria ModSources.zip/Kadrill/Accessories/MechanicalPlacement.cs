﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories
{
    public class MechanicalPlacement : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 30;
            Item.height = 30;
            Item.value = Item.buyPrice(0, 10, 0, 0);
            Item.rare = ItemRarityID.Lime;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.wallSpeed += 20;
            player.tileSpeed += 5;
            player.blockRange += 10;
            player.equippedAnyTileRangeAcc = true;
            player.treasureMagnet = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.IronBar, 50)
				.AddIngredient(ItemID.FallenStar, 50)
				.AddTile(TileID.Anvils)
				.Register();
		}
    }
}
