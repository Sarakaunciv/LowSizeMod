﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories.BUF;
using Kadrill.Accessories;

namespace Kadrill.Accessories
{
    public class PlateLunar : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 26;
            Item.height = 26;
            Item.defense = 110;
            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Purple;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.AddBuff(ModContent.BuffType<EffectSolar>(), 5);
            player.AddBuff(ModContent.BuffType<EffectVortex>(), 5);
            player.AddBuff(ModContent.BuffType<EffectNebula>(), 5);
            player.AddBuff(ModContent.BuffType<EffectStardust>(), 5);
			
            player.AddBuff(BuffID.AmmoReservation, 5);
            player.AddBuff(BuffID.AmmoBox, 5);
            player.ammoCost80 = true;
            player.ammoCost75 = true;
			
            player.buffImmune[BuffID.ManaSickness] = true;
            player.statManaMax2 *= 8;
            player.manaFlower = true;
			
            player.AddBuff(ModContent.BuffType<BigHive>(), 5);
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<PlateSolar>()
				.AddIngredient<PlateVortex>()
				.AddIngredient<PlateNebula>()
				.AddIngredient<PlateStardust>()
				.AddIngredient(ItemID.LunarBar, 240)
				.AddTile(TileID.LunarCraftingStation)
				.Register();
		}
    }
}
