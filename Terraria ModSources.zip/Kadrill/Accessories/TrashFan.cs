﻿using Kadrill.Accessories.CRA;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Kadrill.Accessories
{
    [AutoloadEquip(EquipType.Wings)]
    public class TrashFan : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories.Wings";
        public override void SetStaticDefaults()
        {
            ArmorIDs.Wing.Sets.Stats[Item.wingSlot] = new WingStats(360, 12f, 3f);
        }

        public override void SetDefaults()
        {
            Item.width = 22;
            Item.height = 20;
            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
            Item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.noFallDmg = true;
            player.runAcceleration += 0.16f;
            player.moveSpeed += 1f;
            player.waterWalk = true;
        }

        public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising, ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend)
        {
            ascentWhenFalling = 1.5f;
            ascentWhenRising = 0.3f;
            maxCanAscendMultiplier = 1.5f;
            maxAscentMultiplier = 3.5f;
            constantAscend = 0.2f;
        }

        public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration)
        {
            speed = 12f;
        }

        public override void AddRecipes()
        {
            CreateRecipe(1)
				.AddIngredient(ItemID.GiantHarpyFeather, 1)
                .AddIngredient<RecycledTrash>(9999)
				.AddTile(TileID.Anvils)
                .Register();
        }
    }
}
