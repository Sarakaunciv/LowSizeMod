﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories.CRA;

namespace Kadrill.Accessories.CRA
{
    public class FishingRelic : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
        public override void SetDefaults()
        {
            Item.width = 26;
            Item.height = 26;
            Item.value = Item.buyPrice(copper: 10);
            Item.rare = ItemRarityID.Blue;
            Item.maxStack = 1;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.BottomlessBucket, 1)
				.AddIngredient(ItemID.BottomlessBucket, 1)
				.AddIngredient(ItemID.BottomlessHoneyBucket, 1)
				.AddIngredient(ItemID.SuperAbsorbantSponge, 1)
				.AddIngredient(ItemID.HoneyAbsorbantSponge, 1)
				.AddIngredient(ItemID.GoldenBugNet, 1)
				.AddIngredient(ItemID.FishFinder, 1)
				.AddTile(TileID.Anvils)
				.Register();
			CreateRecipe(1)
				.AddIngredient<RecycledTrash>(2000)
				.AddTile(TileID.Anvils)
				.Register();
		}
    }
}
