﻿using Kadrill.Accessories.CRA;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Kadrill.Accessories.CRA
{
    public class SpawnPumpking : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Misc";
        public override void SetDefaults()
        {
            Item.width = 20;
            Item.height = 30;
            Item.damage = 0;
            Item.useTime = 5;
            Item.useAnimation = 5;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.useTurn = true;
            Item.value = 0;
            Item.rare = ItemRarityID.Purple;
            Item.autoReuse = true;
            Item.consumable = false;
            Item.maxStack = 1;
        }

        public override bool? UseItem(Player player)
        {
            if (player.whoAmI == Main.myPlayer)
            {
                int x = (int)Main.MouseWorld.X - 9;
                int y = (int)Main.MouseWorld.Y - 20;

                if (Main.netMode == NetmodeID.SinglePlayer)
                    NPC.NewNPC(new EntitySource_ItemUse(player, Item), x, y, NPCID.Pumpking);

                else
                {
                    var netMessage = Mod.GetPacket();
                    netMessage.Write(x);
                    netMessage.Write(y);
                    netMessage.Send();
                }
            }
            return true;
        }

        public override void AddRecipes()
        {
			CreateRecipe(1)
				.AddIngredient(ItemID.PumpkinMoonMedallion, 1)
				.AddTile(TileID.WorkBenches)
				.Register();
        }
    }
}
