﻿using Kadrill.Accessories.CRA;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Kadrill.Accessories.CRA
{
    public class TrashDummy : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Misc";
        public override void SetDefaults()
        {
            Item.width = 20;
            Item.height = 30;
            Item.damage = 0;
            Item.useTime = 15;
            Item.useAnimation = 15;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.useTurn = true;
            Item.value = 0;
            Item.rare = ItemRarityID.Purple;
            Item.autoReuse = true;
        }

        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        public static void DeleteDummies()
        {
            foreach (NPC npc in Main.ActiveNPCs)
            {
                if (npc.type == ModContent.NPCType<TrashDummyNPC>())
                {
                    npc.life = 0;
                    npc.active = false;

                    if (Main.netMode == NetmodeID.Server)
                        NetMessage.SendData(MessageID.SyncNPC, -1, -1, null, npc.whoAmI);
                }
            }
        }

        public override bool? UseItem(Player player)
        {
            if (player.altFunctionUse == 2)
            {
                if (Main.myPlayer == player.whoAmI)
                {
                    if (Main.netMode == NetmodeID.SinglePlayer)
                        DeleteDummies();
                    else
                    {
                    }
                }
            }
            else if (player.whoAmI == Main.myPlayer)
            {
                int x = (int)Main.MouseWorld.X - 9;
                int y = (int)Main.MouseWorld.Y - 20;

                if (Main.netMode == NetmodeID.SinglePlayer)
                    NPC.NewNPC(new EntitySource_ItemUse(player, Item), x, y, ModContent.NPCType<TrashDummyNPC>());

                else
                {
                    var netMessage = Mod.GetPacket();
                    netMessage.Write(x);
                    netMessage.Write(y);
                    netMessage.Send();
                }
            }
            return true;
        }

        public override void AddRecipes()
        {
			CreateRecipe(1)
				.AddIngredient<RecycledTrash>(1000)
				.AddTile(TileID.WorkBenches)
				.Register();
				
            Recipe WepSumBst = Recipe.Create(ItemID.Smolstar);
			WepSumBst.AddIngredient(ItemID.GelBalloon, 20);
			WepSumBst.AddTile(TileID.MythrilAnvil);
            WepSumBst.Register();
			
            Recipe MisMatGra = Recipe.Create(ItemID.GrassSeeds, 9999);
			MisMatGra.AddIngredient(ItemID.Sunflower, 40);
			MisMatGra.AddIngredient(ItemID.FallenStar, 40);
			MisMatGra.AddTile(TileID.WorkBenches);
            MisMatGra.Register();
			
			
            Recipe MatLum1 = Recipe.Create(ItemID.LunarOre, 200);
			MatLum1.AddIngredient(ItemID.MoonLordTrophy);
			MatLum1.AddTile(TileID.LunarCraftingStation);
            MatLum1.Register();
			
            Recipe MatLum2 = Recipe.Create(ItemID.LunarOre, 120);
			MatLum2.AddIngredient(ItemID.GravityGlobe);
			MatLum2.AddIngredient(ItemID.SuspiciousLookingTentacle);
			MatLum2.AddIngredient(ItemID.LongRainbowTrailWings);
			MatLum2.AddTile(TileID.LunarCraftingStation);
            MatLum2.Register();
			
            Recipe MatLum3 = Recipe.Create(ItemID.LunarOre, 40);
			MatLum3.AddIngredient(ItemID.BossMaskMoonlord);
			MatLum3.AddTile(TileID.LunarCraftingStation);
            MatLum3.Register();
			
            Recipe MatLum4 = Recipe.Create(ItemID.LunarOre, 160);
			MatLum4.AddIngredient(ItemID.Meowmere);
			MatLum4.AddTile(TileID.LunarCraftingStation);
            MatLum4.Register();
			
            Recipe MatLum5 = Recipe.Create(ItemID.LunarOre, 80);
			MatLum5.AddIngredient(ItemID.Terrarian);
			MatLum5.AddTile(TileID.LunarCraftingStation);
            MatLum5.Register();
			
            Recipe MatLum6 = Recipe.Create(ItemID.LunarOre, 160);
			MatLum6.AddIngredient(ItemID.StarWrath);
			MatLum6.AddTile(TileID.LunarCraftingStation);
            MatLum6.Register();
			
            Recipe MatLum7 = Recipe.Create(ItemID.LunarOre, 80);
			MatLum7.AddIngredient(ItemID.SDMG);
			MatLum7.AddTile(TileID.LunarCraftingStation);
            MatLum7.Register();
			
            Recipe MatLum8 = Recipe.Create(ItemID.LunarOre, 80);
			MatLum8.AddIngredient(ItemID.Celeb2);
			MatLum8.AddTile(TileID.LunarCraftingStation);
            MatLum8.Register();
			
            Recipe MatLum9 = Recipe.Create(ItemID.LunarOre, 80);
			MatLum9.AddIngredient(ItemID.LastPrism);
			MatLum9.AddTile(TileID.LunarCraftingStation);
            MatLum9.Register();
			
            Recipe MatLum10 = Recipe.Create(ItemID.LunarOre, 80);
			MatLum10.AddIngredient(ItemID.LunarFlareBook);
			MatLum10.AddTile(TileID.LunarCraftingStation);
            MatLum10.Register();
			
            Recipe MatLum11 = Recipe.Create(ItemID.LunarOre, 80);
			MatLum11.AddIngredient(ItemID.RainbowCrystalStaff);
			MatLum11.AddTile(TileID.LunarCraftingStation);
            MatLum11.Register();
			
            Recipe MatLum12 = Recipe.Create(ItemID.LunarOre, 80);
			MatLum12.AddIngredient(ItemID.MoonlordTurretStaff);
			MatLum12.AddTile(TileID.LunarCraftingStation);
            MatLum12.Register();
			
            Recipe MatLum13 = Recipe.Create(ItemID.LunarOre, 40);
			MatLum13.AddIngredient(ItemID.MeowmereMinecart);
			MatLum13.AddTile(TileID.LunarCraftingStation);
            MatLum13.Register();
			
            Recipe MatLum14 = Recipe.Create(ItemID.LunarOre, 40);
			MatLum14.AddIngredient(ItemID.MoonLordPetItem);
			MatLum14.AddTile(TileID.LunarCraftingStation);
            MatLum14.Register();
			
            Recipe MatGel1 = Recipe.Create(ItemID.Gel, 1000);
			MatGel1.AddIngredient(ItemID.KingSlimeTrophy);
			MatGel1.AddTile(TileID.Solidifier);
            MatGel1.Register();
			
            Recipe MatGel2 = Recipe.Create(ItemID.Gel, 400);
			MatGel2.AddIngredient(ItemID.KingSlimeMask);
			MatGel2.AddTile(TileID.Solidifier);
            MatGel2.Register();
			
            Recipe MatGel3 = Recipe.Create(ItemID.Gel, 400);
			MatGel3.AddIngredient(ItemID.KingSlimePetItem);
			MatGel3.AddTile(TileID.Solidifier);
            MatGel3.Register();
			
            Recipe MatGel4 = Recipe.Create(ItemID.Gel, 200);
			MatGel4.AddIngredient(ItemID.SlimySaddle);
			MatGel4.AddTile(TileID.Solidifier);
            MatGel4.Register();
			
            Recipe MatGel5 = Recipe.Create(ItemID.Gel, 200);
			MatGel5.AddIngredient(ItemID.SlimySaddle);
			MatGel5.AddTile(TileID.Solidifier);
            MatGel5.Register();
			
            Recipe MatGel6 = Recipe.Create(ItemID.Gel, 200);
			MatGel6.AddIngredient(ItemID.SlimeGun);
			MatGel6.AddTile(TileID.Solidifier);
            MatGel6.Register();
			
            Recipe MatGel7 = Recipe.Create(ItemID.Gel, 200);
			MatGel7.AddIngredient(ItemID.SlimeHook);
			MatGel7.AddTile(TileID.Solidifier);
            MatGel7.Register();
			
            Recipe MatGel8 = Recipe.Create(ItemID.Gel, 100);
			MatGel8.AddIngredient(ItemID.NinjaHood);
			MatGel8.AddTile(TileID.Solidifier);
            MatGel8.Register();
			
            Recipe MatGel9 = Recipe.Create(ItemID.Gel, 100);
			MatGel9.AddIngredient(ItemID.NinjaShirt);
			MatGel9.AddTile(TileID.Solidifier);
            MatGel9.Register();
			
            Recipe MatGel0 = Recipe.Create(ItemID.Gel, 100);
			MatGel0.AddIngredient(ItemID.NinjaPants);
			MatGel0.AddTile(TileID.Solidifier);
            MatGel0.Register();
			
            Recipe MatGel10 = Recipe.Create(ItemID.Gel, 400);
			MatGel10.AddIngredient(ItemID.RoyalGel);
			MatGel10.AddTile(TileID.Solidifier);
            MatGel10.Register();
			
            Recipe MatGel11 = Recipe.Create(ItemID.Gel, 100);
			MatGel11.AddIngredient(ItemID.Solidifier);
			MatGel11.AddTile(TileID.Solidifier);
            MatGel11.Register();
			
            Recipe WepMeeHmb = Recipe.Create(ItemID.TheHorsemansBlade, 1);
			WepMeeHmb.AddIngredient(ItemID.PumpkinMoonMedallion);
			WepMeeHmb.AddTile(TileID.LunarCraftingStation);
            WepMeeHmb.Register();
			
            Recipe MatBtw = Recipe.Create(ItemID.BottledWater, 9999);
			MatBtw.AddIngredient(ItemID.SandBlock, 2);
			MatBtw.AddIngredient(ItemID.FallenStar, 500);
			MatBtw.AddTile(TileID.Furnaces);
            MatBtw.Register();
			
            Recipe AccSwiArc = Recipe.Create(ItemID.ArcticDivingGear, 1);
			AccSwiArc.AddIngredient(ItemID.IceSkates, 1);
			AccSwiArc.AddIngredient(ItemID.FallenStar, 5000);
			AccSwiArc.AddTile(TileID.Anvils);
            AccSwiArc.Register();
			
        }
    }
}
