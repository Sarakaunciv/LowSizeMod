﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CRA
{
    public class HeavySoul : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
        public override void SetDefaults()
        {
            Item.width = 16;
            Item.height = 16;
            Item.value = Item.buyPrice(0, 1, 0, 0);
            Item.rare = ItemRarityID.Green;
            Item.maxStack = 9999;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.SoulofLight, 1)
				.AddIngredient(ItemID.SoulofNight, 1)
				.AddTile(TileID.MythrilAnvil)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.SoulofLight, 2)
				.AddTile(TileID.MythrilAnvil)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.SoulofNight, 2)
				.AddTile(TileID.MythrilAnvil)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.SoulofFright, 1)
				.AddTile(TileID.MythrilAnvil)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.SoulofMight, 1)
				.AddTile(TileID.MythrilAnvil)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.SoulofSight, 1)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
