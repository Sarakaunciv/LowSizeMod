﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CRA
{
    public class LifeSeed : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
        public override void SetDefaults()
        {
            Item.width = 16;
            Item.height = 16;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Lime;
            Item.maxStack = 9999;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.LifeFruit, 1)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.HallowedBar, 10)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
