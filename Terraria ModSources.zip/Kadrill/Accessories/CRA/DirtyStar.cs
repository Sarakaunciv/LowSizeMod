﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CRA
{
    public class DirtyStar : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
        public override void SetDefaults()
        {
            Item.width = 26;
            Item.height = 26;
            Item.value = Item.buyPrice(copper: 10);
            Item.rare = ItemRarityID.Blue;
            Item.maxStack = 9999;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.FallenStar, 1)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(100)
				.AddIngredient(ItemID.DirtBlock, 100)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(10)
				.AddIngredient(ItemID.DirtBlock, 10)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.DirtBlock, 1)
				.AddTile(TileID.Furnaces)
				.Register();
		}
    }
}
