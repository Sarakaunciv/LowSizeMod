﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Kadrill.Accessories.CRA;

namespace Kadrill.Accessories.CRA
{
    public class TrashlyTear : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Fishing";

        public override void SetDefaults()
        {
            Item.width = 20;
            Item.height = 20;
            Item.maxStack = 9999;
            Item.value = Item.buyPrice(5, 0, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }
		
		public override void AddRecipes() {
            CreateRecipe(1)
				.AddIngredient(ItemID.BloodMoonStarter, 1)
				.AddTile(TileID.Anvils)
                .Register();
            CreateRecipe(1)
				.AddIngredient<RecycledTrash>(1000)
				.AddTile(TileID.Anvils)
                .Register();
		}
    }
}
