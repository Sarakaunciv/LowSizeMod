﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.CRA
{
    public class RecycledTrash : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Fishing";

        public override void SetDefaults()
        {
            Item.width = 34;
            Item.height = 34;
            Item.maxStack = 9999;
            Item.value = Item.buyPrice(0, 50, 0, 0);
            Item.rare = ItemRarityID.Lime;
        }
		
		public override void AddRecipes() {
            CreateRecipe(15)
				.AddIngredient(ItemID.CorruptFishingCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.CrimsonFishingCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.DungeonFishingCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.FloatingIslandFishingCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.HallowedFishingCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.JungleFishingCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.FrozenCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.OasisCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.LavaCrate, 1)
                .Register();
            CreateRecipe(15)
				.AddIngredient(ItemID.OceanCrate, 1)
                .Register();
            CreateRecipe(9)
				.AddIngredient(ItemID.WoodenCrate, 1)
                .Register();
            CreateRecipe(14)
				.AddIngredient(ItemID.IronCrate, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.GoldenCrate, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.CorruptFishingCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.CrimsonFishingCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.DungeonFishingCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.FloatingIslandFishingCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.HallowedFishingCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.JungleFishingCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.FrozenCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.OasisCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.LavaCrateHard, 1)
                .Register();
            CreateRecipe(30)
				.AddIngredient(ItemID.OceanCrateHard, 1)
                .Register();
            CreateRecipe(18)
				.AddIngredient(ItemID.WoodenCrateHard, 1)
                .Register();
            CreateRecipe(28)
				.AddIngredient(ItemID.IronCrateHard, 1)
                .Register();
            CreateRecipe(60)
				.AddIngredient(ItemID.GoldenCrateHard, 1)
                .Register();
				
            CreateRecipe(150)
				.AddIngredient(ItemID.CorruptFishingCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.CrimsonFishingCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.DungeonFishingCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.FloatingIslandFishingCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.HallowedFishingCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.JungleFishingCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.FrozenCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.OasisCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.LavaCrate, 10)
                .Register();
            CreateRecipe(150)
				.AddIngredient(ItemID.OceanCrate, 10)
                .Register();
            CreateRecipe(90)
				.AddIngredient(ItemID.WoodenCrate, 10)
                .Register();
            CreateRecipe(140)
				.AddIngredient(ItemID.IronCrate, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.GoldenCrate, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.CorruptFishingCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.CrimsonFishingCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.DungeonFishingCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.FloatingIslandFishingCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.HallowedFishingCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.JungleFishingCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.FrozenCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.OasisCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.LavaCrateHard, 10)
                .Register();
            CreateRecipe(300)
				.AddIngredient(ItemID.OceanCrateHard, 10)
                .Register();
            CreateRecipe(180)
				.AddIngredient(ItemID.WoodenCrateHard, 10)
                .Register();
            CreateRecipe(280)
				.AddIngredient(ItemID.IronCrateHard, 10)
                .Register();
            CreateRecipe(600)
				.AddIngredient(ItemID.GoldenCrateHard, 10)
                .Register();
				
            CreateRecipe(1)
				.AddIngredient(ItemID.FrostDaggerfish, 20)
                .Register();
            CreateRecipe(1)
				.AddIngredient(ItemID.BombFish, 4)
                .Register();
				
            CreateRecipe(25)
				.AddIngredient(ItemID.FrostDaggerfish, 500)
                .Register();
            CreateRecipe(25)
				.AddIngredient(ItemID.BombFish, 100)
                .Register();
		}
    }
}
