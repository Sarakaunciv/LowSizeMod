﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CRA
{
    public class HerbalEssence : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 18;
            Item.value = Item.buyPrice(gold: 50);
            Item.rare = ItemRarityID.Green;
            Item.maxStack = 9999;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.Daybloom, 71)
				.AddIngredient(ItemID.Moonglow, 71)
				.AddIngredient(ItemID.Blinkroot, 71)
				.AddIngredient(ItemID.Waterleaf, 71)
				.AddIngredient(ItemID.Shiverthorn, 71)
				.AddIngredient(ItemID.Fireblossom, 71)
				.AddIngredient(ItemID.Deathweed, 71)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.Daybloom, 497)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.Moonglow, 497)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.Blinkroot, 497)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.Waterleaf, 497)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.Shiverthorn, 497)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.Fireblossom, 497)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.Deathweed, 497)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.FallenStar, 994)
				.AddIngredient(ItemID.Daybloom, 1)
				.AddIngredient(ItemID.Moonglow, 1)
				.AddIngredient(ItemID.Blinkroot, 1)
				.AddIngredient(ItemID.Waterleaf, 1)
				.AddIngredient(ItemID.Shiverthorn, 1)
				.AddIngredient(ItemID.Fireblossom, 1)
				.AddIngredient(ItemID.Deathweed, 1)
				.AddTile(TileID.Furnaces)
				.Register();
		}
    }
}
