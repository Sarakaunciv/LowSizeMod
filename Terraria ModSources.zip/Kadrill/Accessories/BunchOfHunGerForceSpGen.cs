﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories
{
    public class BunchOfHunGerForceSpGen : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
		
        public override void SetDefaults()
        {
            Item.width = 30;
            Item.height = 30;
            Item.value = Item.buyPrice(0, 10, 0, 0);
            Item.rare = ItemRarityID.Lime;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.AddBuff(BuffID.Hunter, 216000);
            player.AddBuff(BuffID.Dangersense, 216000);
            player.AddBuff(BuffID.Lifeforce, 216000);
            player.AddBuff(BuffID.Swiftness, 216000);
            player.AddBuff(BuffID.Regeneration, 216000);
        }

        public override void OnConsumeItem(Player player)
        {
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.HunterPotion, 4)
				.AddIngredient(ItemID.TrapsightPotion, 4)
				.AddIngredient(ItemID.LifeforcePotion, 4)
				.AddIngredient(ItemID.SwiftnessPotion, 4)
				.AddIngredient(ItemID.RegenerationPotion, 4)
				.Register();
		}
    }
}
