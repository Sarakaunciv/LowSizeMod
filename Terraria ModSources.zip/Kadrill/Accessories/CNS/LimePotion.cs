﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CNS
{
    public class LimePotion : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Potions";
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 18;
            Item.useTurn = true;
            Item.maxStack = 9999;
            Item.healLife = 180;
            Item.useAnimation = 17;
            Item.useTime = 17;
            Item.useStyle = ItemUseStyleID.DrinkLiquid;
            Item.UseSound = SoundID.Item3;
            Item.consumable = true;
            Item.potion = true;
            Item.rare = ItemRarityID.LightRed;
            Item.value = Item.buyPrice(0, 20, 0, 0);
        }
		
		public override void AddRecipes() {
			CreateRecipe(2)
				.AddIngredient(ItemID.GrassSeeds, 12)
				.AddIngredient(ItemID.GreaterHealingPotion, 1)
				.AddIngredient<GreenPotion>(1)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(20)
				.AddIngredient(ItemID.GrassSeeds, 120)
				.AddIngredient(ItemID.GreaterHealingPotion, 10)
				.AddIngredient<GreenPotion>(10)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(200)
				.AddIngredient(ItemID.GrassSeeds, 1200)
				.AddIngredient(ItemID.GreaterHealingPotion, 100)
				.AddIngredient<GreenPotion>(100)
				.AddTile(TileID.Furnaces)
				.Register();
		}
    }
}
