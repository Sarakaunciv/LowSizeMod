﻿using System.Collections.Generic;
using System.Linq;
using Terraria.Localization;
using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CNS
{
    public class GrassPotion : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Potions";
		
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 18;
            Item.useTurn = true;
            Item.maxStack = 9999;
            Item.healLife = 60;
			Item.potionDelay = 1800;
			Item.mushroomDelay = 1800;
            Item.useAnimation = 17;
            Item.useTime = 17;
            Item.useStyle = ItemUseStyleID.DrinkLiquid;
            Item.UseSound = SoundID.Item3;
            Item.consumable = true;
            Item.potion = true;
            Item.rare = ItemRarityID.Blue;
            Item.value = Item.buyPrice(0, 0, 80, 0);
        }

        public override void OnConsumeItem(Player player)
        {
            player.potionDelayTime = Item.mushroomDelay;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.GrassSeeds, 2)
				.AddIngredient(ItemID.LesserHealingPotion, 1)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(10)
				.AddIngredient(ItemID.GrassSeeds, 20)
				.AddIngredient(ItemID.LesserHealingPotion, 10)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(100)
				.AddIngredient(ItemID.GrassSeeds, 200)
				.AddIngredient(ItemID.LesserHealingPotion, 100)
				.AddTile(TileID.Furnaces)
				.Register();
		}
    }
}
