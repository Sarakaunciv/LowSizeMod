﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CNS
{
    public class GreenPotion : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Potions";
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 18;
            Item.useTurn = true;
            Item.maxStack = 9999;
            Item.healLife = 120;
            Item.useAnimation = 17;
            Item.useTime = 17;
            Item.useStyle = ItemUseStyleID.DrinkLiquid;
            Item.UseSound = SoundID.Item3;
            Item.consumable = true;
            Item.potion = true;
            Item.rare = ItemRarityID.Green;
            Item.value = Item.buyPrice(0, 4, 0, 0);
        }
		
		public override void AddRecipes() {
			CreateRecipe(2)
				.AddIngredient(ItemID.GrassSeeds, 6)
				.AddIngredient<GrassPotion>(1)
				.AddIngredient(ItemID.HealingPotion, 1)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(20)
				.AddIngredient(ItemID.GrassSeeds, 60)
				.AddIngredient<GrassPotion>(10)
				.AddIngredient(ItemID.HealingPotion, 10)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(200)
				.AddIngredient(ItemID.GrassSeeds, 600)
				.AddIngredient<GrassPotion>(100)
				.AddIngredient(ItemID.HealingPotion, 100)
				.AddTile(TileID.Furnaces)
				.Register();
		}
    }
}
