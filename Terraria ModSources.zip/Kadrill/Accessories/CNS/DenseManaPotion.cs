﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CNS
{
    public class DenseManaPotion : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Potions";
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 18;
            Item.useTurn = true;
            Item.maxStack = 9999;
            Item.healMana = 2000;
            Item.useAnimation = 17;
            Item.useTime = 17;
            Item.useStyle = ItemUseStyleID.DrinkLiquid;
            Item.UseSound = SoundID.Item1;
            Item.consumable = true;
            Item.rare = ItemRarityID.Red;
            Item.value = Item.buyPrice(1, 0, 0, 0);
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.SuperManaPotion, 4)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(10)
				.AddIngredient(ItemID.SuperManaPotion, 40)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.GreaterManaPotion, 20)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(10)
				.AddIngredient(ItemID.GreaterManaPotion, 200)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.ManaPotion, 100)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(10)
				.AddIngredient(ItemID.ManaPotion, 1000)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(1)
				.AddIngredient(ItemID.LesserManaPotion, 500)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(10)
				.AddIngredient(ItemID.LesserManaPotion, 5000)
				.AddTile(TileID.Furnaces)
				.Register();
		}
    }
}
