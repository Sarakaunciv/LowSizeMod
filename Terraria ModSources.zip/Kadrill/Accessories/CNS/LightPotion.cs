﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories.CNS
{
    public class LightPotion : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Potions";
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 18;
            Item.useTurn = true;
            Item.maxStack = 9999;
            Item.healLife = 625;
            Item.useAnimation = 17;
            Item.useTime = 17;
            Item.useStyle = ItemUseStyleID.DrinkLiquid;
            Item.UseSound = SoundID.Item3;
            Item.consumable = true;
            Item.potion = true;
            Item.rare = ItemRarityID.Yellow;
            Item.value = Item.buyPrice(1, 0, 0, 0);
        }
		
		public override void AddRecipes() {
			CreateRecipe(2)
				.AddIngredient(ItemID.GrassSeeds, 24)
				.AddIngredient(ItemID.SuperHealingPotion, 1)
				.AddIngredient<LimePotion>(1)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(20)
				.AddIngredient(ItemID.GrassSeeds, 240)
				.AddIngredient(ItemID.SuperHealingPotion, 10)
				.AddIngredient<LimePotion>(10)
				.AddTile(TileID.Furnaces)
				.Register();
			CreateRecipe(200)
				.AddIngredient(ItemID.GrassSeeds, 2400)
				.AddIngredient(ItemID.SuperHealingPotion, 100)
				.AddIngredient<LimePotion>(100)
				.AddTile(TileID.Furnaces)
				.Register();
		}
    }
}
