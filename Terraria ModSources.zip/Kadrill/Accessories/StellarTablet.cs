﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Accessories
{
    public class StellarTablet : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 32;
            Item.height = 32;
            Item.value = Item.buyPrice(0, 50, 0, 0);
            Item.rare = ItemRarityID.Lime;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.buffImmune[BuffID.ManaSickness] = true;
            player.statManaMax2 *= 2;
            player.manaFlower = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.ManaFlower, 1)
				.AddIngredient(ItemID.ArcaneCrystal, 100)
				.AddTile(TileID.Anvils)
				.Register();
		}
    }
}
