﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories;

namespace Kadrill.Accessories
{
    public class PlatinumPlate : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 30;
            Item.height = 30;
            Item.defense = 20;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Lime;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.AddBuff(BuffID.Endurance, 5);
            player.AddBuff(BuffID.Ironskin, 5);
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.PlatinumBar, 40)
				.AddIngredient(ItemID.ArmoredCavefish, 4)
				.AddIngredient(ItemID.IronskinPotion, 4)
				.AddTile(TileID.Anvils)
				.Register();
		}
    }
}
