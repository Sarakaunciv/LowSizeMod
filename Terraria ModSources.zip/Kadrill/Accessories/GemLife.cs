﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories;

namespace Kadrill.Accessories
{
    public class GemLife : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 30;
            Item.height = 30;
            Item.defense = 214;
            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.buffImmune[BuffID.SolarShield1] = true;
            player.AddBuff(BuffID.IceBarrier, 5);
            player.AddBuff(BuffID.Endurance, 5);
            player.AddBuff(BuffID.Ironskin, 5);
            player.lifeRegen += 100;
            player.endurance += 0.45f;
            
			player.pStone = true;
			
            player.longInvince = true;
			
            player.noKnockback = true;
            player.fireWalk = true;
            player.buffImmune[BuffID.Weak] = true;
            player.buffImmune[BuffID.BrokenArmor] = true;
            player.buffImmune[BuffID.Bleeding] = true;
            player.buffImmune[BuffID.Poisoned] = true;
            player.buffImmune[BuffID.Slow] = true;
            player.buffImmune[BuffID.Confused] = true;
            player.buffImmune[BuffID.Silenced] = true;
            player.buffImmune[BuffID.Cursed] = true;
            player.buffImmune[BuffID.Darkness] = true;
            player.buffImmune[BuffID.WindPushed] = true;
            player.buffImmune[BuffID.Stoned] = true;
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.Webbed] = true;
            player.buffImmune[BuffID.Blackout] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.OnFire3] = true;
            player.buffImmune[BuffID.Chilled] = true;
            player.buffImmune[BuffID.Frozen] = true;
            player.buffImmune[BuffID.Frostburn] = true;
            player.buffImmune[BuffID.Frostburn2] = true;
            player.buffImmune[BuffID.CursedInferno] = true;
            player.buffImmune[BuffID.ShadowFlame] = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.AnkhShield, 1)
				.AddIngredient<ArachnaFlameCharm>()
				.AddIngredient<TurtleGuard>()
				.AddIngredient<PlatinumPlate>()
				.AddIngredient(ItemID.FragmentSolar, 25)
				.AddIngredient(ItemID.LunarBar, 20)
				.AddIngredient(ItemID.AegisCrystal, 20)
				.AddIngredient(ItemID.AegisFruit, 20)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
