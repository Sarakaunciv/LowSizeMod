﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories;
using Kadrill.Accessories.BUF;

namespace Kadrill.Accessories
{
    public class HoneyInfiniteStarPower : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 30;
            Item.height = 30;
            Item.value = Item.buyPrice(1, 0, 0, 0);
            Item.rare = ItemRarityID.Cyan;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.AddBuff(ModContent.BuffType<BigHive>(), 5);
			
            player.buffImmune[BuffID.ManaSickness] = true;
            player.statManaMax2 *= 2;
            player.manaFlower = true;
			
            player.AddBuff(BuffID.AmmoReservation, 5);
            player.AddBuff(BuffID.AmmoBox, 5);
            player.ammoCost80 = true;
            player.ammoCost75 = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<StellarTablet>()
				.AddIngredient<LargeHive>()
				.AddIngredient<AmmoBackpack>()
				.AddIngredient(ItemID.HallowedBar, 3)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
