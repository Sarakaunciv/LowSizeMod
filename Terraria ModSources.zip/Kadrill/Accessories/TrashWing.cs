﻿using Kadrill.Accessories.CRA;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Kadrill.Accessories
{
    public class TrashWing : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories.Wings";

        public override void SetDefaults()
        {
            Item.width = 22;
            Item.height = 20;
            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Red;
			
            Item.useTime = Item.useAnimation = 20;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.UseSound = SoundID.Item94;
            Item.noMelee = true;
            Item.mountType = ModContent.MountType<TrashWingM>();
        }

        public override void AddRecipes()
        {
            CreateRecipe(1)
				.AddIngredient(ItemID.GiantHarpyFeather, 1)
                .AddIngredient<RecycledTrash>(9999)
				.AddTile(TileID.Anvils)
                .Register();
        }
    }
}
