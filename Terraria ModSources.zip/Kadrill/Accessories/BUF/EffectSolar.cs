﻿using Terraria;
using Terraria.ModLoader;

namespace Kadrill.Accessories.BUF
{
    public class EffectSolar : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.debuff[Type] = false;
            Main.buffNoTimeDisplay[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            player.endurance += 0.3f;
            player.GetDamage<MeleeDamageClass>() *= 2;
        }
    }
}
