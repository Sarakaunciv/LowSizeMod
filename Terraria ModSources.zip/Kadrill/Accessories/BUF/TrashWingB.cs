﻿using Terraria;
using Terraria.ModLoader;
using Kadrill.Accessories;

namespace Kadrill.Accessories.BUF
{
    public class TrashWingB : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.buffNoTimeDisplay[Type] = true;
            Main.buffNoSave[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            player.mount.SetMount(ModContent.MountType<TrashWingM>(), player);
            player.buffTime[buffIndex] = 10;
        }
    }
}
