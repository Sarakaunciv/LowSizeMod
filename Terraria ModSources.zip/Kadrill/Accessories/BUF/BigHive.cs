﻿using Terraria;
using Terraria.ModLoader;

namespace Kadrill.Accessories.BUF
{
    public class BigHive : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.debuff[Type] = false;
            Main.buffNoTimeDisplay[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            player.maxMinions += 8;
            player.GetDamage<SummonDamageClass>() *= 2;
        }
    }
}
