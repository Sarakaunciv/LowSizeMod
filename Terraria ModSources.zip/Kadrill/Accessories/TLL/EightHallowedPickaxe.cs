﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories;

namespace Kadrill.Accessories.TLL
{
    public class EightHallowedPickaxe : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Tools";
		
        public override void SetDefaults()
        {
            Item.width = 48;
            Item.height = 48;
            Item.useTime = 1;
            Item.useAnimation = 15;
            Item.pick = 200;
            Item.tileBoost += 10;

            Item.value = Item.buyPrice(8, 0, 0, 0);
            Item.rare = ItemRarityID.Cyan;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Swing;
            Item.damage = 550;
            Item.knockBack = 8f;
            Item.useTurn = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.HallowedBar, 81)
				.AddIngredient(ItemID.SoulofFright, 1)
				.AddIngredient(ItemID.SoulofMight, 1)
				.AddIngredient(ItemID.SoulofSight, 1)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
