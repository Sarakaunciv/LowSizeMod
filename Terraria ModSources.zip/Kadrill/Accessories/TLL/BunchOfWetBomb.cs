﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.TLL
{
    public class BunchOfWetBomb : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
		
        public override void SetDefaults()
        {
            Item.width = 32;
            Item.height = 32;
            Item.DamageType = DamageClass.Ranged;
            Item.value = Item.buyPrice(0, 0, 0, 5);
            Item.rare = ItemRarityID.Blue;
            Item.maxStack = 9999;
			
            Item.useTime = Item.useAnimation = 10;
            Item.consumable = true;
            Item.shootSpeed = 5f;
            Item.shoot = ProjectileID.WetBomb;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Swing;
            Item.noMelee = true;
            Item.noUseGraphic = true;
            Item.UseSound = SoundID.Item1;
        }
		
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 destination = Main.MouseWorld;
            position = destination;
            Vector2 cachedPosition = position;
            float maxRandomOffset = 10f;
            int totalProjectiles = 20;
            for (int i = 0; i < totalProjectiles; i++)
            {
                position.X += MathHelper.Lerp(0f, 0f, i / (float)(totalProjectiles - 1));
                position += Main.rand.NextVector2Circular(maxRandomOffset, maxRandomOffset);
                velocity = (Main.MouseWorld - position).SafeNormalize(Vector2.UnitY) * 10f;
                Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI);
                position = cachedPosition;
            }
            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(100)
				.AddIngredient(ItemID.WetBomb, 1)
				.Register();
		}
    }
}
