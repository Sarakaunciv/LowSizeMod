﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.TLL
{
    public class MixedBait : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Fishing";

        public override void SetDefaults()
        {
            Item.width = 32;
            Item.height = 32;
            Item.maxStack = 9999;
            Item.value = Item.buyPrice(0, 0, 5, 0);
            Item.rare = ItemRarityID.Cyan;
            Item.bait = 50;
            Item.consumable = true;
        }
		
		public override void AddRecipes() {
            CreateRecipe(10)
				.AddIngredient(ItemID.Bass, 40)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Flounder, 40)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Trout, 40)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.ShuckedOyster, 40)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Oyster, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.AtlanticCod, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.CrimsonTigerfish, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.RedSnapper, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.SpecularFish, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.NeonTetra, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Ebonkoi, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Hemopiranha, 30)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.DoubleCod, 25)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Tuna, 20)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Damselfish, 20)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Salmon, 18)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.FrostMinnow, 15)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.RockLobster, 10)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Shrimp, 9)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.VariegatedLardfish, 9)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(20)
				.AddIngredient(ItemID.Honeyfin, 9)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(20)
				.AddIngredient(ItemID.PrincessFish, 8)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.Obsidifish, 8)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(10)
				.AddIngredient(ItemID.FlarefinKoi, 8)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(20)
				.AddIngredient(ItemID.ArmoredCavefish, 6)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(20)
				.AddIngredient(ItemID.ChaosFish, 6)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(20)
				.AddIngredient(ItemID.Prismite, 5)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(20)
				.AddIngredient(ItemID.GoldenCarp, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(1)
				.AddIngredient(ItemID.Bird, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(1)
				.AddIngredient(ItemID.BlueJay, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(1)
				.AddIngredient(ItemID.Cardinal, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(3)
				.AddIngredient(ItemID.Squirrel, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(3)
				.AddIngredient(ItemID.SquirrelRed, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(3)
				.AddIngredient(ItemID.Bunny, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(2)
				.AddIngredient(ItemID.Duck, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(2)
				.AddIngredient(ItemID.MallardDuck, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(100)
				.AddIngredient(ItemID.Goldfish, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(2)
				.AddIngredient(ItemID.Grebe, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(1)
				.AddIngredient(ItemID.BlueMacaw, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(1)
				.AddIngredient(ItemID.ScarletMacaw, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(2)
				.AddIngredient(ItemID.Owl, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(3)
				.AddIngredient(ItemID.Penguin, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(2)
				.AddIngredient(ItemID.Seagull, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(2)
				.AddIngredient(ItemID.Toucan, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(3)
				.AddIngredient(ItemID.Turtle, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(3)
				.AddIngredient(ItemID.TurtleJungle, 1)
				.AddTile(TileID.Furnaces)
                .Register();
            CreateRecipe(9999)
				.AddIngredient(ItemID.GoldGoldfish, 1)
				.AddTile(TileID.Furnaces)
                .Register();
		}
    }
}
