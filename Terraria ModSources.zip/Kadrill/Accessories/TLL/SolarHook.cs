﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Kadrill.Accessories.TLL;
using static Terraria.ModLoader.ModContent;

namespace Kadrill.Accessories.TLL
{
    public class SolarHook : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Tools";
        public override void SetDefaults()
        {
            // Instead of copying these values, we can clone and modify the ones we want to copy
            Item.CloneDefaults(ItemID.AmethystHook);
            Item.width = 30;
            Item.height = 32;
            Item.shootSpeed = 60f;
            Item.shoot = ProjectileType<SolarHookP>();
            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Purple;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.FragmentSolar, 50)
				.AddIngredient(ItemID.Chain, 9)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
