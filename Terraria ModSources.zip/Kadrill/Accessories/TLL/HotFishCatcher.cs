﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Kadrill.Accessories.TLL;

namespace Kadrill.Accessories.TLL
{
    public class HotFishCatcher : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Fishing";
        public override void SetStaticDefaults()
        {
            ItemID.Sets.CanFishInLava[Item.type] = true;
        }

        public override void SetDefaults()
        {
            Item.width = 24;
            Item.height = 28;
            Item.useAnimation = 8;
            Item.useTime = 8;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.UseSound = SoundID.Item1;
            Item.fishingPole = 950;
            Item.shootSpeed = 20f;
            Item.shoot = ProjectileID.BobberHotline;
            Item.value = Item.buyPrice(5, 0, 0, 0);
            Item.rare = ItemRarityID.Purple;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            for (int i = 0; i < 500; i++)
            {
                Projectile.NewProjectile(source, position, velocity.RotatedByRandom(MathHelper.ToRadians(18f)), type, 0, 0f, player.whoAmI, ai2: Main.rand.Next(2));
            }
            return false;
        }

        public override void ModifyFishingLine(Projectile bobber, ref Vector2 lineOriginOffset, ref Color lineColor)
        {
            lineOriginOffset = new Vector2(53f, -33f);
            if (bobber.ai[2] == 0f)
                lineColor = new Color(80, 80, 80, 100);
            else
                lineColor = new Color(80, 80, 80, 100);
        }
		
		public override void AddRecipes() {
            CreateRecipe(1)
				.AddIngredient<FishCatcher>()
				.AddIngredient(ItemID.HellstoneBar, 50)
				.AddIngredient(ItemID.FallenStar, 500)
				.AddTile(TileID.Anvils)
                .Register();
		}
    }
}
