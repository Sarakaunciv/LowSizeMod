﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories;

namespace Kadrill.Accessories.TLL
{
    public class EightWoodenPickaxe : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Tools";
		
        public override void SetDefaults()
        {
            Item.width = 48;
            Item.height = 48;
            Item.useTime = 1;
            Item.useAnimation = 25;
            Item.pick = 35;
            Item.tileBoost += 1;

            Item.value = Item.buyPrice(0, 1, 0, 0);
            Item.rare = ItemRarityID.Blue;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Swing;
            Item.damage = 40;
            Item.knockBack = 2f;
            Item.useTurn = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.Wood, 54)
				.AddTile(TileID.WorkBenches)
				.Register();
		}
    }
}
