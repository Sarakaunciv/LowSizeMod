﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories.TLL;

namespace Kadrill.Accessories.TLL
{
    public class ShortCopperXam : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Tools";
		
        public override void SetDefaults()
        {
            Item.width = 46;
            Item.height = 38;
            Item.useTime = 1;
            Item.useAnimation = 17;
            Item.axe = 500;
            Item.hammer = 500;

            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Purple;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Swing;
            Item.damage = 150;
            Item.knockBack = 10f;
            Item.useTurn = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient<CopperXam>()
				.AddTile(TileID.WorkBenches)
				.Register();
		}
    }
}
