﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories;

namespace Kadrill.Accessories.TLL
{
    public class EightMoonPickaxe : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Tools";
		
        public override void SetDefaults()
        {
            Item.width = 48;
            Item.height = 48;
            Item.useTime = 1;
            Item.useAnimation = 12;
            Item.pick = 5000;
            Item.tileBoost += 15;

            Item.value = Item.buyPrice(50, 0, 0, 0);
            Item.rare = ItemRarityID.Purple;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Swing;
            Item.damage = 2250;
            Item.knockBack = 10f;
            Item.useTurn = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.FragmentNebula, 15)
				.AddIngredient(ItemID.FragmentSolar, 15)
				.AddIngredient(ItemID.FragmentStardust, 15)
				.AddIngredient(ItemID.FragmentVortex, 15)
				.AddIngredient(ItemID.LunarBar, 50)
				.AddTile(TileID.LunarCraftingStation)
				.Register();
		}
    }
}
