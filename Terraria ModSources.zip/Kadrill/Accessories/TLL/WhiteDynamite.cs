﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.TLL
{
    public class WhiteDynamite : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
		
        public override void SetDefaults()
        {
            Item.width = 8;
            Item.height = 28;
            Item.DamageType = DamageClass.Ranged;
            Item.damage = 999;
            Item.value = Item.buyPrice(0, 1, 0, 0);
            Item.rare = ItemRarityID.Cyan;
            Item.maxStack = 9999;
			
            Item.useTime = Item.useAnimation = 20;
            Item.consumable = true;
            Item.shootSpeed = 5f;
            Item.shoot = ProjectileID.TNTBarrel;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Swing;
            Item.noMelee = true;
            Item.noUseGraphic = true;
            Item.UseSound = SoundID.Item1;
        }
		
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 destination = Main.MouseWorld;
            position = destination;
            Vector2 cachedPosition = position;
            float maxRandomOffset = 160f;
            int totalProjectiles = 10;
            for (int i = 0; i < totalProjectiles; i++)
            {
                position.X += MathHelper.Lerp(0f, 0f, i / (float)(totalProjectiles - 1));
                position += Main.rand.NextVector2Circular(maxRandomOffset, maxRandomOffset);
                velocity = (Main.MouseWorld - position).SafeNormalize(Vector2.UnitY) * 0;
                Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI);
                position = cachedPosition;
            }
            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.Dynamite, 5)
				.Register();
			CreateRecipe(100)
				.AddIngredient(ItemID.Dynamite, 500)
				.Register();
		}
    }
}
