﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;

namespace Kadrill.Accessories.TLL
{
    public class TrueTerraformer : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Block";
		
        public override void SetDefaults()
        {
            Item.width = 70;
            Item.height = 70;
            Item.value = Item.buyPrice(10, 0, 0, 0);
            Item.rare = ItemRarityID.Purple;
			
            Item.useTime = 4;
			Item.useAnimation = 30;
            Item.shoot = ProjectileID.PureSpray;
            Item.shootSpeed = 80f;
            Item.autoReuse = true;

            Item.useStyle = ItemUseStyleID.Shoot;
            Item.UseSound = SoundID.Item34;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            if (player.altFunctionUse == 2)
            {
            }
            else
            {
                Projectile.NewProjectile(source, player.MountedCenter, new Vector2(player.direction * 60, 0), ProjectileID.PureSpray, damage, knockback, player.whoAmI, (float)player.direction * player.gravDir, player.itemAnimationMax, 1);
                NetMessage.SendData(MessageID.PlayerControls, -1, -1, null, player.whoAmI);
            }

            return false;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.Clentaminator2, 6)
				.AddIngredient(ItemID.GreenSolution, 9999)
				.AddIngredient(ItemID.LunarBar, 100)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
