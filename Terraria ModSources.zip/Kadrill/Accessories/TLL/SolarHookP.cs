﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Kadrill.Accessories.TLL
{
    public class SolarHookP : ModProjectile, ILocalizedModType
    {
        public new string LocalizationCategory => "Projectiles";
        public override void SetDefaults()
        {
            Projectile.CloneDefaults(ProjectileID.GemHookAmethyst);
        }

        public override bool? CanUseGrapple(Player player)
        {
            int hooksOut = 0;
            for (int l = 0; l < Main.maxProjectiles; l++)
            {
                if (Main.projectile[l].active && Main.projectile[l].owner == Main.myPlayer && Main.projectile[l].type == Projectile.type)
                {
                    hooksOut++;
                }
            }
            if (hooksOut > 1)
            {
                return false;
            }
            return true;
        }

        public override float GrappleRange() => 1600;

        public override void NumGrappleHooks(Player player, ref int numHooks)
        {
            numHooks = 1;
        }

        public override void GrappleRetreatSpeed(Player player, ref float speed)
        {
            speed = 60;
        }

        public override void GrapplePullSpeed(Player player, ref float speed)
        {
            speed = 60;
        }

        public override void AI()
        {
            Projectile.spriteDirection = -Projectile.direction;

            if (Projectile.ai[0] == 2f)
                Projectile.extraUpdates = 1;
            else
                Projectile.extraUpdates = 0;
        }
    }
}
