﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill.Accessories;

namespace Kadrill.Accessories
{
    public class TurtleGuard : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "Items.Accessories";
        public override void SetDefaults()
        {
            Item.width = 30;
            Item.height = 30;
            Item.defense = 65;
            Item.value = Item.buyPrice(5, 0, 0, 0);
            Item.rare = ItemRarityID.Yellow;
            Item.accessory = true;
        }
		
   public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.endurance += 0.15f;
            player.AddBuff(BuffID.IceBarrier, 5);
            player.noKnockback = true;
        }
		
		public override void AddRecipes() {
			CreateRecipe(1)
				.AddIngredient(ItemID.FrozenTurtleShell, 1)
				.AddIngredient(ItemID.ChlorophyteBar, 54)
				.AddIngredient(ItemID.TurtleShell, 3)
				.AddTile(TileID.MythrilAnvil)
				.Register();
		}
    }
}
