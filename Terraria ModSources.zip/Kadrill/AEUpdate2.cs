﻿using System;
using Terraria;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Terraria.ID;
using Kadrill;

namespace Kadrill
{
    public class AEUpdate2 : GlobalItem
    {

        public static GameCulture ActiveCulture
        {
            get
            {
                return LanguageManager.Instance.ActiveCulture;
            }
        }
        public int rangedDamage;
        public int minionDamage;
        public int meleeDamage;
        public int magicDamage;
        public int meleeCrit;
        public int rangedCrit;
        public int magicCrit;
        public override bool InstancePerEntity
        {
            get
            {
                return true;
            }
        }
        public override GlobalItem Clone(Item item, Item itemClone)
        {
            AEUpdate2 myClone = (AEUpdate2)base.Clone(item, itemClone);

            myClone.rangedDamage = rangedDamage;
            myClone.minionDamage = minionDamage;
            myClone.meleeDamage = meleeDamage;
            myClone.magicDamage = magicDamage;
            myClone.meleeCrit = meleeCrit;
            myClone.rangedCrit = rangedCrit;
            myClone.magicCrit = magicCrit;
            return myClone;
        }
        public override bool CanReforge(Item item)/* tModPorter Note: Use CanReforge instead for logic determining if a reforge can happen. */
        {

            rangedDamage = 0;
            minionDamage = 0;
            meleeDamage = 0;
            magicDamage = 0;
            meleeCrit = 0;
            rangedCrit = 0;
            magicCrit = 0;
            return base.CanReforge(item);
        }
        public override void ModifyTooltips(Item item, List<TooltipLine> tooltips)
        {
            if (ActiveCulture == GameCulture.FromName("pl-PL"))
            {
                if (rangedDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", "+" + rangedDamage + "% obrażenia dystansowe");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (minionDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", "+" + minionDamage + "% obrażenia przywołanej istoty");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", "+" + meleeDamage + "% obrażenia w walce w zwarciu");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", "+" + magicDamage + "% obrażenia magiczne");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeCrit", "+" + meleeCrit + "% szansa na trafienie krytyczne w walce w zwarciu");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedCrit", "+" + rangedCrit + "% szansa na dystansowe trafienie krytyczne");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicCrit", "+" + magicCrit + "% szansa na magiczne trafienie krytyczne");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", rangedDamage + "% obrażenia dystansowe");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (minionDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", minionDamage + "% obrażenia przywołanej istoty");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", meleeDamage + "% obrażenia w walce w zwarciu");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (magicDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", magicDamage + "% obrażenia magiczne");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
            else if (ActiveCulture == GameCulture.FromName("ru-RU"))
            {
                if (rangedDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", "+" + rangedDamage + "% дистанционный урон");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (minionDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", "+" + minionDamage + "% урон от призыва");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", "+" + meleeDamage + "% урон в ближнем");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", "+" + magicDamage + "% магический урон");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeCrit", "+" + meleeCrit + "% шанс критического удара в ближнем бою");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedCrit", "+" + rangedCrit + "% шанс дистанционного критического удара");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicCrit", "+" + magicCrit + "% шанс критического магического урона");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", rangedDamage + "% дистанционный урон");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (minionDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", minionDamage + "% урон от призыва");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", meleeDamage + "% урон в ближнем");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (magicDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", magicDamage + "% магический урон");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
            else if (ActiveCulture == GameCulture.FromName("de-DE"))
            {
                if (rangedDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", "+" + rangedDamage + "% Fernkampfschaden");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (minionDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", "+" + minionDamage + "% Günstlingschaden");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", "+" + meleeDamage + "% Nahkampfschaden");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", "+" + magicDamage + "% Magieschaden");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeCrit", "+" + meleeCrit + "% kritische Nahkampf-Trefferchance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedCrit", "+" + rangedCrit + "% kritische Fernkampf-Trefferchance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicCrit", "+" + magicCrit + "% kritische Magie-Trefferchance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", rangedDamage + "% Fernkampfschaden");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (minionDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", minionDamage + "% Günstlingschaden");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", meleeDamage + "% Nahkampfschaden");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (magicDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", magicDamage + "% Magieschaden");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
            else
            {
                if (rangedDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", "+" + rangedDamage + "% ranged damage");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (minionDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", "+" + minionDamage + "% summon damage");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", "+" + meleeDamage + "% melee damage");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicDamage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", "+" + magicDamage + "% magic damage");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeCrit", "+" + meleeCrit + "% melee critical strike chance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedCrit", "+" + rangedCrit + "% ranged critical strike chance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (magicCrit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicCrit", "+" + magicCrit + "% magic critical strike chance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (rangedDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "rangedDamage", rangedDamage + "% ranged damage");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (minionDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "minionDamage", minionDamage + "% summon damage");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeDamage", meleeDamage + "% melee damage");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (magicDamage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "magicDamage", magicDamage + "% magic damage");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
        }
    
        public override void UpdateEquip(Item item, Player player)
        {
            if (item.prefix > 0)
            {

                player.GetDamage(DamageClass.Ranged) += (float)rangedDamage * .01f;
                player.GetDamage(DamageClass.Summon) += (float)minionDamage * .01f;
                player.GetDamage(DamageClass.Melee) += (float)meleeDamage * .01f;
                player.GetDamage(DamageClass.Magic) += (float)magicDamage * .01f;
                player.GetCritChance(DamageClass.Melee) += meleeCrit;
                player.GetCritChance(DamageClass.Ranged) += rangedCrit;
                player.GetCritChance(DamageClass.Magic) += magicCrit;
            }
        }
        public override void NetSend(Item item, BinaryWriter writer)
        {

            writer.Write(rangedDamage);
            writer.Write(minionDamage);
            writer.Write(meleeDamage);
            writer.Write(magicDamage);
            writer.Write(meleeCrit);
            writer.Write(rangedCrit);
            writer.Write(magicCrit);

        }
        public override void NetReceive(Item item, BinaryReader reader)
        {
            rangedDamage = reader.ReadInt32();
            minionDamage = reader.ReadInt32();
            meleeDamage = reader.ReadInt32();
            magicDamage = reader.ReadInt32();
            meleeCrit = reader.ReadInt32();
            rangedCrit = reader.ReadInt32();
            magicCrit = reader.ReadInt32();

        }
    }
}