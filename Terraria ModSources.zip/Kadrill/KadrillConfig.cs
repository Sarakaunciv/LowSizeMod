﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Newtonsoft.Json;
using Terraria;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ModLoader.Config;
using System.Runtime.Serialization;

namespace Kadrill
{
    public class KadrillConfig : ModConfig
    {
        [DefaultValue(false)]
        [ReloadRequired]
        public bool KadrillReforge;

        public override ConfigScope Mode => ConfigScope.ServerSide;
    }
}
