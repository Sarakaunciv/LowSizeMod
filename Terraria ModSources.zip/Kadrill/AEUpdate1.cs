﻿using System;
using Terraria;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill
{
    public class AEUpdate1 : GlobalItem
    {

        public static GameCulture ActiveCulture
        {
            get
            {
                return LanguageManager.Instance.ActiveCulture;
            }
        }
        public int damage;
        public int crit;
        public int moveSpeed;
        public int meleeSpeed;
        public int defense;
        public int statManaMax2;
        public float endurance;
        public override bool InstancePerEntity
        {
            get
            {
                return true;
            }
        }
        public override GlobalItem Clone(Item item, Item itemClone)
        {
            AEUpdate1 myClone = (AEUpdate1)base.Clone(item, itemClone);

            myClone.damage = damage;
            myClone.crit = crit;
            myClone.moveSpeed = moveSpeed;
            myClone.meleeSpeed = meleeSpeed;
            myClone.defense = defense;
            myClone.statManaMax2 = statManaMax2;
            myClone.endurance = endurance;
            return myClone;
        }
        public override bool CanReforge(Item item)/* tModPorter Note: Use CanReforge instead for logic determining if a reforge can happen. */
        {

            damage = 0;
            crit = 0;
            moveSpeed = 0;
            meleeSpeed = 0;
            defense = 0;
            statManaMax2 = 0;
            endurance = 0;
            return base.CanReforge(item);
        }
        public override void ModifyTooltips(Item item, List<TooltipLine> tooltips)
        {
            if (ActiveCulture == GameCulture.FromName("pl-PL"))
            {
                if (damage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", "+" + damage + "% pkt. obrażeń");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (crit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "crit", "+" + crit + "% szansy na trafienie krytyczne");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (moveSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", "+" + moveSpeed + "% szybkości poruszania się");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", "+" + meleeSpeed + "% szybkości walki w zwarciu");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (defense > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", "+" + defense + " pkt. obrony");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (statManaMax2 > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "statManaMax2", "+" + statManaMax2 + " pkt. many");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (endurance > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "endurance", "+" + endurance + "% zmniejszone obrażenia");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (damage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", damage + "% pkt. obrażeń");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (moveSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", moveSpeed + "% szybkości poruszania się");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", meleeSpeed + "% szybkości walki w zwarciu");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (defense < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", defense + " pkt. obrony");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
            else if (ActiveCulture == GameCulture.FromName("ru-RU"))
            {
                if (damage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", "+" + damage + "% урон");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (crit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "crit", "+" + crit + "% шанс критического удара");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (moveSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", "+" + moveSpeed + "% скорость движения");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", "+" + meleeSpeed + "% скорость ближнего боя");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (defense > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", "+" + defense + " защита");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (statManaMax2 > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "statManaMax2", "+" + statManaMax2 + " ману");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (endurance > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "endurance", "+" + endurance + "% Получаемый урон снижен");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (damage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", damage + "% урон");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (moveSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", moveSpeed + "% скорость движения");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", meleeSpeed + "% скорость ближнего боя");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (defense < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", defense + " защита");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
            else if (ActiveCulture == GameCulture.FromName("de-DE"))
            {
                if (damage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", "+" + damage + "% Schaden");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (crit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "crit", "+" + crit + "% kritische Trefferchance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (moveSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", "+" + moveSpeed + "% Bewegungstempo");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", "+" + meleeSpeed + "% Nahkampftempo");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (defense > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", "+" + defense + " Abwehr");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (statManaMax2 > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "statManaMax2", "+" + statManaMax2 + " Mana");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (endurance > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "endurance", "+" + endurance + "% Schadensverringerung");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (damage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", damage + "% Schaden");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (moveSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", moveSpeed + "% Bewegungstempo");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", meleeSpeed + "% Nahkampftempo");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (defense < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", defense + " Abwehr");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
            else
            {
                if (damage > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", "+" + damage + "% damage");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (crit > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "crit", "+" + crit + "% critical strike chance");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (moveSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", "+" + moveSpeed + "% movement speed");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", "+" + meleeSpeed + "% melee speed");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (defense > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", "+" + defense + " defense");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (statManaMax2 > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "statManaMax2", "+" + statManaMax2 + " mana");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (endurance > 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "endurance", "+" + endurance + "% damage reduction");
                    line.IsModifier = true;
                    tooltips.Add(line);
                }
                if (damage < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "damage", damage + "% damage");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (moveSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "moveSpeed", moveSpeed + "% movement speed");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (meleeSpeed < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "meleeSpeed", meleeSpeed + "% melee speed");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
                if (defense < 0)
                {
                    TooltipLine line = new TooltipLine(Mod, "defense", defense + " defense");
                    line.IsModifier = true;
                    line.IsModifierBad = true;
                    tooltips.Add(line);
                }
            }
        }
    
        public override void UpdateEquip(Item item, Player player)
        {
            if (item.prefix > 0)
            {
                player.GetDamage(DamageClass.Generic) += (float)damage * .01f;
                player.GetCritChance(DamageClass.Generic) += crit;
                player.moveSpeed += moveSpeed * .01f;
                player.GetAttackSpeed(DamageClass.Melee) += (float)meleeSpeed * .01f;
                player.statDefense += defense;
                player.statManaMax2 += statManaMax2;
                player.endurance = player.endurance + (endurance * .01f);
            }
        }
        public override void NetSend(Item item, BinaryWriter writer)
        {

            writer.Write(damage);
            writer.Write(crit);
            writer.Write(moveSpeed);
            writer.Write(meleeSpeed);
            writer.Write(defense);
            writer.Write(statManaMax2);
            writer.Write(endurance);

        }
        public override void NetReceive(Item item, BinaryReader reader)
        {
            damage = reader.ReadInt32();
            crit = reader.ReadInt32();
            moveSpeed = reader.ReadInt32();
            meleeSpeed = reader.ReadInt32();
            defense = reader.ReadInt32();
            statManaMax2 = reader.ReadInt32();
            endurance = reader.ReadSingle();

        }
    }
}