using System.Collections.Generic;
using Terraria.Utilities;
using Terraria;
using Terraria.ModLoader;

namespace Kadrill.Prefixes
{
    [Autoload(false)]
    public class CommonPrefix : ModPrefix
    {
        public class CommonPrefixLoader : ILoadable
		{
			public void Load(Mod mod) {
                mod.AddContent(new CommonPrefix("Drill", 0.25f, 4f, 0.40f, 0));
                mod.AddContent(new CommonPrefix("Lightning", 0.25f, 4f, 0.25f, 0));
			}

			public void Unload() { }
		}

        public override string Name => _name;
		private readonly string _name;
        internal int critBonus = 0;
        internal float damageMult = 1f;
        internal float knockbackMult = 1f;
        internal float useTimeMult = 1f;

        public override PrefixCategory Category { get { return PrefixCategory.AnyWeapon;} }

        public CommonPrefix() { }

        public CommonPrefix(string name, float damageMult = 1f, float knockbackMult = 1f, float useTimeMult = 1f, int critBonus = 0)
        {
            _name = name;
            this.damageMult = damageMult;
            this.knockbackMult = knockbackMult;
            this.useTimeMult = useTimeMult;
            this.critBonus = critBonus;
        }

        public override void ModifyValue(ref float valueMult) { valueMult *= 1; }

        public override bool CanRoll(Item item)
        {

            if (item.noUseGraphic == true && item.CountsAsClass(DamageClass.Melee) == true && item.useStyle != 13 && item.type != 4956) {
                return false; }
            else {
                return true;
            }
        }

        public override float RollChance(Item item) { return 1f; }

        public override void SetStats(ref float damageMult, ref float knockbackMult, ref float useTimeMult, ref float scaleMult, ref float shootSpeedMult, ref float manaMult, ref int critBonus)
        {
            damageMult = this.damageMult;
            knockbackMult = this.knockbackMult;
            useTimeMult = this.useTimeMult;
            critBonus = this.critBonus;
        }
    }
}
