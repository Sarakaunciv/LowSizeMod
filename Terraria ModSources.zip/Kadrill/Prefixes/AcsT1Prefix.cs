using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Exceptions;
using System.IO;
using System.Collections.Generic;
using Terraria.ID;

namespace Kadrill.Prefixes
{
    [Autoload(false)]
    public class AcsT1Prefix : ModPrefix
    {
        public class AcsT1PrefixLoader : ILoadable
		{
            public void Load(Mod mod)
            {
                mod.AddContent(new AcsT1Prefix("Mad", 8, 0, 0, 0, 0, 0, 1));
                mod.AddContent(new AcsT1Prefix("Fury", 20, 0, 0, 0, 0, 0, 3));
                mod.AddContent(new AcsT1Prefix("Warth", 50, 0, 0, 0, 0, 0, 6));
                mod.AddContent(new AcsT1Prefix("Gambing", 0, 8, 0, 0, 0, 0, 1));
                mod.AddContent(new AcsT1Prefix("Dice", 0, 20, 0, 0, 0, 0, 3));
                mod.AddContent(new AcsT1Prefix("Half", 0, 50, 0, 0, 0, 0, 6));
                mod.AddContent(new AcsT1Prefix("Jump", 0, 0, 10, 0, 0, 0, 1));
                mod.AddContent(new AcsT1Prefix("Wing", 0, 0, 35, 0, 0, 0, 3));
                mod.AddContent(new AcsT1Prefix("Flight", 0, 0, 100, 0, 0, 0, 6));
                mod.AddContent(new AcsT1Prefix("Fort", 0, 0, 0, 14, 0, 2, 10));
                mod.AddContent(new AcsT1Prefix("Bright", 0, 0, 0, 0, 80, 0, 1));
                mod.AddContent(new AcsT1Prefix("Star", 0, 0, 0, 0, 300, 0, 3));
                mod.AddContent(new AcsT1Prefix("Comet", 0, 0, 0, 0, 800, 0, 6));
			}

			public void Unload() { }
		}

        public override string Name => _name;
		private readonly string _name;
        private int damage;
        private int crit;
        private int moveSpeed;
        private int meleeSpeed;
        private int defense;
        private int statManaMax2;
        private float endurance;
        private int tier;
        
        public override float RollChance(Item item)
        {
            return 1f;
        }
        public override bool CanRoll(Item item)
        {
            return true;
        }
        public override PrefixCategory Category { get { return PrefixCategory.Accessory; } }

        public AcsT1Prefix()
        {
        }

        public AcsT1Prefix(string name, int damage, int crit, int moveSpeed, int defense, int statManaMax2, int endurance, int tier)
        {
            _name = name;
            this.damage = damage;
            this.crit = crit;
            this.moveSpeed = moveSpeed;
            this.meleeSpeed = meleeSpeed;
            this.defense = defense;
            this.statManaMax2 = statManaMax2;
            this.endurance = endurance;
            this.tier = tier;

        }

        public override void Apply(Item item)
        {

            item.GetGlobalItem<AEUpdate1>().damage = damage;
            item.GetGlobalItem<AEUpdate1>().crit = crit;
            item.GetGlobalItem<AEUpdate1>().moveSpeed = moveSpeed;
            item.GetGlobalItem<AEUpdate1>().meleeSpeed = meleeSpeed;
            item.GetGlobalItem<AEUpdate1>().defense = defense;
            item.GetGlobalItem<AEUpdate1>().statManaMax2 = statManaMax2;
            item.GetGlobalItem<AEUpdate1>().endurance = endurance;
        }
        public override void ModifyValue(ref float valueMult)
        {
            float multiplier = 1f * (1 + tier * 0.5f);
            valueMult *= multiplier;
        }
    }
}