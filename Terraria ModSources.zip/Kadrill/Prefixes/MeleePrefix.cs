using System.Collections.Generic;
using Terraria.Utilities;
using Terraria;
using Terraria.ModLoader;

namespace Kadrill.Prefixes
{
    [Autoload(false)]
    public class MeleePrefix : ModPrefix
    {
        public class MeleePrefixLoader : ILoadable
		{
			public void Load(Mod mod) {
                mod.AddContent(new MeleePrefix("Giga", 1f, 1f, 1f, 0, 2f));
                if (ModContent.GetInstance<KadrillConfig>().KadrillReforge == true)
				{
				mod.AddContent(new MeleePrefix("Kami", 10f, 0.33f, 1f, 100, 2f));
				}
			}

			public void Unload() { }
		}

        public override string Name => _name;
		private readonly string _name;
        internal int critBonus = 0;
        internal float damageMult = 1f;
        internal float knockbackMult = 1f;
        internal float scaleMult = 1f;
        internal float useTimeMult = 1f;

		public override PrefixCategory Category { get { return PrefixCategory.Melee; } }

        public MeleePrefix() { }

        public MeleePrefix(string name, float damageMult = 1f, float knockbackMult = 1f, float useTimeMult = 1f, int critBonus = 0, float scaleMult = 1f)
        {
            _name = name;
            this.damageMult = damageMult;
            this.knockbackMult = knockbackMult;
            this.useTimeMult = useTimeMult;
            this.critBonus = critBonus;
            this.scaleMult = scaleMult;
        }

        public override void ModifyValue(ref float valueMult) { valueMult *= 1; }

        public override bool CanRoll(Item item)
        {

            if (item.noUseGraphic == true && item.CountsAsClass(DamageClass.Melee) == false && item.useStyle != 13 && item.type != 4956)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public override float RollChance(Item item) { return 1f; }

        public override void SetStats(ref float damageMult, ref float knockbackMult, ref float useTimeMult, ref float scaleMult, ref float shootSpeedMult, ref float manaMult, ref int critBonus)
        {
            damageMult = this.damageMult;
            knockbackMult = this.knockbackMult;
            useTimeMult = this.useTimeMult;
            critBonus = this.critBonus;
            scaleMult = this.scaleMult;
        }
    }
}
