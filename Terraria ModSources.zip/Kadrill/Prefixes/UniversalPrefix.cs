using System.Collections.Generic;
using Terraria.Utilities;
using Terraria;
using Terraria.ModLoader;

namespace Kadrill.Prefixes
{
    [Autoload(false)]
    public class UniversalPrefix : ModPrefix
    {
        public class UniversalPrefixLoader : ILoadable
		{
			public void Load(Mod mod) {
                mod.AddContent(new UniversalPrefix("Useless", 0.5f, 0.5f, 2f, 0));
                mod.AddContent(new UniversalPrefix("High", 1f, 3f, 1f, 0));
                if (ModContent.GetInstance<KadrillConfig>().KadrillReforge == true)
				{
                mod.AddContent(new UniversalPrefix("Gamble", 1f, 1f, 1f, 100));
                mod.AddContent(new UniversalPrefix("Kagh", 10f, 0.64f, 1f, 100));
                mod.AddContent(new UniversalPrefix("Kadrill", 4f, 1f, 0.4f, 100));
				}
			}

			public void Unload() { }
		}

        public override string Name => _name;
		private readonly string _name;
        internal int critBonus = 0;
        internal float damageMult = 1f;
        internal float knockbackMult = 1f;
        internal float useTimeMult = 1f;

        public override PrefixCategory Category { get { return PrefixCategory.AnyWeapon;} }

        public UniversalPrefix() { }

        public UniversalPrefix(string name, float damageMult = 1f, float knockbackMult = 1f, float useTimeMult = 1f, int critBonus = 0)
        {
            _name = name;
            this.damageMult = damageMult;
            this.knockbackMult = knockbackMult;
            this.useTimeMult = useTimeMult;
            this.critBonus = critBonus;
        }

        public override void ModifyValue(ref float valueMult) { valueMult *= 1; }

        public override bool CanRoll(Item item) { return true; }

        public override float RollChance(Item item) { return 1f; }

        public override void SetStats(ref float damageMult, ref float knockbackMult, ref float useTimeMult, ref float scaleMult, ref float shootSpeedMult, ref float manaMult, ref int critBonus)
        {
            damageMult = this.damageMult;
            knockbackMult = this.knockbackMult;
            useTimeMult = this.useTimeMult;
            critBonus = this.critBonus;
        }
    }
}
