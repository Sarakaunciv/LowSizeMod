using System.Collections.Generic;
using Terraria.Utilities;
using Terraria;
using Terraria.ModLoader;

namespace Kadrill.Prefixes
{
    [Autoload(false)]
    public class RangedPrefix : ModPrefix
    {
        public class RangedPrefixLoader : ILoadable
		{
			public void Load(Mod mod) {
                mod.AddContent(new RangedPrefix("Instant", 1f, 1f, 1f, 0, 2f));
                if (ModContent.GetInstance<KadrillConfig>().KadrillReforge == true)
				{
                mod.AddContent(new RangedPrefix("Kamiang", 10f, 0.33f, 1f, 100, 2f));
				}
			}

			public void Unload() { }
		}

        public override string Name => _name;
		private readonly string _name;
        internal int critBonus = 0;
        internal float damageMult = 1f;
        internal float knockbackMult = 1f;
        internal float shootSpeedMult = 1f;
        internal float useTimeMult = 1f;

        public override PrefixCategory Category { get { return PrefixCategory.Ranged; } }


        public RangedPrefix() { }

        public RangedPrefix(string name, float damageMult = 1f, float knockbackMult = 1f, float useTimeMult = 1f, int critBonus = 0, float shootSpeedMult = 1f)
        {
            _name = name;
            this.damageMult = damageMult;
            this.knockbackMult = knockbackMult;
            this.useTimeMult = useTimeMult;
            this.critBonus = critBonus;
            this.shootSpeedMult = shootSpeedMult;
        }

        public override void ModifyValue(ref float valueMult) { valueMult *= 1; }

        public override bool CanRoll(Item item) { return true; }

        public override float RollChance(Item item) { return 1f; }

        public override void SetStats(ref float damageMult, ref float knockbackMult, ref float useTimeMult, ref float scaleMult, ref float shootSpeedMult, ref float manaMult, ref int critBonus)
        {
            damageMult = this.damageMult;
            knockbackMult = this.knockbackMult;
            useTimeMult = this.useTimeMult;
            critBonus = this.critBonus;
            shootSpeedMult = this.shootSpeedMult;
        }
    }
}
