extends Control

@onready var a: Button = $a
var wall_p: int = 150
@onready var b: Button = $b
var piercer_p: int = 300000
@onready var c: Button = $c
var spike_p: int = 50000
@onready var d: Button = $d
var mine_p: int = 50
@onready var e: Button = $e
var explosive_p: int = 5000
@onready var f: Button = $f
var stop_p: int = 400
@onready var g: Button = $g
var diverter_p: int = 100
@onready var upg: Button = $upg
var upg_p: int = 250
@onready var upg_level_label: Label = $upg/ColorRect/Label
var upg_p_level: int = 0
func _ready() -> void:
	a.price = wall_p
	b.price = piercer_p
	c.price = spike_p
	d.price = mine_p
	e.price = explosive_p
	f.price = stop_p
	g.price = diverter_p
	update_is_buy_done()

func update_is_buy_done():
	if Config.is_wall_unlock == true:
		a.is_buy_done = true
	a.ready0()
	if Config.is_piercer_unlock == true:
		b.is_buy_done = true
	b.ready0()
	if Config.is_spike_unlock == true:
		c.is_buy_done = true
	c.ready0()
	if Config.is_mine_unlock == true:
		d.is_buy_done = true
	d.ready0()
	if Config.is_explosive_unlock == true:
		e.is_buy_done = true
	e.ready0()
	if Config.is_stop_unlock == true:
		f.is_buy_done = true
	f.ready0()
	if Config.is_diverter_unlock == true:
		g.is_buy_done = true
	g.ready0()
	if Config.max_upgrade_level == 6:
		upg.is_buy_done = true
	upg.price = upg_p * Config.max_upgrade_level_price
	upg_level_label.text = str(Config.max_upgrade_level)
	upg.ready0()

func _on_a_pressed() -> void:
	if Config.money >= wall_p and Config.is_wall_unlock == false:
		Config.add_money(wall_p * -1)
		Config.is_wall_unlock = true
		update_is_buy_done()
func _on_b_pressed() -> void:
	if Config.money >= piercer_p and Config.is_piercer_unlock == false:
		Config.add_money(piercer_p * -1)
		Config.is_piercer_unlock = true
		update_is_buy_done()
func _on_c_pressed() -> void:
	if Config.money >= spike_p and Config.is_spike_unlock == false:
		Config.add_money(spike_p * -1)
		Config.is_spike_unlock = true
		update_is_buy_done()
func _on_d_pressed() -> void:
	if Config.money >= mine_p and Config.is_mine_unlock == false:
		Config.add_money(mine_p * -1)
		Config.is_mine_unlock = true
		update_is_buy_done()
func _on_e_pressed() -> void:
	if Config.money >= explosive_p and Config.is_explosive_unlock == false:
		Config.add_money(explosive_p * -1)
		Config.is_explosive_unlock = true
		update_is_buy_done()
func _on_f_pressed() -> void:
	if Config.money >= stop_p and Config.is_stop_unlock == false:
		Config.add_money(stop_p * -1)
		Config.is_stop_unlock = true
		update_is_buy_done()
func _on_g_pressed() -> void:
	if Config.money >= diverter_p and Config.is_diverter_unlock == false:
		Config.add_money(diverter_p * -1)
		Config.is_diverter_unlock = true
		update_is_buy_done()
func _on_upg_pressed() -> void:
	if Config.money >= upg_p * Config.max_upgrade_level_price and Config.max_upgrade_level < 6:
		Config.add_money(upg_p * Config.max_upgrade_level_price * -1)
		Config.max_upgrade_level += 1
		Config.max_upgrade_level_price *= 4
		update_is_buy_done()
