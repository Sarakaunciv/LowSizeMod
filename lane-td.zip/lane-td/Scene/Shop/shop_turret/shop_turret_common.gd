extends Control

var is_buy_done = false
@onready var sprite_2d1: Sprite2D = $Sprite2D/Sprite2D
@onready var color_rect: ColorRect = $Sprite2D/Sprite2D/Sprite2D/ColorRect
func ready0() -> void:
	if is_buy_done == true:
		sprite_2d1.region_rect.position = Vector2(32, 8)
	update_price_label()
	color_rect.z_index = 1

var price: int = 0
@onready var label: Label = $Sprite2D/Sprite2D/Sprite2D/ColorRect/Label
func update_price_label():
	if is_buy_done == true:
		label.text = str("Sold Out")
	else:
		label.text = str(price)

@onready var sprite_2d2: Sprite2D = $Sprite2D/Sprite2D/Sprite2D
func _on_mouse_entered() -> void:
	if is_buy_done == true:
		return
	else:
		sprite_2d2.visible = true
func _on_mouse_exited() -> void:
	sprite_2d2.visible = false
