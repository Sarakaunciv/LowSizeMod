extends Control

func _ready() -> void:
	filter_ignore_for_all_rect()

func filter_ignore_for_all_rect():
	for child in self.find_children("*"):
		if child is ColorRect:
			child.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _on_back_pressed() -> void:
	Save.save0()
	get_tree().change_scene_to_file("res://Scene/level_menu.tscn")
