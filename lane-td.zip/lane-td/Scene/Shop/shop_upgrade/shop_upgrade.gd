extends Control

var wall_u_p: int = 8000
var energy_u_p: int = 50
var explosive_u_p: int = 2500
var stop_u_p: int = 250
var attacker_u_p: int = 1000
var piercer_u_p: int = 781250
func _ready() -> void:
	update_wall_text()
	update_energy_text()
	update_explosive_text()
	update_stop_text()
	update_attacker_text()
	update_piercer_text()

@onready var wall_price_label: Label = $Wall/Button/AddA/ColorRect/Label
@onready var wall_level_label: Label = $Wall/ColorRect/Level
@onready var wall_level_max_label: Label = $Wall/ColorRect2/LevelMax
func update_wall_text():
	wall_price_label.text = str(Config.wall_upgrade_level_price * wall_u_p)
	wall_level_label.text = str(Config.wall_upgrade_level)
	wall_level_max_label.text = str(Config.wall_upgrade_level_max)

@onready var wall_price_rect: ColorRect = $Wall/Button/AddA/ColorRect
func _on_add_a_mouse_entered() -> void:
	if Config.wall_upgrade_level == Config.wall_upgrade_level_max and Config.wall_upgrade_level_max != 9:
		wall_price_rect.visible = true
	else:
		wall_price_rect.visible = false
func _on_add_a_mouse_exited() -> void:
	wall_price_rect.visible = false

func _on_add_a_pressed() -> void:
	if Config.wall_upgrade_level == Config.wall_upgrade_level_max and Config.money >= Config.wall_upgrade_level_price * wall_u_p and Config.wall_upgrade_level_max != 8:
		Config.add_money(Config.wall_upgrade_level_price * wall_u_p * -1)
		Config.wall_upgrade_level += 1
		Config.wall_upgrade_level_max += 1
		Config.wall_upgrade_level_price *= 4
	elif Config.wall_upgrade_level < Config.wall_upgrade_level_max:
		Config.wall_upgrade_level += 1
	_on_add_a_mouse_entered()
	update_wall_text()
func _on_sub_a_pressed() -> void:
	if Config.wall_upgrade_level > 0:
		Config.wall_upgrade_level -= 1
	update_wall_text()

@onready var energy_price_label: Label = $Energy/Button/AddB/ColorRect/Label
@onready var energy_level_label: Label = $Energy/ColorRect/Level
@onready var energy_level_max_label: Label = $Energy/ColorRect2/LevelMax
func update_energy_text():
	energy_price_label.text = str(Config.energy_upgrade_level_price * energy_u_p)
	energy_level_label.text = str(Config.energy_upgrade_level)
	energy_level_max_label.text = str(Config.energy_upgrade_level_max)

@onready var energy_price_rect: ColorRect = $Energy/Button/AddB/ColorRect
func _on_add_b_mouse_entered() -> void:
	if Config.energy_upgrade_level == Config.energy_upgrade_level_max and Config.energy_upgrade_level_max != 5:
		energy_price_rect.visible = true
	else:
		energy_price_rect.visible = false
func _on_add_b_mouse_exited() -> void:
	energy_price_rect.visible = false

func _on_add_b_pressed() -> void:
	if Config.energy_upgrade_level == Config.energy_upgrade_level_max and Config.money >= Config.energy_upgrade_level_price * energy_u_p and Config.energy_upgrade_level_max != 5:
		Config.add_money(Config.energy_upgrade_level_price * energy_u_p * -1)
		Config.energy_upgrade_level += 1
		Config.energy_upgrade_level_max += 1
		Config.energy_upgrade_level_price *= 2
	elif Config.energy_upgrade_level < Config.energy_upgrade_level_max:
		Config.energy_upgrade_level += 1
	_on_add_b_mouse_entered()
	update_energy_text()
func _on_sub_b_pressed() -> void:
	if Config.energy_upgrade_level > 1:
		Config.energy_upgrade_level -= 1
	update_energy_text()

@onready var explosive_price_label: Label = $Explosive/Button/AddC/ColorRect/Label
@onready var explosive_level_label: Label = $Explosive/ColorRect/Level
@onready var explosive_level_max_label: Label = $Explosive/ColorRect2/LevelMax
func update_explosive_text():
	explosive_price_label.text = str(Config.explosive_upgrade_level_price * explosive_u_p)
	explosive_level_label.text = str(Config.explosive_upgrade_level)
	explosive_level_max_label.text = str(Config.explosive_upgrade_level_max)

@onready var explosive_price_rect: ColorRect = $Explosive/Button/AddC/ColorRect
func _on_add_c_mouse_entered() -> void:
	if Config.explosive_upgrade_level == Config.explosive_upgrade_level_max and Config.explosive_upgrade_level_max != 15:
		explosive_price_rect.visible = true
	else:
		explosive_price_rect.visible = false
func _on_add_c_mouse_exited() -> void:
	explosive_price_rect.visible = false

func _on_add_c_pressed() -> void:
	if Config.explosive_upgrade_level == Config.explosive_upgrade_level_max and Config.money >= Config.explosive_upgrade_level_price * explosive_u_p and Config.explosive_upgrade_level_max != 15:
		Config.add_money(Config.explosive_upgrade_level_price * explosive_u_p * -1)
		Config.explosive_upgrade_level += 1
		Config.explosive_upgrade_level_max += 1
		Config.explosive_upgrade_level_price *= 2
	elif Config.explosive_upgrade_level < Config.explosive_upgrade_level_max:
		Config.explosive_upgrade_level += 1
	_on_add_c_mouse_entered()
	update_explosive_text()
func _on_sub_c_pressed() -> void:
	if Config.explosive_upgrade_level > 1:
		Config.explosive_upgrade_level -= 1
	update_explosive_text()

@onready var stop_price_label: Label = $Stop/Button/AddD/ColorRect/Label
@onready var stop_level_label: Label = $Stop/ColorRect/Level
@onready var stop_level_max_label: Label = $Stop/ColorRect2/LevelMax
func update_stop_text():
	stop_price_label.text = str(Config.stop_upgrade_level_price * stop_u_p)
	stop_level_label.text = str(Config.stop_upgrade_level)
	stop_level_max_label.text = str(Config.stop_upgrade_level_max)

@onready var stop_price_rect: ColorRect = $Stop/Button/AddD/ColorRect
func _on_add_d_mouse_entered() -> void:
	if Config.stop_upgrade_level == Config.stop_upgrade_level_max and Config.stop_upgrade_level_max != 15:
		stop_price_rect.visible = true
	else:
		stop_price_rect.visible = false
func _on_add_d_mouse_exited() -> void:
	stop_price_rect.visible = false

func _on_add_d_pressed() -> void:
	if Config.stop_upgrade_level == Config.stop_upgrade_level_max and Config.money >= Config.stop_upgrade_level_price * stop_u_p and Config.stop_upgrade_level_max != 15:
		Config.add_money(Config.stop_upgrade_level_price * stop_u_p * -1)
		Config.stop_upgrade_level += 1
		Config.stop_upgrade_level_max += 1
		Config.stop_upgrade_level_price *= 2
	elif Config.stop_upgrade_level < Config.stop_upgrade_level_max:
		Config.stop_upgrade_level += 1
	_on_add_d_mouse_entered()
	update_stop_text()
func _on_sub_d_pressed() -> void:
	if Config.stop_upgrade_level > 1:
		Config.stop_upgrade_level -= 1
	update_stop_text()

@onready var attacker_price_label: Label = $Attacker/Button/AddE/ColorRect/Label
@onready var attacker_level_label: Label = $Attacker/ColorRect/Level
@onready var attacker_level_max_label: Label = $Attacker/ColorRect2/LevelMax
func update_attacker_text():
	attacker_price_label.text = str(Config.attacker_upgrade_level_price * attacker_u_p)
	attacker_level_label.text = str(Config.attacker_upgrade_level)
	attacker_level_max_label.text = str(Config.attacker_upgrade_level_max)

@onready var attacker_price_rect: ColorRect = $Attacker/Button/AddE/ColorRect
func _on_add_e_mouse_entered() -> void:
	if Config.attacker_upgrade_level == Config.attacker_upgrade_level_max and Config.attacker_upgrade_level_max != 4:
		attacker_price_rect.visible = true
	else:
		attacker_price_rect.visible = false
func _on_add_e_mouse_exited() -> void:
	attacker_price_rect.visible = false

func _on_add_e_pressed() -> void:
	if Config.attacker_upgrade_level == Config.attacker_upgrade_level_max and Config.money >= Config.attacker_upgrade_level_price * attacker_u_p and Config.attacker_upgrade_level_max != 4:
		Config.add_money(Config.attacker_upgrade_level_price * attacker_u_p * -1)
		Config.attacker_upgrade_level += 1
		Config.attacker_upgrade_level_max += 1
		Config.attacker_upgrade_level_price *= 4
	elif Config.attacker_upgrade_level < Config.attacker_upgrade_level_max:
		Config.attacker_upgrade_level += 1
	_on_add_e_mouse_entered()
	update_attacker_text()
func _on_sub_e_pressed() -> void:
	if Config.attacker_upgrade_level > 0:
		Config.attacker_upgrade_level -= 1
	update_attacker_text()

@onready var piercer_price_label: Label = $Piercer/Button/AddF/ColorRect/Label
@onready var piercer_level_label: Label = $Piercer/ColorRect/Level
@onready var piercer_level_max_label: Label = $Piercer/ColorRect2/LevelMax
func update_piercer_text():
	piercer_price_label.text = str(Config.piercer_upgrade_level_price * piercer_u_p)
	piercer_level_label.text = str(Config.piercer_upgrade_level)
	piercer_level_max_label.text = str(Config.piercer_upgrade_level_max)

@onready var piercer_price_rect: ColorRect = $Piercer/Button/AddF/ColorRect
func _on_add_f_mouse_entered() -> void:
	if Config.piercer_upgrade_level == Config.piercer_upgrade_level_max and Config.piercer_upgrade_level_max != 3:
		piercer_price_rect.visible = true
	else:
		piercer_price_rect.visible = false
func _on_add_f_mouse_exited() -> void:
	piercer_price_rect.visible = false

func _on_add_f_pressed() -> void:
	if Config.piercer_upgrade_level == Config.piercer_upgrade_level_max and Config.money >= Config.piercer_upgrade_level_price * piercer_u_p and Config.piercer_upgrade_level_max != 3:
		Config.add_money(Config.piercer_upgrade_level_price * piercer_u_p * -1)
		Config.piercer_upgrade_level += 1
		Config.piercer_upgrade_level_max += 1
		Config.piercer_upgrade_level_price *= 16
	elif Config.piercer_upgrade_level < Config.piercer_upgrade_level_max:
		Config.piercer_upgrade_level += 1
	_on_add_f_mouse_entered()
	update_piercer_text()
func _on_sub_f_pressed() -> void:
	if Config.piercer_upgrade_level > 0:
		Config.piercer_upgrade_level -= 1
	update_piercer_text()
