extends Control

var wall_u_p: int = 4000
var energy_u_p: int = 250
func _ready() -> void:
	update_wall_text()
	update_energy_text()

@onready var wall_price_label: Label = $Wall/Button/AddA/ColorRect/Label
@onready var wall_level_label: Label = $Wall/ColorRect/Level
@onready var wall_level_max_label: Label = $Wall/ColorRect2/LevelMax
func update_wall_text():
	wall_price_label.text = str(Config.wall_upgrade_level_price * wall_u_p)
	wall_level_label.text = str(Config.wall_upgrade_level)
	wall_level_max_label.text = str(Config.wall_upgrade_level_max)

@onready var wall_price_rect: ColorRect = $Wall/Button/AddA/ColorRect
func _on_add_a_mouse_entered() -> void:
	if Config.wall_upgrade_level == Config.wall_upgrade_level_max and Config.wall_upgrade_level_max != 9:
		wall_price_rect.visible = true
	else:
		wall_price_rect.visible = false
func _on_add_a_mouse_exited() -> void:
	wall_price_rect.visible = false

func _on_add_a_pressed() -> void:
	if Config.wall_upgrade_level == Config.wall_upgrade_level_max and Config.money >= Config.wall_upgrade_level_price * wall_u_p and Config.wall_upgrade_level_max != 9:
		Config.add_money(Config.wall_upgrade_level_price * wall_u_p * -1)
		Config.wall_upgrade_level += 1
		Config.wall_upgrade_level_max += 1
		Config.wall_upgrade_level_price *= 2
	elif Config.wall_upgrade_level < Config.wall_upgrade_level_max:
		Config.wall_upgrade_level += 1
	_on_add_a_mouse_entered()
	update_wall_text()
func _on_sub_a_pressed() -> void:
	if Config.wall_upgrade_level > 1:
		Config.wall_upgrade_level -= 1
	update_wall_text()

@onready var energy_price_label: Label = $Energy/Button/AddB/ColorRect/Label
@onready var energy_level_label: Label = $Energy/ColorRect/Level
@onready var energy_level_max_label: Label = $Energy/ColorRect2/LevelMax
func update_energy_text():
	energy_price_label.text = str(Config.energy_upgrade_level_price * energy_u_p)
	energy_level_label.text = str(Config.energy_upgrade_level)
	energy_level_max_label.text = str(Config.energy_upgrade_level_max)

@onready var energy_price_rect: ColorRect = $Energy/Button/AddB/ColorRect
func _on_add_b_mouse_entered() -> void:
	if Config.energy_upgrade_level == Config.energy_upgrade_level_max and Config.energy_upgrade_level_max != 5:
		energy_price_rect.visible = true
	else:
		energy_price_rect.visible = false
func _on_add_b_mouse_exited() -> void:
	energy_price_rect.visible = false

func _on_add_b_pressed() -> void:
	if Config.energy_upgrade_level == Config.energy_upgrade_level_max and Config.money >= Config.energy_upgrade_level_price * energy_u_p and Config.energy_upgrade_level_max != 5:
		Config.add_money(Config.energy_upgrade_level_price * energy_u_p * -1)
		Config.energy_upgrade_level += 1
		Config.energy_upgrade_level_max += 1
		Config.energy_upgrade_level_price *= 2
	elif Config.energy_upgrade_level < Config.energy_upgrade_level_max:
		Config.energy_upgrade_level += 1
	_on_add_b_mouse_entered()
	update_energy_text()
func _on_sub_b_pressed() -> void:
	if Config.energy_upgrade_level > 1:
		Config.energy_upgrade_level -= 1
	update_energy_text()
