extends Control

func _ready() -> void:
	update_level_label()

func _on_shop_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/shop.tscn")

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/level_1.tscn")

@onready var level_label: Label = $ColorRect/LevelLabel
func update_level_label():
	if Config.level_world > Config.level_max:
		Config.level_world = Config.level_max
	if Config.level_world < 0:
		Config.level_world = 0
	level_label.text = str(Config.level_world)

func _on_add_a_pressed() -> void:
	Config.level_world += 1
	update_level_label()
func _on_sub_a_pressed() -> void:
	Config.level_world -= 1
	update_level_label()

func _on_add_b_pressed() -> void:
	Config.level_world += 10
	update_level_label()
func _on_sub_b_pressed() -> void:
	Config.level_world -= 10
	update_level_label()
