extends Control

func _ready() -> void:
	update_level_label()
	filter_ignore_for_all_rect()

func filter_ignore_for_all_rect():
	for child in self.find_children("*"):
		if child is ColorRect:
			child.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _on_shop_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/Shop/shop.tscn")

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/level_1.tscn")

var count_to_0: int = 0
@onready var level_label: Label = $ColorRect/LevelLabel
func update_level_label():
	if Config.level_world > Config.level_max:
		Config.level_world = Config.level_max
	if Config.level_world < 1:
		Config.level_world = 1
		count_to_0 += 1
		if count_to_0 >= 4:
			Config.level_world = 0
		if count_to_0 >= 8:#
			debug0()#
	level_label.text = str(Config.level_world)

@onready var debug_0_rect: ColorRect = $Debug0
@onready var debug_0: Label = $Debug0/Debug0
func debug0():
	debug_0.text = str("Hello")
	debug_0_rect.visible = true

func _on_add_a_pressed() -> void:
	Config.level_world += 1
	update_level_label()
func _on_sub_a_pressed() -> void:
	Config.level_world -= 1
	update_level_label()

func _on_add_b_pressed() -> void:
	Config.level_world += 10
	update_level_label()
func _on_sub_b_pressed() -> void:
	Config.level_world -= 10
	update_level_label()
