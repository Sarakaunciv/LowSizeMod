extends Control

func _ready() -> void:
	update_energy_start()
	update_energy_buy_mode_label()
	energy_max.text = str(Config.energy_start_level_max * 5)

func _on_back_pressed() -> void:
	Save.save0()
	get_tree().change_scene_to_file("res://Scene/level_menu.tscn")

func _on_buy_mode_pressed() -> void:
	if Config.is_energy_buy == true:
		Config.is_energy_buy = false
	else:
		Config.is_energy_buy = true
	update_energy_buy_mode_label()
@onready var buy_mode_label: Label = $Energy/BuyMode/BuyModeLabel
func update_energy_buy_mode_label():
	if Config.is_energy_buy == true:
		buy_mode_label.text = str("Buy on")
	else:
		buy_mode_label.text = str("Buy off")

@onready var energy_label: Label = $Energy/ColorRect/EnergyLabel
func update_energy_start():
	if Config.energy_start_level > Config.energy_start_level_max:
		Config.energy_start_level = Config.energy_start_level_max
	if Config.energy_start_level < 0:
		Config.energy_start_level = 0
	Config.energy_start = Config.energy_start_level * 5
	energy_label.text = str(Config.energy_start)

@onready var energy_max: Label = $Energy/ColorRect2/EnergyMax
func buy_energy(buy_amount):
	for buy in range(buy_amount):
		if Config.money >= Config.energy_start_level_max * 50 + 50:
			Config.add_money(Config.energy_start_level_max * 50 * -1 - 50)
			Config.energy_start_level_max += 1
	energy_max.text = str(Config.energy_start_level_max * 5)

func _on_add_a_pressed() -> void:
	if Config.is_energy_buy == true:
		buy_energy(1)
	else:
		Config.energy_start_level += 1
		update_energy_start()
func _on_sub_a_pressed() -> void:
	Config.energy_start_level -= 1
	update_energy_start()

func _on_add_b_pressed() -> void:
	if Config.is_energy_buy == true:
		buy_energy(10)
	else:
		Config.energy_start_level += 10
		update_energy_start()
func _on_sub_b_pressed() -> void:
	Config.energy_start_level -= 10
	update_energy_start()

func _on_add_c_pressed() -> void:
	if Config.is_energy_buy == true:
		buy_energy(100)
	else:
		Config.energy_start_level += 100
func _on_sub_c_button_up() -> void:
	Config.energy_start_level -= 100
	update_energy_start()

func _on_add_d_pressed() -> void:
	if Config.is_energy_buy == true:
		buy_energy(1000)
	else:
		Config.energy_start_level += 1000
func _on_sub_d_pressed() -> void:
	Config.energy_start_level -= 1000
	update_energy_start()

func _on_add_e_pressed() -> void:
	if Config.is_energy_buy == true:
		buy_energy(10000)
	else:
		Config.energy_start_level += 10000
func _on_sub_e_pressed() -> void:
	Config.energy_start_level -= 10000
	update_energy_start()
