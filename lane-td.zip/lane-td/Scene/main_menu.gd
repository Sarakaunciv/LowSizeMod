extends Control

func _ready() -> void:
	Save.load0()

func _on_start_b_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/level_menu.tscn")

func _on_quit_b_pressed() -> void:
	get_tree().quit()
