extends Control

func _ready() -> void:
	update_level_label()

@onready var level_label: Label = $ColorRect/LevelLabel
func update_level_label():
	if LevelManager.level_world > LevelManager.level_max:
		LevelManager.level_world = LevelManager.level_max
	if LevelManager.level_world < 0:
		LevelManager.level_world = 0
	level_label.text = str(LevelManager.level_world)

#var level0 = load("res://Scene/level_1.tscn")
#var level
#func _on_start_pressed() -> void:
	#level = level0.instantiate()
	#add_child(level)

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/level_1.tscn")

func _on_add_a_pressed() -> void:
	LevelManager.level_world += 1
	update_level_label()

func _on_sub_a_pressed() -> void:
	LevelManager.level_world -= 1
	update_level_label()
