extends Node

var BaseBaseBase1_Cost: int = -10 #
var BaseBaseBase2_Cost: int = -20 #
var BaseBaseBase3_Cost: int = -30 #
var BaseBaseBase4_Cost: int = -40 #
var BaseBaseBase5_Cost: int = -50 #
var BaseBaseBase6_Cost: int = -200 #

#ID
var Energizer1_ID: int = 1
var Attacker1_ID: int = 2
var Wall1_ID: int = 3
var Piercer1_ID: int = 4
var Spike1_ID: int = 5
var Mine1_ID: int = 6
var Explosive1_ID: int = 7
var Stop1_ID: int = 8
var Diverter1_ID: int = 9

var Remover_ID: int = 101
var Upgrader_ID: int = 102

#Energy Cost
var Energizer1_Cost: int = -20 # 15
var Energizer2_Cost: int = -60 # 50 #80
var Energizer3_Cost: int = -240 # 150 #320
var Energizer4_Cost: int = -1280 # 600 #1600
var Energizer5_Cost: int = -6400 # 2400 #8000
var Energizer6_Cost: int = -32000 # 10000 #40000
var Attacker1_Cost: int = -40 # 1 20 20
var Attacker2_Cost: int = -50 # 2 20 40 #90
var Attacker3_Cost: int = -60 # 3 20 60 #150
var Attacker4_Cost: int = -200 # 3 40 120 #350
var Attacker5_Cost: int = -450 # 3 80 240 #800
var Attacker6_Cost: int = -3200 # 4 200 800 #4000
var Wall1_Cost: int = -40 # 1
var Wall2_Cost: int = -120 # 4 #160
var Wall3_Cost: int = -480 # 16 #640
var Wall4_Cost: int = -2560 # 80 #3200
var Wall5_Cost: int = -12800 # 400 #16000
var Wall6_Cost: int = -64000 # 2000 #80000
var Piercer1_Cost: int = -4000 # 1 20 20
var Piercer2_Cost: int = -5000 # 2 20 40 #9000
var Piercer3_Cost: int = -6000 # 3 20 60 #15000
var Piercer4_Cost: int = -20000 # 3 40 120 #35000
var Piercer5_Cost: int = -45000 # 3 80 240 #80000
var Piercer6_Cost: int = -320000 # 4 200 800 #400000
var Spike1_Cost: int = -600 # 1 4
var Spike2_Cost: int = -750 # 2 8 #1350
var Spike3_Cost: int = -900 # 3 12 #2250
var Spike4_Cost: int = -3000 # 3 24 #5250
var Spike5_Cost: int = -6750 # 3 48 #12000
var Spike6_Cost: int = -48000 # 4 160 #60000

var Mine1_Cost: int = -30 # 1
var Mine2_Cost: int = -90 # 4 #120
var Mine3_Cost: int = -480 # 20 #600
var Explosive1_Cost: int = -2000 # 1
var Explosive2_Cost: int = -8000 # 4 #10000
var Explosive3_Cost: int = -50000 # 20 #60000
var Stop1_Cost: int = -500 # 1
var Stop2_Cost: int = -2000 # 4 #2500
var Stop3_Cost: int = -12500 # 20 #15000
var Diverter1_Cost: int = -400 # 1
var Diverter2_Cost: int = -7600 # 20 #8000
var Diverter3_Cost: int = -152000 # 400 #160000

#Enemy
var basic_0_p: int = 3 #3
var fast_0_p: int = 8 #5
var strong_0_p: int = 16 #8
var tank_0_p: int = 30 #14
var massive_0_p: int = 60 #30

var basic_v: int = 1
var fast_v: int = 2
var strong_v: int = 5
var tank_v: int = 12
var massive_v: int = 50

#ECT
var Diverter2_Color: Color = Color(0.5, 1, 0.5)
var Diverter3_Color: Color = Color(1, 0, 0.5)
