extends Node

const save_location0 = "user://Save.json"

var content: Dictionary = {
	"level_world": Config.level_world,
	"level_max": Config.level_max,
	
	"money": Config.money,
	
	"is_energy_buy": Config.is_energy_buy,
	"energy_start": Config.energy_start,
	"energy_start_level": Config.energy_start_level,
	"energy_start_level_max": Config.energy_start_level_max,
	
	"pierce_to_frag": Config.pierce_to_frag,
	
	"is_wall_unlock": Config.is_wall_unlock,
	"is_piercer_unlock": Config.is_piercer_unlock,
	"is_spike_unlock": Config.is_spike_unlock,
	"is_mine_unlock": Config.is_mine_unlock,
	"is_explosive_unlock": Config.is_explosive_unlock,
	"is_stop_unlock": Config.is_stop_unlock,
	"is_diverter_unlock": Config.is_diverter_unlock,
	"max_upgrade_level": Config.max_upgrade_level,
	"max_upgrade_level_price": Config.max_upgrade_level_price,
	
	"wall_upgrade_level": Config.wall_upgrade_level,
	"wall_upgrade_level_max": Config.wall_upgrade_level_max,
	"wall_upgrade_level_price": Config.wall_upgrade_level_price,
	"energy_upgrade_level": Config.energy_upgrade_level,
	"energy_upgrade_level_max": Config.energy_upgrade_level_max,
	"energy_upgrade_level_price": Config.energy_upgrade_level_price,
	"explosive_upgrade_level": Config.explosive_upgrade_level,
	"explosive_upgrade_level_max": Config.explosive_upgrade_level_max,
	"explosive_upgrade_level_price": Config.explosive_upgrade_level_price,
	"stop_upgrade_level": Config.stop_upgrade_level,
	"stop_upgrade_level_max": Config.stop_upgrade_level_max,
	"stop_upgrade_level_price": Config.stop_upgrade_level_price,
	"attacker_upgrade_level": Config.attacker_upgrade_level,
	"attacker_upgrade_level_max": Config.attacker_upgrade_level_max,
	"attacker_upgrade_level_price": Config.attacker_upgrade_level_price,
	"piercer_upgrade_level": Config.piercer_upgrade_level,
	"piercer_upgrade_level_max": Config.piercer_upgrade_level_max,
	"piercer_upgrade_level_price": Config.piercer_upgrade_level_price
}

func save0():
	var file0 = FileAccess.open(save_location0, FileAccess.WRITE)
	save_cnfg()
	file0.store_var(content.duplicate())
	file0.close()

func load0():
	if FileAccess.file_exists(save_location0):
		var file0 = FileAccess.open(save_location0, FileAccess.READ)
		var data = file0.get_var()
		file0.close()
		
		var save_data = data.duplicate()
		content.level_world = save_data.level_world
		content.level_max = save_data.level_max
		
		content.money = save_data.money
		
		content.is_energy_buy = save_data.is_energy_buy
		content.energy_start = save_data.energy_start
		content.energy_start_level = save_data.energy_start_level
		content.energy_start_level_max = save_data.energy_start_level_max
		
		content.pierce_to_frag = save_data.pierce_to_frag
		
		content.is_wall_unlock = save_data.is_wall_unlock
		content.is_piercer_unlock = save_data.is_piercer_unlock
		content.is_spike_unlock = save_data.is_spike_unlock
		content.is_mine_unlock = save_data.is_mine_unlock
		content.is_explosive_unlock = save_data.is_explosive_unlock
		content.is_stop_unlock = save_data.is_stop_unlock
		content.is_diverter_unlock = save_data.is_diverter_unlock
		content.max_upgrade_level = save_data.max_upgrade_level
		content.max_upgrade_level_price = save_data.max_upgrade_level_price
		
		content.wall_upgrade_level = save_data.wall_upgrade_level
		content.wall_upgrade_level_max = save_data.wall_upgrade_level_max
		content.wall_upgrade_level_price = save_data.wall_upgrade_level_price
		content.energy_upgrade_level = save_data.energy_upgrade_level
		content.energy_upgrade_level_max = save_data.energy_upgrade_level_max
		content.energy_upgrade_level_price = save_data.energy_upgrade_level_price
		content.explosive_upgrade_level = save_data.explosive_upgrade_level
		content.explosive_upgrade_level_max = save_data.explosive_upgrade_level_max
		content.explosive_upgrade_level_price = save_data.explosive_upgrade_level_price
		content.stop_upgrade_level = save_data.stop_upgrade_level
		content.stop_upgrade_level_max = save_data.stop_upgrade_level_max
		content.stop_upgrade_level_price = save_data.stop_upgrade_level_price
		content.attacker_upgrade_level = save_data.attacker_upgrade_level
		content.attacker_upgrade_level_max = save_data.attacker_upgrade_level_max
		content.attacker_upgrade_level_price = save_data.attacker_upgrade_level_price
		content.piercer_upgrade_level = save_data.piercer_upgrade_level
		content.piercer_upgrade_level_max = save_data.piercer_upgrade_level_max
		content.piercer_upgrade_level_price = save_data.piercer_upgrade_level_price
		load_cnfg()
	return true

func save_cnfg():
	content.level_world = Config.level_world
	content.level_max = Config.level_max
	
	content.money = Config.money
	
	content.is_energy_buy = Config.is_energy_buy
	content.energy_start = Config.energy_start
	content.energy_start_level = Config.energy_start_level
	content.energy_start_level_max = Config.energy_start_level_max
	
	content.pierce_to_frag = Config.pierce_to_frag
	
	content.is_wall_unlock = Config.is_wall_unlock
	content.is_piercer_unlock = Config.is_piercer_unlock
	content.is_spike_unlock = Config.is_spike_unlock
	content.is_mine_unlock = Config.is_mine_unlock
	content.is_explosive_unlock = Config.is_explosive_unlock
	content.is_stop_unlock = Config.is_stop_unlock
	content.is_diverter_unlock = Config.is_diverter_unlock
	content.max_upgrade_level = Config.max_upgrade_level
	content.max_upgrade_level_price = Config.max_upgrade_level_price
	
	content.wall_upgrade_level = Config.wall_upgrade_level
	content.wall_upgrade_level_max = Config.wall_upgrade_level_max
	content.wall_upgrade_level_price = Config.wall_upgrade_level_price
	content.energy_upgrade_level = Config.energy_upgrade_level
	content.energy_upgrade_level_max = Config.energy_upgrade_level_max
	content.energy_upgrade_level_price = Config.energy_upgrade_level_price
	content.explosive_upgrade_level = Config.explosive_upgrade_level
	content.explosive_upgrade_level_max = Config.explosive_upgrade_level_max
	content.explosive_upgrade_level_price = Config.explosive_upgrade_level_price
	content.stop_upgrade_level = Config.stop_upgrade_level
	content.stop_upgrade_level_max = Config.stop_upgrade_level_max
	content.stop_upgrade_level_price = Config.stop_upgrade_level_price
	content.attacker_upgrade_level = Config.attacker_upgrade_level
	content.attacker_upgrade_level_max = Config.attacker_upgrade_level_max
	content.attacker_upgrade_level_price = Config.attacker_upgrade_level_price
	content.piercer_upgrade_level = Config.piercer_upgrade_level
	content.piercer_upgrade_level_max = Config.piercer_upgrade_level_max
	content.piercer_upgrade_level_price = Config.piercer_upgrade_level_price
func load_cnfg():
	Config.level_world = content.level_world
	Config.level_max = content.level_max
	
	Config.money = content.money
	
	Config.is_energy_buy = content.is_energy_buy
	Config.energy_start = content.energy_start
	Config.energy_start_level = content.energy_start_level
	Config.energy_start_level_max = content.energy_start_level_max
	
	Config.pierce_to_frag = content.pierce_to_frag
	
	Config.is_wall_unlock = content.is_wall_unlock
	Config.is_piercer_unlock = content.is_piercer_unlock
	Config.is_spike_unlock = content.is_spike_unlock
	Config.is_mine_unlock = content.is_mine_unlock
	Config.is_explosive_unlock = content.is_explosive_unlock
	Config.is_stop_unlock = content.is_stop_unlock
	Config.is_diverter_unlock = content.is_diverter_unlock
	Config.max_upgrade_level = content.max_upgrade_level
	Config.max_upgrade_level_price = content.max_upgrade_level_price
	
	Config.wall_upgrade_level = content.wall_upgrade_level
	Config.wall_upgrade_level_max = content.wall_upgrade_level_max
	Config.wall_upgrade_level_price = content.wall_upgrade_level_price
	Config.energy_upgrade_level = content.energy_upgrade_level
	Config.energy_upgrade_level_max = content.energy_upgrade_level_max
	Config.energy_upgrade_level_price = content.energy_upgrade_level_price
	Config.explosive_upgrade_level = content.explosive_upgrade_level
	Config.explosive_upgrade_level_max = content.explosive_upgrade_level_max
	Config.explosive_upgrade_level_price = content.explosive_upgrade_level_price
	Config.stop_upgrade_level = content.stop_upgrade_level
	Config.stop_upgrade_level_max = content.stop_upgrade_level_max
	Config.stop_upgrade_level_price = content.stop_upgrade_level_price
	Config.attacker_upgrade_level = content.attacker_upgrade_level
	Config.attacker_upgrade_level_max = content.attacker_upgrade_level_max
	Config.attacker_upgrade_level_price = content.attacker_upgrade_level_price
	Config.piercer_upgrade_level = content.piercer_upgrade_level
	Config.piercer_upgrade_level_max = content.piercer_upgrade_level_max
	Config.piercer_upgrade_level_price = content.piercer_upgrade_level_price
