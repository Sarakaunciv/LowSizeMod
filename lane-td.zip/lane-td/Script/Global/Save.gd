extends Node

const save_location0 = "user://Save.json"

var content: Dictionary = {
	"level_world": Config.level_world,
	"level_max": Config.level_max,
	
	"money": Config.money,
	
	"is_energy_buy": Config.is_energy_buy,
	"energy_start": Config.energy_start,
	"energy_start_level": Config.energy_start_level,
	"energy_start_level_max": Config.energy_start_level_max,
	
	"energy_move_mode": Config.energy_move_mode,
	"pierce_to_frag": Config.pierce_to_frag,
	
	"is_wall_unlock": Config.is_wall_unlock,
	"is_piercer_unlock": Config.is_piercer_unlock,
	"is_spike_unlock": Config.is_spike_unlock,
	"is_mine_unlock": Config.is_mine_unlock,
	"is_explosive_unlock": Config.is_explosive_unlock,
	"is_stop_unlock": Config.is_stop_unlock,
	"is_diverter_unlock": Config.is_diverter_unlock,
	"max_upgrade_level": Config.max_upgrade_level,
	"max_upgrade_level_price": Config.max_upgrade_level_price
}

func save0():
	var file0 = FileAccess.open(save_location0, FileAccess.WRITE)
	save_cnfg()
	file0.store_var(content.duplicate())
	file0.close()

func load0():
	if FileAccess.file_exists(save_location0):
		var file0 = FileAccess.open(save_location0, FileAccess.READ)
		var data = file0.get_var()
		file0.close()
		
		var save_data = data.duplicate()
		content.level_world = save_data.level_world
		content.level_max = save_data.level_max
		
		content.money = save_data.money
		
		content.is_energy_buy = save_data.is_energy_buy
		content.energy_start = save_data.energy_start
		content.energy_start_level = save_data.energy_start_level
		content.energy_start_level_max = save_data.energy_start_level_max
		
		content.energy_move_mode = save_data.energy_move_mode
		content.pierce_to_frag = save_data.pierce_to_frag
		
		content.is_wall_unlock = save_data.is_wall_unlock
		content.is_piercer_unlock = save_data.is_piercer_unlock
		content.is_spike_unlock = save_data.is_spike_unlock
		content.is_mine_unlock = save_data.is_mine_unlock
		content.is_explosive_unlock = save_data.is_explosive_unlock
		content.is_stop_unlock = save_data.is_stop_unlock
		content.is_diverter_unlock = save_data.is_diverter_unlock
		content.max_upgrade_level = save_data.max_upgrade_level
		content.max_upgrade_level_price = save_data.max_upgrade_level_price
		load_cnfg()
	return true

func save_cnfg():
	content.level_world = Config.level_world
	content.level_max = Config.level_max
	
	content.money = Config.money
	
	content.is_energy_buy = Config.is_energy_buy
	content.energy_start = Config.energy_start
	content.energy_start_level = Config.energy_start_level
	content.energy_start_level_max = Config.energy_start_level_max
	
	content.energy_move_mode = Config.energy_move_mode
	content.pierce_to_frag = Config.pierce_to_frag
	
	content.is_wall_unlock = Config.is_wall_unlock
	content.is_piercer_unlock = Config.is_piercer_unlock
	content.is_spike_unlock = Config.is_spike_unlock
	content.is_mine_unlock = Config.is_mine_unlock
	content.is_explosive_unlock = Config.is_explosive_unlock
	content.is_stop_unlock = Config.is_stop_unlock
	content.is_diverter_unlock = Config.is_diverter_unlock
	content.max_upgrade_level = Config.max_upgrade_level
	content.max_upgrade_level_price = Config.max_upgrade_level_price
func load_cnfg():
	Config.level_world = content.level_world
	Config.level_max = content.level_max
	
	Config.money = content.money
	
	Config.is_energy_buy = content.is_energy_buy
	Config.energy_start = content.energy_start
	Config.energy_start_level = content.energy_start_level
	Config.energy_start_level_max = content.energy_start_level_max
	
	Config.energy_move_mode = content.energy_move_mode
	Config.pierce_to_frag = content.pierce_to_frag
	
	Config.is_wall_unlock = content.is_wall_unlock
	Config.is_piercer_unlock = content.is_piercer_unlock
	Config.is_spike_unlock = content.is_spike_unlock
	Config.is_mine_unlock = content.is_mine_unlock
	Config.is_explosive_unlock = content.is_explosive_unlock
	Config.is_stop_unlock = content.is_stop_unlock
	Config.is_diverter_unlock = content.is_diverter_unlock
	Config.max_upgrade_level = content.max_upgrade_level
	Config.max_upgrade_level_price = content.max_upgrade_level_price
