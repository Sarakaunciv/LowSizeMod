extends Node2D

var hold_item_id: int = 0
var hold_item_id_tier: int = 1
var hold_diverter_type: int = 1
var hold_upgrade_tier: int = 2
var auto_upgrade: bool = false
var cursor_need_update: bool = true

var is_lose: bool = false
var game_speed_id: int = 2

var total_energizer: int = 0
signal set_energy(set_ting0)
var energy: int = 0
func add_energy(energy_value):
	energy += energy_value
	set_energy.emit(energy)

signal set_enemy(set_ting1)
var enemy_exist: int = 0
func add_enemy(enemy_count):
	enemy_exist += enemy_count
	set_enemy.emit(enemy_exist)

var level_wave: int = 0
var level_wave_max: int = 0
var wave_value: int = 0
var wave_value_current: int = 0
var wave_value_add: int = 0
var wave_value_goal: int = 0
var wave_value_goal_current: int = 0
var w_v_a_add: int = 0
var w_v_a_goal: int = 0
var w_v_a_goal_current: int = 0

var wave_timer_first: int = 0
var wave_timer: int = 0

var fast_0_eneble: bool = true
var strong_0_eneble: bool = true
var tank_0_eneble: bool = true
var massive_0_eneble: bool = true

var lane_0: int = 0
var lane_1: int = 0
var lane_2: int = 0
var lane_3: int = 0
var lane_4: int = 0
var lane_5: int = 0
var lane_6: int = 0
var lane_7: int = 0

func reset_to_default():
	hold_item_id = 0
	hold_item_id_tier = 1
	hold_diverter_type = 1
	hold_upgrade_tier = 2
	auto_upgrade = false
	cursor_need_update = true
	
	is_lose = false
	game_speed_id = 2
	
	total_energizer = 0
	energy = 0
	
	enemy_exist = 0
	
	level_wave = 0
	level_wave_max = 0
	wave_value = 0
	wave_value_current = 0
	wave_value_add = 0
	wave_value_goal = 0
	wave_value_goal_current = 0
	w_v_a_add = 0
	w_v_a_goal = 0
	w_v_a_goal_current = 0
	
	wave_timer_first = 0
	wave_timer = 0
	
	fast_0_eneble = true
	strong_0_eneble = true
	tank_0_eneble = true
	massive_0_eneble = true
	
	lane_0 = 0
	lane_1 = 0
	lane_2 = 0
	lane_3 = 0
	lane_4 = 0
	lane_5 = 0
	lane_6 = 0
	lane_7 = 0

#var hold_item_id: int = 0
#var hold_item_id_tier: int = 1
#var hold_diverter_type: int = 1
#var hold_upgrade_tier: int = 2
#var auto_upgrade: bool = false
#var cursor_need_update: bool = true
#
#var is_lose: bool = false
#var game_speed_id: int = 2
#
#var total_energizer: int = 0
#signal set_energy(set_ting0)
#var energy: int = 0
#func add_energy(energy_value):
	#energy += energy_value
	#set_energy.emit(energy)
#
#signal set_enemy(set_ting1)
#var enemy_exist: int = 0
#func add_enemy(enemy_count):
	#enemy_exist += enemy_count
	#set_enemy.emit(enemy_exist)
#
#var level_wave: int = 0
#var level_wave_max: int = 0
#var wave_value: int = 0
#var wave_value_current: int = 0
#var wave_value_add: int = 0
#var wave_value_goal: int = 0
#var wave_value_goal_current: int = 0
#var w_v_a_add: int = 0
#var w_v_a_goal: int = 0
#var w_v_a_goal_current: int = 0
#
#var wave_timer_first: int = 0
#var wave_timer: int = 0
#
#var fast_0_eneble: bool = true
#var strong_0_eneble: bool = true
#var tank_0_eneble: bool = true
#var massive_0_eneble: bool = true
#
#var lane_0: int = 0
#var lane_1: int = 0
#var lane_2: int = 0
#var lane_3: int = 0
#var lane_4: int = 0
#var lane_5: int = 0
#var lane_6: int = 0
#var lane_7: int = 0
