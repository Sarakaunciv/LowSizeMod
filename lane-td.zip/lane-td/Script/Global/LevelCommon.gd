extends Node2D

@onready var board: TileMap = $Board
@onready var enemy_timer: Timer = $EnemyTimer
@onready var enemy_timer_first: Timer = $EnemyTimerFirst
var wave_progress
var user_interface
func _ready():
	wave_progress = get_node("UserInterface/Wave")
	user_interface = get_node("UserInterface")
	LevelManager.set_enemy.connect(rush_wave)
	
	create_grid()
	board.setup_level()
	setup_spawn_enemy()
	wave_progress.max_value = LevelManager.level_wave_max
	wave_progress.value = LevelManager.level_wave
	enemy_timer_first.wait_time = LevelManager.wave_timer_first
	enemy_timer_first.timeout.connect(start_first_wave)
	enemy_timer_first.start()
	enemy_timer.wait_time = LevelManager.wave_timer
	enemy_timer.timeout.connect(spawn_wave)

func start_first_wave():
	spawn_wave()
	enemy_timer.start()

@onready var grid: Node2D = $Grid
var tile = load("res://Script/UI/turret_tile.tscn")
func create_grid():
	for x in range(20):
		for y in range(8):
			var tile_node = tile.instantiate()
			grid.add_child(tile_node)
			tile_node.position = Vector2(x, y) * Vector2(80, 80)

var lose_text
func _on_area_2d_area_entered(area: Area2D) -> void:
	if LevelManager.is_lose == false:
		Engine.time_scale = 0
		
		LevelManager.is_lose = true
		lose_text = get_node("UserInterface/Lose")
		lose_text.visible = true
		Save.save0()
var win_text
func win() -> void:
	if Config.level_world == Config.level_max:
		Config.level_max += 1
		if Config.level_max > Config.level_max_max:
			Config.level_max = Config.level_max_max
	win_text = get_node("UserInterface/Win")
	win_text.visible = true
	Save.save0()

var fast_w_min: int = 0
var strong_w_min: int = 0
var tank_w_min: int = 0
var massive_w_min: int = 0
var giga_w_min: int = 0
var normal_w_max: int = 0

var basic_parent_grand_w_min: int = 0
var basic_growing_w_min: int = 0
var fast_block_w_min: int = 0
var fast_phase_w_min: int = 0
var strong_explode_w_min: int = 0
var tank_gun_w_min: int = 0
var tank_gun_lot_w_min: int = 0
var special_w_max: int = 0
func setup_spawn_enemy():
	normal_w_max += Global.basic_0_p
	if LevelManager.fast_0_eneble == true:
		fast_w_min = normal_w_max
		normal_w_max += Global.fast_0_p
	if LevelManager.strong_0_eneble == true:
		strong_w_min = normal_w_max
		normal_w_max += Global.strong_0_p
	if LevelManager.tank_0_eneble == true:
		tank_w_min = normal_w_max
		normal_w_max += Global.tank_0_p
	if LevelManager.massive_0_eneble == true:
		massive_w_min = normal_w_max
		normal_w_max += Global.massive_0_p
	if LevelManager.giga_0_eneble == true:
		giga_w_min = normal_w_max
		normal_w_max += Global.giga_0_p
	#special
	special_w_max += Global.basic_parent_p
	if LevelManager.basic_parent_grand_eneble == true:
		basic_parent_grand_w_min = special_w_max
		special_w_max += Global.basic_parent_grand_p
	if LevelManager.basic_growing_eneble == true:
		basic_growing_w_min = special_w_max
		special_w_max += Global.basic_growing_p
	if LevelManager.fast_block_eneble == true:
		fast_block_w_min = special_w_max
		special_w_max += Global.fast_block_p
	if LevelManager.fast_phase_eneble == true:
		fast_phase_w_min = special_w_max
		special_w_max += Global.fast_phase_p
	if LevelManager.strong_explode_eneble == true:
		strong_explode_w_min = special_w_max
		special_w_max += Global.strong_explode_p
	if LevelManager.tank_gun_eneble == true:
		tank_gun_w_min = special_w_max
		special_w_max += Global.tank_gun_p
	if LevelManager.tank_gun_lot_eneble == true:
		tank_gun_lot_w_min = special_w_max
		special_w_max += Global.tank_gun_lot_p

var lane: int
var enemy_value: int
var enemy_tier: int
var enemy
func enemy_group_size_special():
	if LevelManager.wave_special_value >= enemy_value * 16 and enemy_tier < 65536:
		enemy_value *= 4
		enemy_tier *= 4
		enemy_group_size_special()
		return
func enemy_group_size_normal():
	if LevelManager.wave_value_current >= enemy_value * 16 and enemy_tier < 65536:
		enemy_value *= 4
		enemy_tier *= 4
		enemy_group_size_normal()
		return
#Special
var basic_parent = load("res://Script/Main/Enemy/Special/basic_parent/basic_parent.tscn")
func spawn_basic_parent():
	if LevelManager.basic_parent_grand_eneble == true:
		spawn_basic_parent_grand()
		return
	enemy_value = Global.basic_parent_v
	enemy_group_size_special()
	enemy = basic_parent.instantiate()
var basic_parent_grand = load("res://Script/Main/Enemy/Special/basic_parent_grand/basic_parent_grand.tscn")
func spawn_basic_parent_grand():
	enemy_value = Global.basic_parent_grand_v
	enemy_group_size_special()
	enemy = basic_parent_grand.instantiate()
var basic_growing = load("res://Script/Main/Enemy/Special/basic_growing/basic_growing.tscn")
func spawn_basic_growing():
	enemy_value = Global.basic_growing_v
	enemy_group_size_special()
	enemy = basic_growing.instantiate()
var fast_block = load("res://Script/Main/Enemy/Special/fast_block/fast_block.tscn")
func spawn_fast_block():
	enemy_value = Global.fast_block_v
	enemy_group_size_special()
	enemy = fast_block.instantiate()
var fast_phase = load("res://Script/Main/Enemy/Special/fast_phase/fast_phase.tscn")
func spawn_fast_phase():
	enemy_value = Global.fast_phase_v
	enemy_group_size_special()
	enemy = fast_phase.instantiate()
var strong_explode = load("res://Script/Main/Enemy/Special/strong_explode/strong_explode.tscn")
func spawn_strong_explode():
	enemy_value = Global.strong_explode_v
	enemy_group_size_special()
	enemy = strong_explode.instantiate()
var tank_gun = load("res://Script/Main/Enemy/Special/tank_gun/tank_gun.tscn")
func spawn_tank_gun():
	if LevelManager.tank_gun_lot_eneble == true:
		spawn_tank_gun_lot()
		return
	enemy_value = Global.tank_gun_v
	enemy_group_size_special()
	enemy = tank_gun.instantiate()
var tank_gun_lot = load("res://Script/Main/Enemy/Special/tank_gun_lot/tank_gun_lot.tscn")
func spawn_tank_gun_lot():
	enemy_value = Global.tank_gun_lot_v
	enemy_group_size_special()
	enemy = tank_gun_lot.instantiate()
#Normal
var basic_0 = load("res://Script/Main/Enemy/Normal/Basic/basic_0.tscn")
func spawn_basic_0():
	enemy_value = Global.basic_v
	enemy_group_size_normal()
	enemy = basic_0.instantiate()
var fast0 = load("res://Script/Main/Enemy/Normal/Fast/fast_0.tscn")
func spawn_fast_0():
	enemy_value = Global.fast_v
	enemy_group_size_normal()
	enemy = fast0.instantiate()
var strong0 = load("res://Script/Main/Enemy/Normal/Strong/strong_0.tscn")
func spawn_strong_0():
	enemy_value = Global.strong_v
	enemy_group_size_normal()
	enemy = strong0.instantiate()
var tank0 = load("res://Script/Main/Enemy/Normal/Tank/tank_0.tscn")
func spawn_tank_0():
	enemy_value = Global.tank_v
	enemy_group_size_normal()
	enemy = tank0.instantiate()
var massive0 = load("res://Script/Main/Enemy/Normal/Massive/massive_0.tscn")
func spawn_massive_0():
	enemy_value = Global.massive_v
	enemy_group_size_normal()
	enemy = massive0.instantiate()
var giga0 = load("res://Script/Main/Enemy/Normal/Giga/giga_0.tscn")
func spawn_giga_0():
	enemy_value = Global.giga_v
	enemy_group_size_normal()
	enemy = giga0.instantiate()

@onready var enemy_spawner: Node2D = $EnemySpawner
var enemy_w_current: int = 0
var enemy_w_current_s: int = 0
func spawn_enemy():
	enemy_tier = 1
	if LevelManager.wave_special_value >= Global.basic_parent_v:
		enemy_w_current = randi_range(1, special_w_max)
		#Select Enemy
		if LevelManager.tank_gun_lot_eneble == true and LevelManager.wave_special_value > Global.tank_gun_lot_v and enemy_w_current > tank_gun_lot_w_min:
			spawn_tank_gun_lot()
		elif LevelManager.tank_gun_eneble == true and LevelManager.wave_special_value > Global.tank_gun_v and enemy_w_current > tank_gun_w_min:
			spawn_tank_gun()
		elif LevelManager.strong_explode_eneble == true and LevelManager.wave_special_value > Global.strong_explode_v and enemy_w_current > strong_explode_w_min:
			spawn_strong_explode()
		elif LevelManager.fast_phase_eneble == true and LevelManager.wave_special_value > Global.fast_phase_v and enemy_w_current > fast_phase_w_min:
			spawn_fast_phase()
		elif LevelManager.fast_block_eneble == true and LevelManager.wave_special_value > Global.fast_block_v and enemy_w_current > fast_block_w_min:
			spawn_fast_block()
		elif LevelManager.basic_growing_eneble == true and LevelManager.wave_special_value > Global.basic_growing_v and enemy_w_current > basic_growing_w_min:
			spawn_basic_growing()
		elif LevelManager.basic_parent_grand_eneble == true and LevelManager.wave_special_value > Global.basic_parent_grand_v and enemy_w_current > basic_parent_grand_w_min:
			spawn_basic_parent_grand()
		else:
			spawn_basic_parent()
		LevelManager.wave_special_value -= enemy_value
	else:
		enemy_w_current = randi_range(1, normal_w_max)
		#Select Enemy
		if LevelManager.giga_0_eneble == true and LevelManager.wave_value_current > Global.giga_v and enemy_w_current > giga_w_min:
			spawn_giga_0()
		elif LevelManager.massive_0_eneble == true and LevelManager.wave_value_current > Global.massive_v and enemy_w_current > massive_w_min:
			spawn_massive_0()
		elif LevelManager.tank_0_eneble == true and LevelManager.wave_value_current > Global.tank_v and enemy_w_current > tank_w_min:
			spawn_tank_0()
		elif LevelManager.strong_0_eneble == true and LevelManager.wave_value_current > Global.strong_v and enemy_w_current > strong_w_min:
			spawn_strong_0()
		elif LevelManager.fast_0_eneble == true and LevelManager.wave_value_current > Global.fast_v and enemy_w_current > fast_w_min:
			spawn_fast_0()
		else:
			spawn_basic_0()
		LevelManager.wave_value_current -= enemy_value
	enemy.tier = enemy_tier
	enemy_spawner.add_child(enemy)
	enemy.global_position = enemy_spawner.global_position + Vector2(0, 80 * lane)

var titan = load("res://Script/Main/Enemy/Boss/titan/titan.tscn")
func spawn_titan():
	enemy = titan.instantiate()
	enemy.tier = LevelManager.boss_tier
	enemy_spawner.add_child(enemy)
var breach = load("res://Script/Main/Enemy/Boss/breach/breach.tscn")
func spawn_breach():
	enemy = breach.instantiate()
	enemy.tier = LevelManager.boss_tier
	enemy_spawner.add_child(enemy)
func spawn_boss():
	if LevelManager.level_wave in LevelManager.boss_titan_spawn_wave:
		spawn_titan()
	if LevelManager.level_wave in LevelManager.boss_breach_spawn_wave:
		spawn_breach()

func rush_wave(enemy_rush):
	if LevelManager.enemy_exist == 0:
		if LevelManager.level_wave == LevelManager.level_wave_max:
			win()
		else:
			enemy_timer.start()
			spawn_wave()

var is_special_set: bool = false
func spawn_wave():
	if is_special_set == false and LevelManager.basic_parent_eneble == true:
		LevelManager.wave_special_value += LevelManager.wave_value
		is_special_set = true
		if LevelManager.level_wave == LevelManager.level_wave_max - 1:
			LevelManager.wave_special_value += LevelManager.wave_value * 4
			LevelManager.wave_value *= 4
	if LevelManager.level_wave == LevelManager.level_wave_max:
		return
	if LevelManager.wave_value_current == 0 and LevelManager.wave_special_value < Global.basic_parent_v:
		pass
	else:
		select_lane()
		spawn_wave()
		return
	LevelManager.level_wave += 1
	wave_progress.value += 1
	user_interface.update_wave_label()
	
	if LevelManager.level_wave in LevelManager.boss_titan_spawn_wave or LevelManager.level_wave in LevelManager.boss_breach_spawn_wave:
		spawn_boss()
		if LevelManager.boss_tier == 65536:
			pass
		else:
			LevelManager.boss_tier *= 4
	
	LevelManager.wave_value_goal_current += 1
	if LevelManager.wave_value_goal_current == LevelManager.wave_value_goal:
		LevelManager.wave_value_goal_current = 0
		
		LevelManager.wave_value += LevelManager.wave_value_add
		
		LevelManager.w_v_a_goal_current += 1
		if LevelManager.w_v_a_goal_current == LevelManager.w_v_a_goal:
			LevelManager.w_v_a_goal_current = 0
			
			LevelManager.wave_value_add += LevelManager.w_v_a_add / 1000
			LevelManager.w_v_a_add *= LevelManager.w_v_a_a_percent
	LevelManager.wave_value_current = LevelManager.wave_value
	is_special_set = false

func select_lane():
	var lane_value = min(LevelManager.lane_0, LevelManager.lane_1, LevelManager.lane_2, LevelManager.lane_3, LevelManager.lane_4, LevelManager.lane_5, LevelManager.lane_6, LevelManager.lane_7)
	match lane_value:
		LevelManager.lane_0:
			lane = 0
			spawn_enemy()
			LevelManager.lane_0 += enemy_value
		LevelManager.lane_1:
			lane = 1
			spawn_enemy()
			LevelManager.lane_1 += enemy_value
		LevelManager.lane_2:
			lane = 2
			spawn_enemy()
			LevelManager.lane_2 += enemy_value
		LevelManager.lane_3:
			lane = 3
			spawn_enemy()
			LevelManager.lane_3 += enemy_value
		LevelManager.lane_4:
			lane = 4
			spawn_enemy()
			LevelManager.lane_4 += enemy_value
		LevelManager.lane_5:
			lane = 5
			spawn_enemy()
			LevelManager.lane_5 += enemy_value
		LevelManager.lane_6:
			lane = 6
			spawn_enemy()
			LevelManager.lane_6 += enemy_value
		LevelManager.lane_7:
			lane = 7
			spawn_enemy()
			LevelManager.lane_7 += enemy_value
