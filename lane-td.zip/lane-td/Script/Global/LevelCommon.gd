extends Node2D

@onready var board: TileMap = $Board
@onready var enemy_timer: Timer = $EnemyTimer
@onready var enemy_timer_first: Timer = $EnemyTimerFirst
var wave_progress
func _ready():
	wave_progress = get_node("UserInterface/Wave")
	LevelManager.set_enemy.connect(rush_wave)
	
	create_grid()
	board.setup_level()
	wave_progress.max_value = LevelManager.level_wave_max
	wave_progress.value = LevelManager.level_wave
	enemy_timer_first.wait_time = LevelManager.wave_timer_first
	enemy_timer_first.timeout.connect(start_first_wave)
	enemy_timer_first.start()
	enemy_timer.wait_time = LevelManager.wave_timer
	enemy_timer.timeout.connect(spawn_wave)

func start_first_wave():
	spawn_wave()
	enemy_timer.start()

@onready var grid: Node2D = $Grid
var tile = load("res://Script/UI/turret_tile.tscn")
func create_grid():
	for x in range(20):
		for y in range(8):
			var tile_node = tile.instantiate()
			grid.add_child(tile_node)
			tile_node.position = Vector2(x, y) * Vector2(80, 80)

var lose_text
func _on_area_2d_area_entered(area: Area2D) -> void:
	Save.save0()
	if LevelManager.is_lose == false:
		Engine.time_scale = 0
		
		LevelManager.is_lose = true
		lose_text = get_node("UserInterface/Lose")
		lose_text.visible = true
var win_text
func win() -> void:
	Save.save0()
	if Config.level_world == Config.level_max:
		Config.level_max += 1
		if Config.level_max > Config.level_max_max:
			Config.level_max = Config.level_max_max
	win_text = get_node("UserInterface/Win")
	win_text.visible = true

var lane: int
var enemy_value: int
var enemy_tier: int
var enemy
#var enemy_is_more_group: int = 1
func enemy_group_size():
	if LevelManager.wave_value_current >= enemy_value * 4 and enemy_tier < 65536:
		enemy_value *= 4
		enemy_tier *= 4
		#enemy_is_more_group = randi_range(0, 1)
		#if enemy_is_more_group == 1:
		enemy_group_size()
		return
@onready var enemy_spawner: Node2D = $EnemySpawner
var basic_0 = load("res://Script/Main/Enemy/Basic/basic_0.tscn")
var fast0 = load("res://Script/Main/Enemy/Fast/fast_0.tscn")
var strong0 = load("res://Script/Main/Enemy/Strong/strong_0.tscn")
var tank0 = load("res://Script/Main/Enemy/Tank/tank_0.tscn")
var massive0 = load("res://Script/Main/Enemy/Massive/massive_0.tscn")
func spawn_basic_0():
	enemy_value = Global.basic_v
	enemy_group_size()
	enemy = basic_0.instantiate()
func spawn_fast_0():
	enemy_value = Global.fast_v
	enemy_group_size()
	enemy = fast0.instantiate()
func spawn_strong_0():
	enemy_value = Global.strong_v
	enemy_group_size()
	enemy = strong0.instantiate()
func spawn_tank_0():
	enemy_value = Global.tank_v
	enemy_group_size()
	enemy = tank0.instantiate()
func spawn_massive_0():
	enemy_value = Global.massive_v
	enemy_group_size()
	enemy = massive0.instantiate()

var enemy_point_current: int = 0
var enemy_point_max: int = 0
func spawn_enemy():
	if LevelManager.wave_value_current >= Global.massive_v:
		enemy_point_max = Global.massive_0_p
	elif LevelManager.wave_value_current >= Global.tank_v:
		enemy_point_max = Global.tank_0_p
	elif LevelManager.wave_value_current >= Global.strong_v:
		enemy_point_max = Global.strong_0_p
	elif LevelManager.wave_value_current >= Global.fast_v:
		enemy_point_max = Global.fast_0_p
	else:
		enemy_point_max = Global.basic_0_p
	enemy_point_current = randi_range(0, enemy_point_max)
	#Select Enemy
	enemy_tier = 1
	if enemy_point_current > Global.tank_0_p and LevelManager.massive_0_eneble == true:
		spawn_massive_0()
	elif enemy_point_current > Global.strong_0_p and LevelManager.tank_0_eneble == true:
		spawn_tank_0()
	elif enemy_point_current > Global.fast_0_p and LevelManager.strong_0_eneble == true:
		spawn_strong_0()
	elif enemy_point_current > Global.basic_0_p and LevelManager.fast_0_eneble == true:
		spawn_fast_0()
	else:
		spawn_basic_0()
	enemy.tier = enemy_tier
	enemy_spawner.add_child(enemy)
	enemy.global_position = enemy_spawner.global_position + Vector2(0, 80 * lane)

func rush_wave(enemy_rush):
	if LevelManager.enemy_exist == 0:
		if LevelManager.level_wave == LevelManager.level_wave_max:
			win()
		else:
			enemy_timer.start()
			spawn_wave()

func spawn_wave():
	if LevelManager.level_wave == LevelManager.level_wave_max:
		return
	if LevelManager.wave_value_current == 0:
		pass
	else:
		select_lane()
		spawn_wave()
		return
	LevelManager.level_wave += 1
	wave_progress.value += 1
	
	LevelManager.wave_value_goal_current += 1
	if LevelManager.wave_value_goal_current == LevelManager.wave_value_goal:
		LevelManager.wave_value_goal_current = 0
		
		LevelManager.wave_value += LevelManager.wave_value_add
		
		LevelManager.w_v_a_goal_current += 1
		if LevelManager.w_v_a_goal_current == LevelManager.w_v_a_goal:
			LevelManager.w_v_a_goal_current = 0
			
			LevelManager.wave_value_add += LevelManager.w_v_a_add
			
	LevelManager.wave_value_current = LevelManager.wave_value

func select_lane():
	var lane_value = min(LevelManager.lane_0, LevelManager.lane_1, LevelManager.lane_2, LevelManager.lane_3, LevelManager.lane_4, LevelManager.lane_5, LevelManager.lane_6, LevelManager.lane_7)
	match lane_value:
		LevelManager.lane_0:
			lane = 0
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_0 += enemy_value
		LevelManager.lane_1:
			lane = 1
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_1 += enemy_value
		LevelManager.lane_2:
			lane = 2
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_2 += enemy_value
		LevelManager.lane_3:
			lane = 3
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_3 += enemy_value
		LevelManager.lane_4:
			lane = 4
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_4 += enemy_value
		LevelManager.lane_5:
			lane = 5
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_5 += enemy_value
		LevelManager.lane_6:
			lane = 6
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_6 += enemy_value
		LevelManager.lane_7:
			lane = 7
			spawn_enemy()	
			LevelManager.wave_value_current -= enemy_value
			LevelManager.lane_7 += enemy_value
