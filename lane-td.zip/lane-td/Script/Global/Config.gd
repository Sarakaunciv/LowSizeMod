extends Node

var level_world: int = 1
var level_max: int = 1
var level_max_max: int = 15

#Shop
signal set_money(set_ting0)
var money: int = 0
func add_money(money_count):
	money += money_count
	set_money.emit(money)

var is_energy_buy: bool = false
var energy_start: int = 0
var energy_start_level: int = 0
var energy_start_level_max: int = 0

var pierce_to_frag: bool = true

var is_wall_unlock: bool = false
var is_piercer_unlock: bool = false
var is_spike_unlock: bool = false
var is_mine_unlock: bool = false
var is_explosive_unlock: bool = false
var is_stop_unlock: bool = false
var is_diverter_unlock: bool = false
var max_upgrade_level: int = 1
var max_upgrade_level_price: int = 1

var wall_upgrade_level: int = 0
var wall_upgrade_level_max: int = 0
var wall_upgrade_level_price: int = 1
var energy_upgrade_level: int = 1
var energy_upgrade_level_max: int = 1
var energy_upgrade_level_price: int = 1
