extends Node

var energy_move_mode: int = 3

var energy_start: int = 5
