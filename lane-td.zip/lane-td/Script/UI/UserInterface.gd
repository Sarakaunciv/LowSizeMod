extends Node2D

func _ready():
	focus_none_for_all_button()
	LevelManager.set_energy.connect(update_energy_label)
	LevelManager.set_enemy.connect(update_enemy_label)
	self.z_index = 128

func focus_none_for_all_button():
	for child in self.find_children("*"):
		if child is Button:
			child.focus_mode = Control.FOCUS_NONE

@onready var wave_label: Label = $Wave0/Label
func update_wave_label():
	wave_label.text = str(LevelManager.level_wave_max, "/ ", LevelManager.level_wave)

@onready var energy_label: Label = $Energy/Label
func update_energy_label(energy: int):
	energy_label.text = str(energy)

@onready var enemy_label: Label = $Enemy/Label
func update_enemy_label(enemy: int):
	enemy_label.text = str(enemy)
