extends Node2D

@onready var button: Button = $Button
func _ready() -> void:
	button.focus_mode = Control.FOCUS_NONE

var type: int = 0
var turret_tier: int = 0

var occupy: bool = false

var kill_child
func kill_turret():
	occupy = false
	type = 0
	turret_tier = 0
	kill_child = get_node("Turret")
	kill_child.queue_free()

var kill_explosive1
var occupy_explosive: bool = false
func kill_explosive():
	occupy_explosive = false
	kill_explosive1 = get_node("Explosive")
	kill_explosive1.queue_free()
var kill_stop1
var occupy_stop: bool = false
func kill_stop():
	occupy_stop = false
	kill_stop1 = get_node("Stop")
	kill_stop1.queue_free()

func _on_button_mouse_entered() -> void:
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()

var no_plant_turret_pool = [0, Global.Explosive1_ID, Global.Stop1_ID, Global.Remover_ID, Global.Upgrader_ID]
var special_plant_turret_pool = [Global.Explosive1_ID, Global.Stop1_ID]
var turret
func _on_button_pressed() -> void:
	if LevelManager.hold_item_id in special_plant_turret_pool and LevelManager.energy >= 0:
		match LevelManager.hold_item_id:
			Global.Explosive1_ID:
				if occupy_explosive == false:
					plant_explosive1()
					occupy_explosive = true
			Global.Stop1_ID:
				if occupy_stop == false:
					plant_stop1()
					occupy_stop = true
		return
	elif occupy == true:
		match LevelManager.hold_item_id:
			Global.Remover_ID:
				kill_turret()
			Global.Upgrader_ID:
				if LevelManager.energy < 0 or turret_tier == 6:
					return
				else:
					upgrade_turret()
		return
	else:
		if occupy_block_enemy == true or LevelManager.hold_item_id in no_plant_turret_pool or LevelManager.energy < 0:
			return
		else:
			match LevelManager.hold_item_id:
				Global.Energizer1_ID:
					plant_energizer1()
				Global.Attacker1_ID:
					plant_attacker1()
				Global.Wall1_ID:
					plant_wall1()
				Global.Piercer1_ID:
					plant_piercer1()
				Global.Spike1_ID:
					plant_spike1()
				Global.Mine1_ID:
					plant_mine1()
				Global.Diverter1_ID:
					plant_diverter1()
			turret_tier = 1
			occupy = true
			turret = get_node("Turret")
			if LevelManager.auto_upgrade == true:
				upgrade_turret()
		return

var upgrade_price: int = 0
var no_upgrade_pool = [Global.Mine1_ID, Global.Diverter1_ID]
func upgrade_turret():
	if type in no_upgrade_pool:
		return
	elif type == Global.Energizer1_ID:
		match turret_tier:
			1:
				upgrade_price = Global.Energizer2_Cost * -1
			2:
				upgrade_price = Global.Energizer3_Cost * -1
			3:
				upgrade_price = Global.Energizer4_Cost * -1
			4:
				upgrade_price = Global.Energizer5_Cost * -1
			5:
				upgrade_price = Global.Energizer6_Cost * -1
	if LevelManager.energy >= upgrade_price and LevelManager.hold_upgrade_tier > turret_tier:
		turret_tier += 1
		turret.update_tier()
		upgrade_turret()
		upgrade_price = 0

var turret_node
var energizer1 = load("res://Script/Main/Turret/Top0/Energizer1/energizer1.tscn")
func plant_energizer1():
	turret_node = energizer1.instantiate()
	LevelManager.add_energy(Global.Energizer1_Cost)
	type = Global.Energizer1_ID
	plant_common()
var attacker1 = load("res://Script/Main/Turret/Top0/Attacker1/attacker1.tscn")
func plant_attacker1():
	turret_node = attacker1.instantiate()
	LevelManager.add_energy(Global.Attacker1_Cost)
	type = Global.Attacker1_ID
	plant_common()
var wall1 = load("res://Script/Main/Turret/Top0/Wall1/wall1.tscn")
func plant_wall1():
	turret_node = wall1.instantiate()
	LevelManager.add_energy(Global.Wall1_Cost)
	type = Global.Wall1_ID
	plant_common()
var piercer1 = load("res://Script/Main/Turret/Top0/Piercer1/piercer1.tscn")
func plant_piercer1():
	turret_node = piercer1.instantiate()
	LevelManager.add_energy(Global.Piercer1_Cost)
	type = Global.Piercer1_ID
	plant_common()
var spike1 = load("res://Script/Main/Turret/Top0/Spike1/spike1.tscn")
func plant_spike1():
	turret_node = spike1.instantiate()
	LevelManager.add_energy(Global.Spike1_Cost)
	type = Global.Spike1_ID
	plant_common()

var mine1 = load("res://Script/Main/Turret/Top1/Mine1/mine1.tscn")
func plant_mine1():
	turret_node = mine1.instantiate()
	LevelManager.add_energy(Global.Mine1_Cost)
	type = Global.Mine1_ID
	plant_common()
	hold_item_id_tier()
var explosive1 = load("res://Script/Main/Turret/Top1/Explosive1/explosive1.tscn")
func plant_explosive1():
	turret_node = explosive1.instantiate()
	LevelManager.add_energy(Global.Explosive1_Cost)
	plant_common()
	hold_item_id_tier()
var stop1 = load("res://Script/Main/Turret/Top1/Stop1/stop1.tscn")
func plant_stop1():
	turret_node = stop1.instantiate()
	LevelManager.add_energy(Global.Stop1_Cost)
	plant_common()
	hold_item_id_tier()
var diverter1 = load("res://Script/Main/Turret/Top1/Diverter1/diverter1.tscn")
func plant_diverter1():
	turret_node = diverter1.instantiate()
	LevelManager.add_energy(Global.Diverter1_Cost)
	type = Global.Diverter1_ID
	plant_common()
	hold_item_id_tier()

func plant_common():
	add_child(turret_node)
	turret_node.global_position = self.global_position
func hold_item_id_tier():
	match LevelManager.hold_item_id_tier:
		1:
			pass
		2:
			turret_node.update_tier()
		3:
			turret_node.update_tier()
			turret_node.update_tier()
#
#var kill_block_enemy1
var occupy_block_enemy: bool = false
#func kill_block_enemy():
	#occupy_block_enemy = false
	#kill_block_enemy1 = get_node("Enemy")
	#kill_block_enemy1.queue_free()
var enemy_node
var block_enemy1 = load("res://Script/Main/Enemy/Special/fast_block/block/block.tscn")
func plant_block_enemy(enemy_tier):
	if occupy == true:
		return
	elif occupy_block_enemy == true:
		enemy_node = get_node("Enemy")
		if enemy_node.tier < enemy_tier:
			enemy_node.death()
			plant_block_enemy(enemy_tier)
			return
		else:
			enemy_node.hp_regen(enemy_tier)
	else:
		occupy_block_enemy = true
		enemy_node = block_enemy1.instantiate()
		enemy_node.tier = enemy_tier
		add_child(enemy_node)
