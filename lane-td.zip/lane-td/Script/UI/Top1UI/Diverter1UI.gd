extends Node2D

@onready var content: Sprite2D = $Content
func _on_button_pressed() -> void:
	if LevelManager.hold_item_id == Global.Diverter1_ID:
		if LevelManager.hold_diverter_type == 1:
			content.region_rect.position.y += 8
			LevelManager.hold_diverter_type = 2
		else:
			content.region_rect.position.y -= 8
			LevelManager.hold_diverter_type = 1
	else:
		LevelManager.hold_item_id = Global.Diverter1_ID
	LevelManager.cursor_need_update = true

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_R:
			_on_button_pressed()

@onready var edge_hover: Sprite2D = $EdgeHover

func _on_button_mouse_entered() -> void:
	edge_hover.visible = true

func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
