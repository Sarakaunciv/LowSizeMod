extends Node2D

func _on_button_pressed() -> void:
	if LevelManager.hold_item_id == Global.Stop1_ID:
		LevelManager.hold_item_id = 0
	else:
		LevelManager.hold_item_id = Global.Stop1_ID
	LevelManager.cursor_need_update = true

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_E:
			_on_button_pressed()

@onready var edge_hover: Sprite2D = $EdgeHover

func _on_button_mouse_entered() -> void:
	edge_hover.visible = true

func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
