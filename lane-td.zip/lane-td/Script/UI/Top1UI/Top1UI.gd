extends Node2D

var mine_content
var explosive_content
var stop_content
var diverter_content
func _ready() -> void:
	mine_content = get_node("Mine1UI/Content")
	explosive_content = get_node("Explosive1UI/Content")
	stop_content = get_node("Stop1UI/Content")
	diverter_content = get_node("Diverter1UI/Content")
	label.text =str(LevelManager.hold_item_id_tier)

@onready var label: Label = $Label
func _on_add_pressed() -> void:
	if LevelManager.hold_item_id_tier == 3:
		return
	else:
		LevelManager.hold_item_id_tier += 1
		if mine_content != null:
			mine_content.region_rect.position.y += 8
		if explosive_content != null:
			explosive_content.region_rect.position.y += 8
		if stop_content != null:
			stop_content.region_rect.position.y += 8
		if diverter_content != null:
			update_diverter()
		LevelManager.cursor_need_update = true
		label.text =str(LevelManager.hold_item_id_tier)

func _on_sub_pressed() -> void:
	if LevelManager.hold_item_id_tier == 1:
		return
	else:
		LevelManager.hold_item_id_tier -= 1
		if mine_content != null:
			mine_content.region_rect.position.y -= 8
		if explosive_content != null:
			explosive_content.region_rect.position.y -= 8
		if stop_content != null:
			stop_content.region_rect.position.y -= 8
		if diverter_content != null:
			update_diverter()
		LevelManager.cursor_need_update = true
		label.text =str(LevelManager.hold_item_id_tier)

func update_diverter():
	match LevelManager.hold_item_id_tier:
		1:
			diverter_content.modulate = Color(1, 1, 1)
		2:
			diverter_content.modulate = Global.Diverter2_Color
		3:
			diverter_content.modulate = Global.Diverter3_Color
