extends Node2D

func _ready() -> void:
	self.z_index = 128

@onready var color_rect: ColorRect = $ColorRect
func visible_rect():
	if color_rect.visible == false:
		color_rect.visible = true
	else:
		color_rect.visible = false

func _on_button_pressed() -> void:
	var event = InputEventKey.new()
	event.pressed = true
	event.keycode = KEY_ESCAPE
	Input.parse_input_event(event)

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE:
			visible_rect()
		if color_rect.visible == true and event.keycode == KEY_SPACE:
			visible_rect()

@onready var edge_hover: Sprite2D = $EdgeHover

func _on_button_mouse_entered() -> void:
	edge_hover.visible = true

func _on_button_mouse_exited() -> void:
	edge_hover.visible = false

#var level
#func _on_a_pressed() -> void:
	#level = get_node("../../..")
	#level.queue_free()

func _on_a_pressed() -> void:
	LevelManager.reset_to_default()
	get_tree().change_scene_to_file("res://Scene/level_menu.tscn")
