extends Node2D

var color_rect
var edge_hover

var damage_menu
var energizer_damage_label
var attacker_damage_label
var piercer_damage_label
var spike_damage_label
var mine_damage_label
var explosive_damage_label
func _ready() -> void:
	color_rect = get_node("ColorRect")
	edge_hover = get_node("EdgeHover")
	
	damage_menu = get_node("ColorRect/b/ColorRect")
	energizer_damage_label = get_node("ColorRect/b/ColorRect/Energizer/ColorRect/Label")
	attacker_damage_label = get_node("ColorRect/b/ColorRect/Attacker/ColorRect/Label")
	piercer_damage_label = get_node("ColorRect/b/ColorRect/Piercer/ColorRect/Label")
	spike_damage_label = get_node("ColorRect/b/ColorRect/Spike/ColorRect/Label")
	mine_damage_label = get_node("ColorRect/b/ColorRect/Mine/ColorRect/Label")
	explosive_damage_label = get_node("ColorRect/b/ColorRect/Explosive/ColorRect/Label")
	self.z_index = 128

func visible_rect():
	if color_rect.visible == false:
		color_rect.visible = true
		LevelManager.is_menu = true
	else:
		color_rect.visible = false
		damage_menu.visible = false
		LevelManager.is_menu = false

func _on_button_pressed() -> void:
	if Engine.time_scale == 0 and LevelManager.is_menu == false:
		visible_rect()
	else:
		var event = InputEventKey.new()
		event.pressed = true
		event.keycode = KEY_ESCAPE
		Input.parse_input_event(event)

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE:
			visible_rect()
		if color_rect.visible == true and event.keycode == KEY_SPACE:
			visible_rect()

func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false

func _on_a_pressed() -> void:
	Save.save0()
	LevelManager.reset_to_default()
	get_tree().change_scene_to_file("res://Scene/level_menu.tscn")

func _on_b_pressed() -> void:
	if damage_menu.visible == false:
		energizer_damage_label.text = str(LevelManager.energizer_damage)
		attacker_damage_label.text = str(LevelManager.attacker_damage)
		piercer_damage_label.text = str(LevelManager.piercer_damage)
		spike_damage_label.text = str(LevelManager.spike_damage)
		mine_damage_label.text = str(LevelManager.mine_damage)
		explosive_damage_label.text = str(LevelManager.explosive_damage)
		damage_menu.visible = true
	else:
		damage_menu.visible = false
