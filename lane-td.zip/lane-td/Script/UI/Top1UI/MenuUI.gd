extends Node2D

var color_rect
var edge_hover

var damage_menu
var energizer_damage_label
var attacker_damage_label
var piercer_damage_label
var spike_damage_label
var mine_damage_label
var explosive_damage_label

var enemy_menu
var basic
var fast
var strong
var tank
var massive
var giga
var basic_parent
var basic_parent_grand
var basic_growing
var fast_block
var fast_phase
var strong_explode
var tank_gun
var tank_gun_lot

var turret_menu
func _ready() -> void:
	color_rect = get_node("ColorRect")
	edge_hover = get_node("EdgeHover")
	
	damage_menu = get_node("ColorRect/b/ColorRect")
	energizer_damage_label = get_node("ColorRect/b/ColorRect/Energizer/ColorRect/Label")
	attacker_damage_label = get_node("ColorRect/b/ColorRect/Attacker/ColorRect/Label")
	piercer_damage_label = get_node("ColorRect/b/ColorRect/Piercer/ColorRect/Label")
	spike_damage_label = get_node("ColorRect/b/ColorRect/Spike/ColorRect/Label")
	mine_damage_label = get_node("ColorRect/b/ColorRect/Mine/ColorRect/Label")
	explosive_damage_label = get_node("ColorRect/b/ColorRect/Explosive/ColorRect/Label")
	
	enemy_menu = get_node("ColorRect/c/ColorRect")
	fast = get_node("ColorRect/c/ColorRect/ColorRect/Fast")
	strong = get_node("ColorRect/c/ColorRect/ColorRect/Strong")
	tank = get_node("ColorRect/c/ColorRect/ColorRect/Tank")
	massive = get_node("ColorRect/c/ColorRect/ColorRect/Massive")
	giga = get_node("ColorRect/c/ColorRect/ColorRect/Giga")
	basic_parent = get_node("ColorRect/c/ColorRect/ColorRect/basic_parent")
	basic_parent_grand = get_node("ColorRect/c/ColorRect/ColorRect/basic_parent_grand")
	basic_growing = get_node("ColorRect/c/ColorRect/ColorRect/basic_growing")
	fast_block = get_node("ColorRect/c/ColorRect/ColorRect/fast_block")
	fast_phase = get_node("ColorRect/c/ColorRect/ColorRect/fast_phase")
	strong_explode = get_node("ColorRect/c/ColorRect/ColorRect/strong_explode")
	tank_gun = get_node("ColorRect/c/ColorRect/ColorRect/tank_gun")
	tank_gun_lot = get_node("ColorRect/c/ColorRect/ColorRect/tank_gun_lot")
	
	turret_menu = get_node("ColorRect/d/ColorRect")
	self.z_index = 128

func ready0():
	if LevelManager.fast_0_eneble == false:
		fast.visible = false
	if LevelManager.strong_0_eneble == false:
		strong.visible = false
	if LevelManager.tank_0_eneble == false:
		tank.visible = false
	if LevelManager.massive_0_eneble == false:
		massive.visible = false
	if LevelManager.giga_0_eneble == false:
		giga.visible = false
	if LevelManager.basic_parent_eneble == false:
		basic_parent.visible = false
	if LevelManager.basic_parent_grand_eneble == false:
		basic_parent_grand.visible = false
	if LevelManager.basic_growing_eneble == false:
		basic_growing.visible = false
	if LevelManager.fast_block_eneble == false:
		fast_block.visible = false
	if LevelManager.fast_phase_eneble == false:
		fast_phase.visible = false
	if LevelManager.strong_explode_eneble == false:
		strong_explode.visible = false
	if LevelManager.tank_gun_eneble == false:
		tank_gun.visible = false
	if LevelManager.tank_gun_lot_eneble == false:
		tank_gun_lot.visible = false

func visible_rect():
	if color_rect.visible == false:
		color_rect.visible = true
		LevelManager.is_menu = true
	else:
		color_rect.visible = false
		damage_menu.visible = false
		enemy_menu.visible = false
		LevelManager.is_menu = false

func _on_button_pressed() -> void:
	if Engine.time_scale == 0 and LevelManager.is_menu == false:
		visible_rect()
	else:
		var event = InputEventKey.new()
		event.pressed = true
		event.keycode = KEY_ESCAPE
		Input.parse_input_event(event)

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE:
			visible_rect()
		if color_rect.visible == true and event.keycode == KEY_SPACE:
			visible_rect()

func _on_button_mouse_entered() -> void:
	edge_hover.visible = true
func _on_button_mouse_exited() -> void:
	edge_hover.visible = false

func _on_a_pressed() -> void:
	Save.save0()
	LevelManager.reset_to_default()
	get_tree().change_scene_to_file("res://Scene/level_menu.tscn")

func _on_b_pressed() -> void:
	enemy_menu.visible = false
	turret_menu.visible = false
	if damage_menu.visible == false:
		energizer_damage_label.text = str(LevelManager.energizer_damage)
		attacker_damage_label.text = str(LevelManager.attacker_damage)
		piercer_damage_label.text = str(LevelManager.piercer_damage)
		spike_damage_label.text = str(LevelManager.spike_damage)
		mine_damage_label.text = str(LevelManager.mine_damage)
		explosive_damage_label.text = str(LevelManager.explosive_damage)
		damage_menu.visible = true
	else:
		damage_menu.visible = false

var is_enemy_ready: bool = false
func _on_c_pressed() -> void:
	damage_menu.visible = false
	turret_menu.visible = false
	if is_enemy_ready == false:
		ready0()
		is_enemy_ready = true
	if enemy_menu.visible == false:
		enemy_menu.visible = true
	else:
		enemy_menu.visible = false

func _on_d_pressed() -> void:
	damage_menu.visible = false
	enemy_menu.visible = false
	if turret_menu.visible == false:
		turret_menu.visible = true
	else:
		turret_menu.visible = false
