extends Node2D

@onready var sprite_2d: Sprite2D = $Sprite2D

func _ready() -> void:
	holding_content()

func _process(delta: float) -> void:
	self.global_position = get_global_mouse_position()
	holding_content()

func holding_content():
	if LevelManager.cursor_need_update == false:
		return
	else:
		LevelManager.cursor_need_update = false
		if LevelManager.hold_item_id == 0:
			sprite_2d.visible = false
		else:
			sprite_2d.visible = true
			if LevelManager.hold_item_id == Global.Diverter1_ID:
				sprite_2d.region_rect.position.x = 88
				if LevelManager.hold_diverter_type == 1:
					sprite_2d.region_rect.position.y = 40
				else:
					sprite_2d.region_rect.position.y = 48
				match LevelManager.hold_item_id_tier:
					1:
						sprite_2d.modulate = Color(1, 1, 1)
					2:
						sprite_2d.modulate = Global.Diverter2_Color
					3:
						sprite_2d.modulate = Global.Diverter3_Color
			else:
				sprite_2d.modulate = Color(1, 1, 1)
				match LevelManager.hold_item_id:
					Global.Energizer1_ID:
						sprite_2d.region_rect.position.x = 64
						sprite_2d.region_rect.position.y = 0
					Global.Attacker1_ID:
						sprite_2d.region_rect.position.x = 64
						sprite_2d.region_rect.position.y = 8
					Global.Wall1_ID:
						sprite_2d.region_rect.position.x = 64
						sprite_2d.region_rect.position.y = 24
					Global.Piercer1_ID:
						sprite_2d.region_rect.position.x = 64
						sprite_2d.region_rect.position.y = 16
					Global.Spike1_ID:
						sprite_2d.region_rect.position.x = 64
						sprite_2d.region_rect.position.y = 32
					Global.Mine1_ID:
						hold_item_id_tier()
						sprite_2d.region_rect.position.x = 80
					Global.Explosive1_ID:
						hold_item_id_tier()
						sprite_2d.region_rect.position.x = 64
					Global.Stop1_ID:
						hold_item_id_tier()
						sprite_2d.region_rect.position.x = 96
					Global.Remover_ID:
						sprite_2d.region_rect.position.x = 32
						sprite_2d.region_rect.position.y = 8
					Global.Upgrader_ID:
						sprite_2d.region_rect.position.x = 40
						sprite_2d.region_rect.position.y = 8

func hold_item_id_tier():
	match LevelManager.hold_item_id_tier:
		1:
			sprite_2d.region_rect.position.y = 40
		2:
			sprite_2d.region_rect.position.y = 48
		3:
			sprite_2d.region_rect.position.y = 56
