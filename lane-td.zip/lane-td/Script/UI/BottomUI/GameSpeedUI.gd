extends Node2D

@onready var button: Node2D = $Button
func _ready() -> void:
	update_game_speed()

var save_game_speed_id: int = 0
func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_SPACE or event.keycode == KEY_ESCAPE:
			if LevelManager.game_speed_id != 0:
				save_game_speed_id = LevelManager.game_speed_id
				LevelManager.game_speed_id = 0
			else:
				LevelManager.game_speed_id = save_game_speed_id
		if event.keycode == KEY_X:
			LevelManager.game_speed_id += 1
		if event.keycode == KEY_Z:
			LevelManager.game_speed_id -= 1
	update_game_speed()

@onready var content_p: Sprite2D = $Button/p/Content
@onready var content_a: Sprite2D = $Button/a/Content
@onready var content_b: Sprite2D = $Button/b/Content
@onready var content_c: Sprite2D = $Button/c/Content
@onready var content_d: Sprite2D = $Button/d/Content
@onready var content_e: Sprite2D = $Button/e/Content
func update_game_speed():
	if LevelManager.is_lose == true:
		return
	else:
		if LevelManager.game_speed_id < 0:
			LevelManager.game_speed_id = 0
		elif LevelManager.game_speed_id > 5:
			LevelManager.game_speed_id = 5
		content_p.modulate = Color(1, 1, 1)
		content_a.modulate = Color(1, 1, 1)
		content_b.modulate = Color(1, 1, 1)
		content_c.modulate = Color(1, 1, 1)
		content_d.modulate = Color(1, 1, 1)
		content_e.modulate = Color(1, 1, 1)
		match LevelManager.game_speed_id:
			0:
				content_p.modulate *= Color(0.5, 0.5, 0.5)
				Engine.time_scale = 0
			1:
				content_a.modulate *= Color(0.5, 0.5, 0.5)
				Engine.time_scale = 0.25
			2:
				content_b.modulate *= Color(0.5, 0.5, 0.5)
				Engine.time_scale = 1
			3:
				content_c.modulate *= Color(0.5, 0.5, 0.5)
				Engine.time_scale = 4
			4:
				content_d.modulate *= Color(0.5, 0.5, 0.5)
				Engine.time_scale = 8
			5:
				content_e.modulate *= Color(0.5, 0.5, 0.5)
				Engine.time_scale = 16

func _on_p_pressed() -> void:
	if LevelManager.is_menu == false:
		LevelManager.game_speed_id = 0
		update_game_speed()

func _on_a_pressed() -> void:
	if LevelManager.is_menu == false:
		LevelManager.game_speed_id = 1
		update_game_speed()

func _on_b_pressed() -> void:
	if LevelManager.is_menu == false:
		LevelManager.game_speed_id = 2
		update_game_speed()

func _on_c_pressed() -> void:
	if LevelManager.is_menu == false:
		LevelManager.game_speed_id = 3
		update_game_speed()

func _on_d_pressed() -> void:
	if LevelManager.is_menu == false:
		LevelManager.game_speed_id = 4
		update_game_speed()

func _on_e_pressed() -> void:
	if LevelManager.is_menu == false:
		LevelManager.game_speed_id = 5
		update_game_speed()
