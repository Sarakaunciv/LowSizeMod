extends Node2D

func _ready() -> void:
	if Config.max_upgrade_level == 1:
		queue_free()
	update_label()
	ready_0()

func _on_button_pressed() -> void:
	if LevelManager.hold_item_id == Global.Upgrader_ID:
		LevelManager.hold_item_id = 0
	else:
		LevelManager.hold_item_id = Global.Upgrader_ID
	LevelManager.cursor_need_update = true

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_S:
			_on_button_pressed()

@onready var edge_hover: Sprite2D = $EdgeHover

func _on_button_mouse_entered() -> void:
	edge_hover.visible = true

func _on_button_mouse_exited() -> void:
	edge_hover.visible = false

@onready var label: Label = $Label
func update_label():
	label.text = str(LevelManager.hold_upgrade_tier)

func _on_add_pressed() -> void:
	if LevelManager.hold_upgrade_tier < Config.max_upgrade_level:
		LevelManager.hold_upgrade_tier += 1
		update_label()

func _on_sub_pressed() -> void:
	if LevelManager.hold_upgrade_tier > 2:
		LevelManager.hold_upgrade_tier -= 1
		update_label()

@onready var auto_text: Label = $Auto/Text
func _on_auto_pressed() -> void:
	if LevelManager.auto_upgrade == true:
		LevelManager.auto_upgrade = false
		auto_text.text = str("Manual")
	else:
		LevelManager.auto_upgrade = true
		auto_text.text = str("Auto")
func ready_0():
	if LevelManager.auto_upgrade == false:
		auto_text.text = str("Manual")
	else:
		auto_text.text = str("Auto")
