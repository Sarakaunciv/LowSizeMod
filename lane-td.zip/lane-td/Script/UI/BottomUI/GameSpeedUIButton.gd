extends Button

@onready var content: Sprite2D = $Content
func _on_mouse_entered() -> void:
	content.modulate *= Color(1.25, 1.25, 1.25)

func _on_mouse_exited() -> void:
	content.modulate *= Color(0.8, 0.8, 0.8)
