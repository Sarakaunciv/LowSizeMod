extends Node2D

func _ready() -> void:
	update_money(0)
	Config.set_money.connect(update_money)

@onready var label: Label = $Label
func update_money(money0):
	label.text = str("M ", Config.money)
