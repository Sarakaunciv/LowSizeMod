extends Button

func _ready():
	update_label()

var total_wave_value: int = 0
var max_wave_value: int = 0
func simulate_wave():
	for wave in range(LevelManager.level_wave_max):
		total_wave_value += LevelManager.wave_value
		max_wave_value = LevelManager.wave_value
		
		LevelManager.wave_value_goal_current += 1
		if LevelManager.wave_value_goal_current == LevelManager.wave_value_goal:
			LevelManager.wave_value_goal_current = 0
			
			LevelManager.wave_value += LevelManager.wave_value_add
			
			LevelManager.w_v_a_goal_current += 1
			if LevelManager.w_v_a_goal_current == LevelManager.w_v_a_goal:
				LevelManager.w_v_a_goal_current = 0
				
				LevelManager.wave_value_add += LevelManager.w_v_a_add / 1000
				LevelManager.w_v_a_add *= LevelManager.w_v_a_a_percent

@onready var label: Label = $ColorRect/Label
func update_label():
	label.text = str("Wave ", LevelManager.level_wave_max,
	"\nMax Value ", max_wave_value, "\nTotal Value ", total_wave_value,
	"\nWave Timer ", LevelManager.wave_timer_first, "/", LevelManager.wave_timer,
	"\nWave Multiplier ", LevelManager.w_v_a_a_percent)
	if LevelManager.weak_awake == true:
		label.text += str("\nAwake")

@onready var board: Node2D = $Board
func _on_pressed() -> void:
	board.setup_level()
	simulate_wave()
	update_label()
	LevelManager.reset_to_default()
	total_wave_value = 0
	max_wave_value = 0
