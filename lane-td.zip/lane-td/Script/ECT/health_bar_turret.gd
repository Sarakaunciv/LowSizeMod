extends TextureProgressBar

func _ready() -> void:
	update_health_bar()

func update_health_bar():
	var parent = get_node("..")
	max_value = parent.hp_max
	value = parent.hp_left
	if parent.hp_left == parent.hp_max:
		self.visible = false
	else:
		self.visible = true
