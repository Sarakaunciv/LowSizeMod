extends Node2D

func _ready():
	pass

func setup_level():
	LevelManager.add_energy(Config.energy_start)
	LevelManager.wave_timer = 20
	LevelManager.wave_timer_first = 20
	match Config.level_world:
		0:
			Config.add_money(50000000)
			Config.level_max = Config.level_max_max
			LevelManager.add_energy(180000000)
			LevelManager.level_wave_max = 500
			LevelManager.wave_value = 500
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			LevelManager.wave_timer = 90000
			LevelManager.wave_timer_first = 1
		1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		2:
			LevelManager.level_wave_max = 30
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 2000
			LevelManager.w_v_a_goal = 3
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		3:
			LevelManager.level_wave_max = 40
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 2000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		4:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		5:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 2500
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.lane_0 = -2147483648
		6:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		7:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3500
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		8:
			LevelManager.level_wave_max = 60
			LevelManager.wave_value = 3
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 4000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		9:
			LevelManager.level_wave_max = 60
			LevelManager.wave_value = 3
			LevelManager.wave_value_add = 4
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 4000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.2
			
			LevelManager.fast_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		10:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.2
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_titan_spawn_wave = [80]
			LevelManager.boss_tier = 16
		11:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.2
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		12:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 6
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.2
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		13:
			LevelManager.level_wave_max = 90
			LevelManager.wave_value = 6
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.2
			
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		14:
			LevelManager.level_wave_max = 100
			LevelManager.wave_value = 8
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.2
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_titan_spawn_wave = [25, 50, 75, 100]
			LevelManager.boss_tier = 1
		15:
			LevelManager.level_wave_max = 100
			LevelManager.wave_value = 8
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.2
			
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_titan_spawn_wave = [25, 50, 75]
			LevelManager.boss_breach_spawn_wave = [100]
			LevelManager.boss_tier = 1
		16:
			LevelManager.level_wave_max = 100
			LevelManager.wave_value = 8
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.25
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		17:
			LevelManager.level_wave_max = 110
			LevelManager.wave_value = 8
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.25
			
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		17:
			LevelManager.level_wave_max = 120
			LevelManager.wave_value = 8
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.25
			
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		18:
			LevelManager.level_wave_max = 130
			LevelManager.wave_value = 12
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.25
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
		19:
			LevelManager.level_wave_max = 140
			LevelManager.wave_value = 12
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.25
		20:
			LevelManager.level_wave_max = 150
			LevelManager.wave_value = 12
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.25
			
			LevelManager.boss_titan_spawn_wave = [5, 30, 60, 90, 120, 150]
			LevelManager.boss_breach_spawn_wave = [150]
			LevelManager.boss_tier = 1
		21:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 5
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 5000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 3.0
		22:
			LevelManager.level_wave_max = 30
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 5
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 5000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 10.0
			
			LevelManager.lane_0 = -2147483648
		23:
			LevelManager.level_wave_max = 180
			LevelManager.wave_value = 12
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 3000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.25
			
			LevelManager.wave_timer = 15
			LevelManager.wave_timer_first = 5
			
			LevelManager.boss_titan_spawn_wave = [5, 30, 60, 90, 120, 150, 180]
			LevelManager.boss_breach_spawn_wave = [5, 180]
			LevelManager.boss_tier = 1
		24:
			LevelManager.level_wave_max = 5
			LevelManager.wave_value = 500000
			LevelManager.wave_value_add = 500000
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 0
			LevelManager.w_v_a_goal = 1
			LevelManager.w_v_a_a_percent = 0
			
			LevelManager.wave_timer = 60
			LevelManager.wave_timer_first = 300
			
			LevelManager.boss_titan_spawn_wave = [1, 2, 3, 4, 5]
			LevelManager.boss_breach_spawn_wave = [1, 2, 3, 4, 5]
			LevelManager.boss_tier = 16
		25:
			LevelManager.level_wave_max = 500
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.11
			
			LevelManager.wave_timer = 10
			LevelManager.wave_timer_first = 5
			
			LevelManager.boss_titan_spawn_wave = [5, 60, 120, 180, 240, 300, 360, 420, 500]
			LevelManager.boss_breach_spawn_wave = [5, 60, 120, 180, 240, 300, 360, 420, 500]
			LevelManager.boss_tier = 1
		-1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1000
			LevelManager.w_v_a_goal = 2
			LevelManager.w_v_a_a_percent = 1.1
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_titan_spawn_wave = [25, 50, 75]
			LevelManager.boss_breach_spawn_wave = [100]
			LevelManager.boss_tier = 1
	LevelManager.wave_value_current = LevelManager.wave_value
