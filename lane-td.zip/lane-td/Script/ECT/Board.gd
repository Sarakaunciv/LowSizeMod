extends Node2D

func _ready():
	pass

func setup_level():
	LevelManager.add_energy(Config.energy_start)
	match LevelManager.level_world:
		0:
			LevelManager.add_energy(18000000)
			LevelManager.level_wave_max = 3
			LevelManager.wave_value = 10
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 4
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 4
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 1
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = true
		1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
		2:
			LevelManager.level_wave_max = 30
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
		3:
			LevelManager.level_wave_max = 40
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
		4:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = false
		5:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = false
		6:
			LevelManager.level_wave_max = 60
			LevelManager.wave_value = 3
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = true
		7:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 12
			LevelManager.wave_value_add = 10
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 12
			LevelManager.wave_timer_first = 32
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = true
		8:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 4
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 32
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = true
		9:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 32
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = true
		10:
			LevelManager.level_wave_max = 100
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 6
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = true
		-1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
			LevelManager.fast_0_eneble = true
			LevelManager.strong_0_eneble = true
			LevelManager.tank_0_eneble = true
	LevelManager.wave_value_current = LevelManager.wave_value
