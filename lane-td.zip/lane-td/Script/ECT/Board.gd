extends Node2D

func _ready():
	pass

func setup_level():
	LevelManager.add_energy(Config.energy_start)
	LevelManager.wave_timer = 10
	LevelManager.wave_timer_first = 20
	match Config.level_world:
		0:
			Config.add_money(500000)
			LevelManager.add_energy(18000000)
			LevelManager.level_wave_max = 1000
			LevelManager.wave_value = 750
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 1
		1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
		2:
			LevelManager.level_wave_max = 30
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
		3:
			LevelManager.level_wave_max = 40
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
		4:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
		5:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
		6:
			LevelManager.level_wave_max = 60
			LevelManager.wave_value = 3
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
		7:
			LevelManager.level_wave_max = 60
			LevelManager.wave_value = 4
			LevelManager.wave_value_add = 3
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
		8:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 4
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			LevelManager.giga_0_eneble = false
		9:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.giga_0_eneble = false
		10:
			LevelManager.level_wave_max = 100
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 16
		11:
			LevelManager.level_wave_max = 120
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
		12:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 50
			LevelManager.wave_value_add = 25
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 5
			LevelManager.w_v_a_goal = 1
			LevelManager.wave_timer = 30
			LevelManager.wave_timer_first = 60
		13:
			LevelManager.level_wave_max = 100
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 5
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 5
			LevelManager.w_v_a_goal = 2
		14:
			LevelManager.level_wave_max = 40
			LevelManager.wave_value = 15
			LevelManager.wave_value_add = 15
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 15
			LevelManager.w_v_a_goal = 2
		15:
			LevelManager.level_wave_max = 1000
			LevelManager.wave_value = 4
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
		-1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
	LevelManager.wave_value_current = LevelManager.wave_value
