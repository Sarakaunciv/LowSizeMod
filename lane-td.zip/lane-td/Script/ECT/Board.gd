extends Node2D

func _ready():
	pass

func setup_level():
	LevelManager.add_energy(Config.energy_start)
	LevelManager.wave_timer = 20
	LevelManager.wave_timer_first = 20
	match Config.level_world:
		0:
			Config.add_money(500000)
			LevelManager.add_energy(18000000)
			LevelManager.level_wave_max = 1000
			LevelManager.wave_value = 500
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 90000
			LevelManager.wave_timer_first = 1000
		1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			
			LevelManager.fast_0_eneble = false
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		2:
			LevelManager.level_wave_max = 30
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			
			LevelManager.strong_0_eneble = false
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		3:
			LevelManager.level_wave_max = 40
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
			
			LevelManager.tank_0_eneble = false
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		4:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 2
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 2
			
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_eneble = false
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		5:
			LevelManager.level_wave_max = 60
			LevelManager.wave_value = 3
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 2
			LevelManager.w_v_a_goal = 2
			
			LevelManager.massive_0_eneble = false
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		6:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 4
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 1
			
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_block_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		7:
			LevelManager.level_wave_max = 80
			LevelManager.wave_value = 4
			LevelManager.wave_value_add = 4
			LevelManager.wave_value_goal = 2
			LevelManager.w_v_a_add = 2
			LevelManager.w_v_a_goal = 1
			
			LevelManager.giga_0_eneble = false
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		8:
			LevelManager.level_wave_max = 90
			LevelManager.wave_value = 4
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 3
			LevelManager.w_v_a_goal = 3
			
			LevelManager.basic_parent_grand_eneble = false
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		9:
			LevelManager.level_wave_max = 100
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 2
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 5
			LevelManager.w_v_a_goal = 3
			
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_eneble = false
			LevelManager.tank_gun_lot_eneble = false
		10:
			LevelManager.level_wave_max = 120
			LevelManager.wave_value = 5
			LevelManager.wave_value_add = 5
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 9
			LevelManager.w_v_a_goal = 3
			LevelManager.wave_timer = 15
			LevelManager.wave_timer_first = 15
			
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.strong_explode_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_titan_spawn_wave = [120]
			LevelManager.boss_tier = 64
		11:
			LevelManager.level_wave_max = 150
			LevelManager.wave_value = 6
			LevelManager.wave_value_add = 5
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 6
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 15
			LevelManager.wave_timer_first = 15
			
			LevelManager.basic_growing_eneble = false
			LevelManager.fast_phase_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_titan_spawn_wave = [1, 50, 100, 150]
			LevelManager.boss_tier = 1
		12:
			LevelManager.level_wave_max = 50
			LevelManager.wave_value = 100
			LevelManager.wave_value_add = 100
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 100
			LevelManager.w_v_a_goal = 1
			LevelManager.wave_timer = 30
			LevelManager.wave_timer_first = 60
			
			LevelManager.fast_phase_eneble = false
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_breach_spawn_wave = [50]
			LevelManager.boss_tier = 64
		13:
			LevelManager.level_wave_max = 160
			LevelManager.wave_value = 8
			LevelManager.wave_value_add = 6
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 8
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 15
			LevelManager.wave_timer_first = 15
			
			LevelManager.tank_gun_lot_eneble = false
			
			LevelManager.boss_titan_spawn_wave = [5, 40, 80, 120, 160]
			LevelManager.boss_breach_spawn_wave = [40]
			LevelManager.boss_tier = 1
		14:
			LevelManager.level_wave_max = 200
			LevelManager.wave_value = 50
			LevelManager.wave_value_add = 10
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 10
			LevelManager.w_v_a_goal = 2
			LevelManager.wave_timer = 15
			LevelManager.wave_timer_first = 15
			
			LevelManager.boss_titan_spawn_wave = [5, 40, 80, 120, 160, 200]
			LevelManager.boss_breach_spawn_wave = [80, 160, 200]
			LevelManager.boss_tier = 1
		15:
			LevelManager.level_wave_max = 1000
			LevelManager.wave_value = 12
			LevelManager.wave_value_add = 10
			LevelManager.wave_value_goal = 1
			LevelManager.w_v_a_add = 5
			LevelManager.w_v_a_goal = 1
			LevelManager.wave_timer = 15
			LevelManager.wave_timer_first = 15
			
			LevelManager.boss_titan_spawn_wave = [10, 50, 100, 150, 200, 400, 600, 800, 1000]
			LevelManager.boss_breach_spawn_wave = [50, 150, 200, 400, 600, 800, 1000]
			LevelManager.boss_tier = 1
		-1:
			LevelManager.level_wave_max = 20
			LevelManager.wave_value = 1
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_goal = 3
			LevelManager.w_v_a_add = 1
			LevelManager.w_v_a_goal = 3
	LevelManager.wave_value_current = LevelManager.wave_value
