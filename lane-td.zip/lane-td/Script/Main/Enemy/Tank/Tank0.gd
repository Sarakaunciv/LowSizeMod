extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 3000 * tier
	hp_left = 3000 * tier
	attack_damage = 4000 * tier
	move_speed = 20
	knockback_distance = 6
	stop_percent = 0.2
	ready0()
	sprite_2d.global_position.y += randi_range(-16, 16)

func death():
	Config.add_money(tier * Global.tank_v)
	LevelManager.add_enemy(-1)
	queue_free()
