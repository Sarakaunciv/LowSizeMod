class_name EnemyBase
extends Node2D

#Stats
var hp_max: int = 200
var hp_left: int = 200
var attack_damage: int = 50
var move_speed: int = 30
var knockback_distance: int = 30
var stop_percent: float = 1.0
var damage_to_frag_percent: float = 1.0
var damage_to_frag: int = 0

var is_stop: bool = false

var tier: int = 1
var flash_duration: float = 0.1

var sprite_size: int = 1
var sprite_z_index: int = 8

#Function
var self_node
var sprite_2d
var flash_sprite
var health_bar
var timer_flash
var timer_stop
func ready0() -> void:
	self_node = get_node(".")
	sprite_2d = get_node("Sprite2D")
	flash_sprite = get_node("Sprite2D/Flash")
	health_bar = get_node("Sprite2D/HealthBar")
	timer_flash = get_node("TimerFlash")
	timer_stop = get_node("TimerStop")
	health_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sprite_2d.z_index = sprite_z_index
	flash_sprite.region_rect = sprite_2d.region_rect
	flash_sprite.modulate = Color(2, 2, 2, 1)
	timer_flash.one_shot = true
	timer_flash.wait_time = flash_duration
	timer_flash.timeout.connect(flash_out)
	timer_stop.timeout.connect(not_stop)

func _physics_process(delta: float):
	if is_stop == true:
		return
	else:
		position.x -= move_speed * delta

func flash():
	timer_flash.start()
	flash_sprite.visible = true
func flash_out():
	flash_sprite.visible = false

func stop(stop_duration):
	is_stop = true
	timer_stop.wait_time = stop_duration * stop_percent
	timer_stop.start()
func not_stop():
	is_stop = false

@onready var armor: Sprite2D = $Sprite2D/Armor
func update_tier():
	if tier == 1:
		return
	else:
		hp_left *= tier
		hp_max *= tier
		attack_damage *= tier
		armor.visible = true
		match tier:
			16:
				armor.region_rect.position.x += 8
			64:
				armor.region_rect.position.x += 16
			256:
				armor.region_rect.position.x += 24
			1024:
				armor.region_rect.position.x += 32
			4096:
				armor.region_rect.position.x += 40
			16384:
				armor.region_rect.position.x += 48
			65536:
				armor.region_rect.position.x += 56

var turret
var tile_turret
func _on_area_2d_area_entered(area: Area2D):
	turret = area.get_node("..")
	if turret.hp_left > 0:
		if turret.hp_left < attack_damage:
			self.global_position.x += float(knockback_distance) * turret.hp_left / attack_damage
		else:
			self.global_position.x += knockback_distance
	turret.take_damage(attack_damage)

func take_damage(bullet_damage):
	flash()
	hp_left -= bullet_damage
	health_bar.update_health_bar()
	if hp_left <= 0:
		self_node.death()

#func death():
	#LevelManager.add_enemy(-1)
	#queue_free()

#var frag_enemy = load()
#var frag_count: int = 4
#var spawner
#func frag_spawn():
	#spawner = get_node("..")
	#for frag in range(frag_count):
		#var enemy = frag_enemy.instantiate()
		#enemy.tier = tier
		#spawner.add_child(enemy)
		#if Config.pierce_to_frag == true:
			#enemy.hp_left -= damage_to_frag * tier
			#enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
		#var frag_health_bar = enemy.get_node("Sprite2D/HealthBar")
		#frag_health_bar.update_health_bar()
		#if enemy.hp_left <= 0:
			#enemy.death()
		#else:
			#enemy.global_position = self.global_position + Vector2(16 * frag, 0)
			#if enemy.global_position.x > 1920:
				#enemy.global_position.x = 1920
