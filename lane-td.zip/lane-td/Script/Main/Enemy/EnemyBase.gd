class_name EnemyBase
extends Node2D

#Stats
var hp_max: int = 200
var hp_left: int = 200
var attack_damage: int = 50
var move_speed: int = 30
var knockback_distance: int = 30
var stop_percent: float = 1.0
var damage_to_frag_percent: float = 1.0
var damage_to_frag: int = 0

var is_stop: bool = false
var is_dead: bool = false

var tier: int = 1
var flash_duration: float = 0.1

var sprite_size: int = 1
var sprite_distance: int = 0
var sprite_z_index_base: int = 4
var sprite_z_index: int = 4

#Special
var turret_tile

var mine_resist_level: int = 1
var is_divert_immune: bool = false

var fuse_area_collision
var fuse_id: int = 0
var fuse
var is_fuse: bool = true
var fuse_count: int = 1
var fuse_scale: float = 1.0

var timer_parent
var parent_delay: float = 1.0

var block

#Function
var spawner
var self_node
var sprite_2d
var flash_sprite
var health_bar
var timer_flash
var timer_stop
func ready0() -> void:
	spawner = get_node("..")
	self_node = get_node(".")
	sprite_2d = get_node("Sprite2D")
	flash_sprite = get_node("Sprite2D/Flash")
	health_bar = get_node("Sprite2D/HealthBar")
	timer_flash = get_node("TimerFlash")
	timer_stop = get_node("TimerStop")
	take_damage(0)
	health_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sprite_2d.z_index = sprite_z_index
	flash_sprite.region_rect = sprite_2d.region_rect
	flash_sprite.modulate = Color(2, 2, 2, 1)
	timer_flash.one_shot = true
	timer_flash.wait_time = flash_duration
	timer_flash.timeout.connect(flash_out)
	timer_stop.timeout.connect(not_stop)
	sprite_2d.global_position.y += randi_range(sprite_distance * -1, sprite_distance)

var timer_delay_ready
var timer_delay_ready_duration: float = 0.3
func ready1():
	timer_delay_ready = get_node("TimerDelayReady")
	timer_delay_ready.wait_time = timer_delay_ready_duration
	timer_delay_ready.timeout.connect(self_node.ready_delay)
	timer_delay_ready.start()

func _process(delta: float):
	if is_stop == true:
		return
	else:
		position.x -= move_speed * delta

func flash():
	timer_flash.start()
	flash_sprite.visible = true
func flash_out():
	flash_sprite.visible = false

func stop(stop_duration):
	is_stop = true
	timer_stop.wait_time = stop_duration * stop_percent
	timer_stop.start()
func not_stop():
	is_stop = false

@onready var armor: Sprite2D = $Sprite2D/Armor
func update_tier():
	if tier == 1:
		return
	else:
		armor.visible = true
		armor.region_rect.position.x = 64
		match tier:
			16:
				armor.region_rect.position.x += 8
			64:
				armor.region_rect.position.x += 16
			256:
				armor.region_rect.position.x += 24
			1024:
				armor.region_rect.position.x += 32
			4096:
				armor.region_rect.position.x += 40
			16384:
				armor.region_rect.position.x += 48
			65536:
				armor.region_rect.position.x += 56

var turret
func _on_area_2d_area_entered(area: Area2D):
	turret = area.get_node("..")
	if turret.hp_left > 0:
		if turret.hp_left < attack_damage / turret.dmg_reduction:
			self.global_position.x += float(knockback_distance) * turret.hp_left / (attack_damage / turret.dmg_reduction)
		else:
			self.global_position.x += knockback_distance
	turret.take_damage(attack_damage)

func take_damage(bullet_damage):
	if is_fuse == true:
		return
	elif bullet_damage > 0:
		flash()
		hp_left -= bullet_damage
	health_bar.update_health_bar()
	if hp_left <= 0:
		self_node.death()

func ready_fuse():
	hp_max = hp_max * fuse_count
	hp_left = hp_left * fuse_count
	attack_damage = attack_damage * fuse_count
	self_node.fuse_scale_sprite()
func _on_fuse_area_entered(area: Area2D) -> void:
	fuse = area.get_node("..")
	if fuse_id == fuse.fuse_id and is_fuse == false and fuse.is_fuse == false and tier == fuse.tier:
		fuse.is_fuse = true
		hp_max += fuse.hp_max
		hp_left += fuse.hp_left
		attack_damage += fuse.attack_damage
		parent_delay = (parent_delay * fuse_count) + (fuse.parent_delay * fuse.fuse_count)
		damage_to_frag = (damage_to_frag * fuse_count) + (fuse.damage_to_frag * fuse.fuse_count)
		fuse_count += fuse.fuse_count
		parent_delay /= fuse_count
		damage_to_frag /= fuse_count
		self_node.fuse_scale_sprite()
		health_bar.update_health_bar()
		fuse.death_fuse()
	return

func _on_tier_up_area_entered(area: Area2D) -> void:
	if tier < 65536:
		tier *= 4
		self_node._ready()
