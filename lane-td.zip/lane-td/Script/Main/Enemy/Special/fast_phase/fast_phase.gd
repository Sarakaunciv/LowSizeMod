extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 30000 * tier
	hp_left = 30000 * tier
	attack_damage = 30000 * tier
	move_speed = 10
	knockback_distance = 0
	stop_percent = 0.01
	
	timer_delay_ready_duration = 5.0
	
	mine_resist_level = 500
	is_divert_immune = true
	
	sprite_z_index = 10
	ready0()
	ready1()
	is_fuse = false

func ready_delay():
	move_speed = 300
	timer_delay_ready.queue_free()

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.fast_phase_v * 2)
		LevelManager.add_enemy(-1)
		queue_free()

func _on_return_area_entered(area: Area2D) -> void:
	self.global_position.x = 1720
