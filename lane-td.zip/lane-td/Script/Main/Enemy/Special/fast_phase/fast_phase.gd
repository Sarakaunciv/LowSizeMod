extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 9000 * tier
	hp_left = 9000 * tier
	attack_damage = 16000 * tier
	move_speed = 10
	knockback_distance = 0
	stop_percent = 0.05
	
	timer_delay_ready_duration = 15.0
	ready0()
	ready1()

func ready_delay():
	move_speed = 300
	timer_delay_ready.queue_free()

func death():
	Config.add_money(tier * Global.fast_phase_v)
	LevelManager.add_enemy(-1)
	queue_free()

func _on_return_area_entered(area: Area2D) -> void:
	self.global_position.x = 1720
