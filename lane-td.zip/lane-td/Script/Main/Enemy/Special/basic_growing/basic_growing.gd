extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 30000 * tier
	hp_left = 30000 * tier
	attack_damage = 4000 * tier
	move_speed = 1
	knockback_distance = 40
	stop_percent = 0.1
	
	mine_resist_level = 20
	
	parent_delay = 10
	sprite_distance = 8
	ready0()
	ready1()
	is_fuse = false

func ready_delay():
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	timer_parent.start()
	timer_delay_ready.queue_free()

func take_damage(bullet_damage):
	if is_fuse == true:
		return
	elif bullet_damage > 0:
		flash()
		hp_left -= bullet_damage
	health_bar.update_health_bar()
	if hp_left <= 0:
		self_node.death()
	elif fuse_count < 256 and hp_left < hp_max / 4: #
		parent() #

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.basic_growing_v * 4)
		LevelManager.add_enemy(-1)
		queue_free()

func parent():
	if fuse_count == 256:
		move_speed = 60
		timer_parent.queue_free()
	else:
		sprite_2d.scale += Vector2(1, 1)
		hp_left += hp_max - (damage_to_frag * fuse_count)
		hp_max *= 2
		attack_damage *= 2
		fuse_count *= 2
		health_bar.update_health_bar()
