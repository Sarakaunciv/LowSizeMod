extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 6250 * tier
	hp_left = 6250 * tier
	attack_damage = 500 * tier
	move_speed = 4
	knockback_distance = 40
	stop_percent = 0.1
	
	parent_delay = 10
	timer_delay_ready_duration = 10
	sprite_distance = 8
	ready0()
	ready1()

func ready_delay():
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	timer_parent.start()
	timer_delay_ready.queue_free()

func death():
	Config.add_money(tier * Global.basic_growing_v)
	LevelManager.add_enemy(-1)
	queue_free()

func parent():
	if fuse_count == 256:
		move_speed = 60
		timer_parent.queue_free()
	else:
		sprite_2d.scale += Vector2(1, 1)
		hp_left += hp_max - (damage_to_frag * fuse_count)
		hp_max *= 2
		attack_damage *= 2
		move_speed += 2
		fuse_count *= 2
		health_bar.update_health_bar()
