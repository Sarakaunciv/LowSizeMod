extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 3000 * tier
	hp_left = 3000 * tier
	attack_damage = 16000 * tier
	move_speed = 40
	knockback_distance = 30
	stop_percent = 0.15
	ready0()

func death():
	frag_spawn(1)
	Config.add_money(tier * Global.fast_block_v)
	LevelManager.add_enemy(-1)
	queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Special/strong_explode/strong_explode_exp/strong_explode_exp.tscn")
var spawner
func frag_spawn(frag_count):
	spawner = get_node("..")
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.add_child(enemy)
		enemy.global_position = self.global_position + Vector2(8 * frag, 0)
		if enemy.global_position.x > 1920:
			enemy.global_position.x = 1920
