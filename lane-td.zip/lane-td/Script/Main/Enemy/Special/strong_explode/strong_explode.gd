extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 9000 * tier
	hp_left = 9000 * tier
	attack_damage = 16000 * tier
	move_speed = 50
	knockback_distance = 30
	stop_percent = 0.15
	
	mine_resist_level = 20
	
	ready0()
	is_fuse = false

func death():
	if is_dead == false:
		is_dead = true
		frag_spawn(1)
		Config.add_money(tier * Global.strong_explode_v)
		LevelManager.add_enemy(-1)
		queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Special/strong_explode/strong_explode_exp/strong_explode_exp.tscn")
func frag_spawn(frag_count):
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.call_deferred("add_child", enemy)
		enemy.position = self.position
