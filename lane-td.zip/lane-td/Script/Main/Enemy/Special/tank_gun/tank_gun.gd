extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 3000 * tier
	hp_left = 3000 * tier
	attack_damage = 0 * tier
	move_speed = 30 #
	knockback_distance = 30 #
	stop_percent = 1.0 #
	
	parent_delay = 0.8
	sprite_distance = 8
	ready0()
	ready1()
	is_fuse = false

func ready_delay():
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	timer_parent.start()
	self.global_position.x = randi_range(1880 - sprite_distance, 1880 + sprite_distance)
	timer_delay_ready.queue_free()

func _process(delta: float):
	return

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.tank_gun_v)
		LevelManager.add_enemy(-1)
		queue_free()

func parent():
	frag_spawn(1)

var frag_enemy = load("res://Script/Main/Enemy/Special/tank_gun/tank_gun_bullet/tank_gun_bullet.tscn")
func frag_spawn(frag_count):
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.call_deferred("add_child", enemy)
		enemy.position = self.position
