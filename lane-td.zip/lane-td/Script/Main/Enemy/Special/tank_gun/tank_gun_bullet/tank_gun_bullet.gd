extends EnemyBase

func _ready():
	update_tier()
	attack_damage = 16000 * tier
	move_speed = 300
	sprite_distance = 16
	ready0()

func _on_area_2d_area_entered(area: Area2D):
	if area.collision_layer == 2:
		turret = area.get_node("..")
		turret.take_damage(attack_damage)
	frag_spawn(1)
	queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Special/tank_gun/tank_gun_bullet/tank_gun_exp/tank_gun_exp.tscn")
func frag_spawn(frag_count):
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.add_child(enemy)
		enemy.global_position = self.global_position + Vector2(8 * frag, 0)
		if enemy.global_position.x > 1920:
			enemy.global_position.x = 1920
