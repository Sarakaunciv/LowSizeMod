extends EnemyBase

func _ready():
	update_tier()
	attack_damage = 16000 * tier
	move_speed = 300
	
	sprite_distance = 16
	ready0()
	ready_fuse()

func _on_area_2d_area_entered(area: Area2D):
	if area.collision_layer == 2:
		turret = area.get_node("..")
		turret.take_damage(attack_damage)
	frag_spawn(1)
	queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Special/tank_gun/tank_gun_bullet/tank_gun_exp/tank_gun_exp.tscn")
func frag_spawn(frag_count):
	var enemy = frag_enemy.instantiate()
	enemy.tier = tier
	enemy.fuse_count = fuse_count * frag_count #fuse
	spawner.call_deferred("add_child", enemy)
	enemy.position = self.position

func fuse_scale_sprite():
	if fuse_count == 16:
		fuse_scale = 2.0
	elif fuse_count == 4:
		fuse_scale = 1.0
	else:
		fuse_scale = 0
	fuse_scale += 2.0
	sprite_2d.scale = Vector2(fuse_scale, fuse_scale)
