extends EnemyBase

func _ready():
	update_tier()
	attack_damage = 4000 * tier
	ready0()
	ready1()
	self.modulate = Color(1, 1, 1, 0.25)
	self.scale *= 3

func ready_delay():
	queue_free()

func _physics_process(delta: float):
	return

func _on_area_2d_area_entered(area: Area2D):
	turret = area.get_node("..")
	turret.take_damage(attack_damage)
