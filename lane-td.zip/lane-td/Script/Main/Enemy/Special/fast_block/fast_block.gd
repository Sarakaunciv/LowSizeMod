extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 3000 * tier
	hp_left = 3000 * tier
	attack_damage = 4000 * tier
	move_speed = 120
	knockback_distance = 80
	stop_percent = 0.05
	sprite_distance = 16
	
	if LevelManager.weak_awake == true:
		atk_multiplier = 4
		dmg_reduction = 10
		move_speed = 200
		knockback_distance = 120
	
	mine_resist_level = 10
	
	ready0()
	is_fuse = false

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.fast_block_v)
		LevelManager.add_enemy(-1)
		queue_free()

func _on_turret_tile_area_entered(area: Area2D) -> void:
	turret_tile = area.get_node("..")
	turret_tile.plant_block_enemy(tier)

func _on_heal_area_entered(area: Area2D) -> void:
	block = area.get_node("..")
	block.hp_regen(tier)
