extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 9000 * tier
	hp_left = 9000 * tier
	attack_damage = 50 * tier #
	move_speed = 30 #
	knockback_distance = 30 #
	stop_percent = 1 #
	
	sprite_z_index -= 1
	ready0()
	is_fuse = false

func _physics_process(delta: float):
	return

func death():
	Config.add_money(tier * Global.tank_v)
	LevelManager.add_enemy(-1)
	turret_tile = get_node("..")
	turret_tile.occupy_block_enemy = false
	queue_free()

func hp_regen(tier0):
	hp_left += hp_max * tier0
	if hp_left > hp_max:
		hp_left = hp_max
	health_bar.update_health_bar()
