extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 30000 * tier
	hp_left = 30000 * tier
	attack_damage = 0 * tier
	move_speed = 30 #
	knockback_distance = 30 #
	stop_percent = 1.0 #
	
	parent_delay = 0.6
	sprite_distance = 8
	ready0()
	ready1()
	is_fuse = false

func ready_delay():
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	timer_parent.start()
	self.global_position.x = randi_range(1880 - sprite_distance, 1880 + sprite_distance)
	timer_delay_ready.queue_free()

func _physics_process(delta: float):
	return

func death():
	Config.add_money(tier * Global.basic_parent_v)
	LevelManager.add_enemy(-1)
	queue_free()

func parent():
	frag_spawn(4)

var frag_enemy = load("res://Script/Main/Enemy/Special/tank_gun/tank_gun_bullet/tank_gun_bullet.tscn")
var spawner
func frag_spawn(frag_count):
	spawner = get_node("..")
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.add_child(enemy)
		enemy.global_position = self.global_position + Vector2(8 * frag, 0)
