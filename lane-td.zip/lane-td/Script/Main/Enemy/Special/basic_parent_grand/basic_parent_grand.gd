extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 30000 * tier
	hp_left = 30000 * tier
	attack_damage = 0 * tier
	move_speed = 30 #
	knockback_distance = 30 #
	stop_percent = 1.0
	
	parent_delay = 0.25
	damage_to_frag_percent = 0.08
	sprite_distance = 8
	ready0()
	ready1()

func ready_delay():
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	timer_parent.start()
	self.global_position.x = randi_range(1800 - sprite_distance, 1800 + sprite_distance)
	timer_delay_ready.queue_free()

func _physics_process(delta: float):
	return

func death():
	frag_spawn(4)
	Config.add_money(tier * Global.basic_parent_grand_v)
	LevelManager.add_enemy(-1)
	queue_free()

func parent():
	if parent_delay == 4:
		pass
	else:
		parent_delay += 0.25
		timer_parent.wait_time = parent_delay
	frag_spawn(1)

var frag_enemy = load("res://Script/Main/Enemy/Special/basic_parent/basic_parent.tscn")
var spawner
func frag_spawn(frag_count):
	spawner = get_node("..")
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.add_child(enemy)
		if Config.pierce_to_frag == true:
			enemy.hp_left -= damage_to_frag * tier
			enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
		enemy.health_bar.update_health_bar()
		if enemy.hp_left <= 0:
			enemy.death()
		else:
			enemy.global_position = self.global_position + Vector2(8 * frag, 0)
			if enemy.global_position.x > 1920:
				enemy.global_position.x = 1920
