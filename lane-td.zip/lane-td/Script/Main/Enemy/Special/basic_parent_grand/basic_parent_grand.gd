extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 30000 * tier
	hp_left = 30000 * tier
	attack_damage = 0 * tier
	move_speed = 30 #
	knockback_distance = 30 #
	stop_percent = 1.0
	
	fuse_id = 3
	parent_delay = 0.1
	damage_to_frag_percent = 0.08
	ready0()
	ready1()
	fuse_area_collision = self.get_node("Fuse/CollisionShape2D")

func ready_delay():
	is_fuse = false
	fuse_area_collision.disabled = false
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	timer_parent.start()
	self.global_position.x = 1800
	timer_delay_ready.queue_free()

func _process(delta: float):
	return

func death():
	if is_dead == false:
		is_dead = true
		frag_spawn(4)
		Config.add_money(tier * Global.basic_parent_grand_v * (fuse_count ** 0.85))
		LevelManager.add_enemy(-1)
		queue_free()
func death_fuse():
	if is_dead == false:
		is_dead = true
		LevelManager.add_enemy(-1)
		queue_free()

func parent():
	if parent_delay >= 8.0:
		parent_delay = 8.0
	else:
		parent_delay += 0.1
	timer_parent.wait_time = parent_delay
	frag_spawn(1)

var frag_enemy = load("res://Script/Main/Enemy/Special/basic_parent/basic_parent.tscn")
func frag_spawn(frag_count):
	var enemy = frag_enemy.instantiate()
	enemy.tier = tier
	enemy.fuse_count = fuse_count * frag_count #fuse
	if Config.pierce_to_frag == true:
		enemy.damage_to_frag_to_apply = damage_to_frag * tier * fuse_count
		enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
	spawner.call_deferred("add_child", enemy)
	enemy.position = self.position

func fuse_scale_sprite():
	if fuse_count >= 80:
		fuse_scale = 4.0
	elif fuse_count >= 40 and fuse_count < 80:
		fuse_scale = float(fuse_count - 40.0) / 40.0 + 3.0
	elif fuse_count >= 20 and fuse_count < 40:
		fuse_scale = float(fuse_count - 20.0) / 20.0 + 2.0
	#elif fuse_count >= 10 and fuse_count < 20:
		#fuse_scale = float(fuse_count - 10.0) / 10.0 + 4.0 + 1.0
	else:
		fuse_scale = float(fuse_count - 0.0) / 10.0 + 0.0
	fuse_scale += 8.0
	sprite_2d.scale = Vector2(fuse_scale, fuse_scale)
