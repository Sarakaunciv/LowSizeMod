extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 1500000 * tier
	hp_left = 1500000 * tier
	attack_damage = 1250000 * tier
	move_speed = 4
	knockback_distance = 5
	stop_percent = 0.01
	
	damage_to_frag_percent = 0.01
	self.global_position = Vector2(2240, 560)
	sprite_z_index = 2
	ready0()
	flash_sprite.modulate = Color(1.5, 1.5, 1.5, 1)
	sprite_size = 4
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= sprite_size
		if child.name == "HealthBar":
			child.position *= Vector2(sprite_size, sprite_size)

func death():
	frag_spawn(8)
	Config.add_money(tier * Global.titan_v)
	LevelManager.add_enemy(-1)
	queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Normal/Giga/giga_0.tscn")
var spawner
func frag_spawn(frag_count):
	spawner = get_node("..")
	for frag in range(frag_count):
		for frag0 in range(4):
			var enemy = frag_enemy.instantiate()
			enemy.tier = tier
			spawner.add_child(enemy)
			if Config.pierce_to_frag == true:
				enemy.hp_left -= damage_to_frag * tier
				enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
			enemy.health_bar.update_health_bar()
			if enemy.hp_left <= 0:
				enemy.death()
			else:
				enemy.global_position = Vector2(self.global_position.x - 240 + (frag0 * 80), spawner.global_position.y + (frag * 80))
				if enemy.global_position.x > 1920:
					enemy.global_position.x = 1920
