extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 2500000 * tier
	hp_left = 2500000 * tier
	attack_damage = 1250000 * tier
	move_speed = 4
	knockback_distance = 5
	stop_percent = 0.01
	
	mine_resist_level = 100
	is_divert_immune = true
	
	damage_to_frag_percent = 0.01
	self.global_position = Vector2(2240, 560)
	sprite_z_index -= 2
	ready0()
	is_fuse = false
	flash_sprite.modulate = Color(1.5, 1.5, 1.5, 1)
	sprite_size = 4
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= sprite_size
		if child.name == "HealthBar":
			child.position *= Vector2(sprite_size, sprite_size)

func death():
	if is_dead == false:
		is_dead = true
		frag_spawn(8)
		Config.add_money(tier * Global.titan_v)
		LevelManager.add_enemy(-1)
		queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Normal/Giga/giga_0.tscn")
func frag_spawn(frag_count):
	for frag in range(frag_count):
		for frag0 in range(4):
			var enemy = frag_enemy.instantiate()
			enemy.tier = tier
			if Config.pierce_to_frag == true:
				enemy.damage_to_frag_to_apply = damage_to_frag * tier * fuse_count
				enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
			spawner.call_deferred("add_child", enemy)
			enemy.position = Vector2(self.position.x - 240 + (frag0 * 80), frag * 80)
