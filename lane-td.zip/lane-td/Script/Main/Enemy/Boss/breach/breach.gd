extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 1000000 * tier
	hp_left = 1000000 * tier
	attack_damage = 500000 * tier
	move_speed = 100
	knockback_distance = 60
	stop_percent = 0.01
	
	mine_resist_level = 1000
	is_divert_immune = true
	
	parent_delay = 0.3
	self.global_position = Vector2(2240, 560)
	sprite_z_index -= 2
	ready0()
	ready1()
	is_fuse = false
	flash_sprite.modulate = Color(1.5, 1.5, 1.5, 1)
	sprite_size = 4
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= sprite_size
		if child.name == "HealthBar":
			child.position *= Vector2(sprite_size, sprite_size)

func ready_delay():
	frag_spawn0(8)
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	if LevelManager.tank_gun_lot_eneble == true:
		timer_parent.start()
	timer_delay_ready.queue_free()

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.breach_v)
		LevelManager.add_enemy(-1)
		queue_free()

func parent():
	frag_spawn(4)

var frag_enemy = load("res://Script/Main/Enemy/Special/tank_gun/tank_gun_bullet/tank_gun_bullet.tscn")
func frag_spawn(frag_count):
	for frag in range(2):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		enemy.fuse_count = fuse_count * frag_count #fuse
		spawner.call_deferred("add_child", enemy)
		enemy.position = self.position + Vector2(0, 80 * frag - 40)

var frag_enemy0 = load("res://Script/Main/Enemy/Special/fast_phase/fast_phase.tscn")
var frag_enemy1 = load("res://Script/Main/Enemy/Special/tank_gun_lot/tank_gun_lot.tscn")
func frag_spawn0(frag_count):
	for frag in range(frag_count):
		if LevelManager.fast_phase_eneble == true:
			var enemy = frag_enemy0.instantiate()
			enemy.tier = tier
			spawner.call_deferred("add_child", enemy)
			enemy.position = Vector2(0, frag * 80)
		if LevelManager.tank_gun_lot_eneble == true:
			var enemy = frag_enemy1.instantiate()
			enemy.tier = tier
			spawner.call_deferred("add_child", enemy)
			enemy.position = Vector2(0, frag * 80)

func _on_turret_tile_area_entered(area: Area2D) -> void:
	turret_tile = area.get_node("..")
	turret_tile.plant_block_enemy(tier)
