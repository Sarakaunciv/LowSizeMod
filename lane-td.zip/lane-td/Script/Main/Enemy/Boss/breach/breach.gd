extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 500000 * tier
	hp_left = 500000 * tier
	attack_damage = 500000 * tier
	move_speed = 100
	knockback_distance = 60
	stop_percent = 0.01
	
	mine_resist_level = 1000
	
	parent_delay = 0.6
	self.global_position = Vector2(2240, 560)
	sprite_z_index -= 2
	ready0()
	ready1()
	is_fuse = false
	sprite_2d.modulate = Color(1, 0.5, 0.5, 1)
	flash_sprite.modulate = Color(1.5, 1.5, 1.5, 1)
	sprite_size = 4
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= sprite_size
		if child.name == "HealthBar":
			child.position *= Vector2(sprite_size, sprite_size)

func ready_delay():
	frag_spawn0(8)
	timer_parent = get_node("TimerParent")
	timer_parent.wait_time = parent_delay
	timer_parent.timeout.connect(parent)
	if LevelManager.tank_gun_lot_eneble == true:
		timer_parent.start()
	timer_delay_ready.queue_free()

func death():
	Config.add_money(tier * Global.breach_v)
	LevelManager.add_enemy(-1)
	queue_free()

func parent():
	frag_spawn(8)

var frag_enemy = load("res://Script/Main/Enemy/Special/tank_gun/tank_gun_bullet/tank_gun_bullet.tscn")
func frag_spawn(frag_count):
	for frag in range(frag_count):
		for frag0 in range(2):
			var enemy = frag_enemy.instantiate()
			enemy.tier = tier
			spawner.add_child(enemy)
			enemy.global_position = self.global_position + Vector2(8 * frag, 80 * frag0 - 40)

var frag_enemy0 = load("res://Script/Main/Enemy/Special/fast_phase/fast_phase.tscn")
var frag_enemy1 = load("res://Script/Main/Enemy/Special/tank_gun_lot/tank_gun_lot.tscn")
func frag_spawn0(frag_count):
	for frag in range(frag_count):
		if LevelManager.fast_phase_eneble == true:
			var enemy = frag_enemy0.instantiate()
			enemy.tier = tier
			spawner.add_child(enemy)
			enemy.global_position = spawner.global_position + Vector2(0, 80 * frag)
		if LevelManager.tank_gun_lot_eneble == true:
			var enemy = frag_enemy1.instantiate()
			enemy.tier = tier
			spawner.add_child(enemy)
			enemy.global_position = spawner.global_position + Vector2(0, 80 * frag)

func _on_turret_tile_area_entered(area: Area2D) -> void:
	turret_tile = area.get_node("..")
	turret_tile.plant_block_enemy(tier)
