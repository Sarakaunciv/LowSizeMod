extends EnemyBase

@onready var sprite_2d: Sprite2D = $Sprite2D
@onready var flash_sprite: Sprite2D = $Sprite2D/Flash
@onready var timer: Timer = $Timer
@onready var timer_stop: Timer = $TimerStop
func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 1800 * tier
	hp_left = 1800 * tier
	attack_damage = 200 * tier
	move_speed = 25
	knockback_distance = 10
	stop_percent = 0.5
	
	sprite_2d.global_position.y += randi_range(-24, 24)
	flash_sprite.region_rect = sprite_2d.region_rect
	flash_sprite.modulate = Color(2, 2, 2, 1)
	timer.one_shot = true
	timer.wait_time = flash_duration
	timer.timeout.connect(flash_out)
	timer_stop.timeout.connect(not_stop)
	sprite_2d.z_index = sprite_z_index

func flash():
	timer.start()
	flash_sprite.visible = true
func flash_out():
	flash_sprite.visible = false

func _physics_process(delta: float):
	if is_stop == true:
		return
	else:
		position.x -= move_speed * delta

func stop(stop_duration):
	is_stop = true
	timer_stop.wait_time = stop_duration * stop_percent
	timer_stop.start()
func not_stop():
	is_stop = false

@onready var armor: Sprite2D = $Sprite2D/Armor
func update_tier():
	if tier == 1:
		return
	else:
		armor.visible = true
		match tier:
			16:
				armor.region_rect.position.x += 8
			64:
				armor.region_rect.position.x += 16
			256:
				armor.region_rect.position.x += 24
			1024:
				armor.region_rect.position.x += 32
			4096:
				armor.region_rect.position.x += 40
			16384:
				armor.region_rect.position.x += 48
			65536:
				armor.region_rect.position.x += 56

func _on_area_2d_area_entered(area: Area2D):
	turret = area.get_node("..")
	if turret.hp_left < attack_damage and turret.hp_left > 0:
		self.global_position.x += knockback_distance * turret.hp_left / attack_damage
	else:
		self.global_position.x += knockback_distance
	
	turret.hp_left -= attack_damage
	health_bar = turret.get_node("HealthBar")
	health_bar.update_health_bar()
	
	if turret.hp_left <= 0:
		tile_turret = turret.get_node("..")
		tile_turret.kill_node()
	self.global_position.x += knockback_distance

func death():
	Config.add_money(tier * Global.strong_v)
	LevelManager.add_enemy(-1)
	queue_free()
