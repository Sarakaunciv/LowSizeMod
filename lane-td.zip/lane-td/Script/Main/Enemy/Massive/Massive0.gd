extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 9000 * tier
	hp_left = 9000 * tier
	attack_damage = 16000 * tier
	move_speed = 45
	knockback_distance = 30
	stop_percent = 0.15
	
	damage_to_frag_percent = 0.3
	ready0()
	sprite_2d.global_position.y += randi_range(-8, 8)
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= 2
		if child.name == "HealthBar":
			child.position *= Vector2(2, 2)

func death():
	frag_spawn()
	Config.add_money(tier * Global.massive_v)
	LevelManager.add_enemy(-1)
	queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Tank/tank_0.tscn")
var frag_count: int = 4
var spawner
func frag_spawn():
	spawner = get_node("..")
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.add_child(enemy)
		if Config.pierce_to_frag == true:
			enemy.hp_left -= damage_to_frag * tier
			enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
		var frag_health_bar = enemy.get_node("Sprite2D/HealthBar")
		frag_health_bar.update_health_bar()
		if enemy.hp_left <= 0:
			enemy.death()
		else:
			enemy.global_position = self.global_position + Vector2(16 * frag, 0)
			if enemy.global_position.x > 1920:
				enemy.global_position.x = 1920
