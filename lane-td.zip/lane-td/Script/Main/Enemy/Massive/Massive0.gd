extends EnemyBase

@onready var sprite_2d: Sprite2D = $Sprite2D
@onready var flash_sprite: Sprite2D = $Sprite2D/Flash
@onready var timer: Timer = $Timer
@onready var timer_stop: Timer = $TimerStop
func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 9000 * tier
	hp_left = 9000 * tier
	attack_damage = 16000 * tier
	move_speed = 45
	knockback_distance = 4
	stop_percent = 0.15
	
	damage_to_frag_percent = 0.3
	
	sprite_2d.global_position.y += randi_range(-8, 8)
	flash_sprite.region_rect = sprite_2d.region_rect
	flash_sprite.modulate = Color(2, 2, 2, 1)
	timer.one_shot = true
	timer.wait_time = flash_duration
	timer.timeout.connect(flash_out)
	timer_stop.timeout.connect(not_stop)
	sprite_2d.z_index = sprite_z_index
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= 2

func flash():
	timer.start()
	flash_sprite.visible = true
func flash_out():
	flash_sprite.visible = false

func _physics_process(delta: float):
	if is_stop == true:
		return
	else:
		position.x -= move_speed * delta

func stop(stop_duration):
	is_stop = true
	timer_stop.wait_time = stop_duration * stop_percent
	timer_stop.start()
func not_stop():
	is_stop = false

@onready var armor: Sprite2D = $Sprite2D/Armor
func update_tier():
	if tier == 1:
		return
	else:
		armor.visible = true
		match tier:
			16:
				armor.region_rect.position.x += 8
			64:
				armor.region_rect.position.x += 16
			256:
				armor.region_rect.position.x += 24
			1024:
				armor.region_rect.position.x += 32
			4096:
				armor.region_rect.position.x += 40
			16384:
				armor.region_rect.position.x += 48
			65536:
				armor.region_rect.position.x += 56

func _on_area_2d_area_entered(area: Area2D):
	turret = area.get_node("..")
	if turret.hp_left < attack_damage and turret.hp_left > 0:
		self.global_position.x += knockback_distance * turret.hp_left / attack_damage
	else:
		self.global_position.x += knockback_distance
	
	turret.hp_left -= attack_damage
	health_bar = turret.get_node("HealthBar")
	health_bar.update_health_bar()
	
	if turret.hp_left <= 0:
		tile_turret = turret.get_node("..")
		tile_turret.kill_node()
	self.global_position.x += knockback_distance

func death():
	frag_spawn()
	Config.add_money(tier * Global.massive_v)
	LevelManager.add_enemy(-1)
	queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Tank/tank_0.tscn")
var frag_count: int = 4
var spawner
func frag_spawn():
	spawner = get_node("..")
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.add_child(enemy)
		if Config.pierce_to_frag == true:
			enemy.hp_left -= damage_to_frag * tier
		var frag_health_bar = enemy.get_node("Sprite2D/HealthBar")
		frag_health_bar.update_health_bar()
		if enemy.hp_left <= 0:
			enemy.death()
		else:
			enemy.global_position = self.global_position + Vector2(16 * frag, 0)
			if enemy.global_position.x > 1920:
				enemy.global_position.x = 1920
