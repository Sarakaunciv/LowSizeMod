extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 200 * tier #
	hp_left = 200 * tier #
	attack_damage = 50 * tier #
	move_speed = 30 #
	knockback_distance = 15 #
	stop_percent = 1 #
	ready0()
	sprite_2d.global_position.y += randi_range(-24, 24)

func death():
	Config.add_money(tier * Global.basic_v)
	LevelManager.add_enemy(-1)
	queue_free()
