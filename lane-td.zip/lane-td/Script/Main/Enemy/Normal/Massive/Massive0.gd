extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 9000 * tier
	hp_left = 9000 * tier
	attack_damage = 16000 * tier
	move_speed = 60
	knockback_distance = 80
	stop_percent = 0.15
	
	damage_to_frag_percent = 0.3
	sprite_distance = 8
	ready0()
	is_fuse = false
	sprite_size = 2
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= sprite_size
		if child.name == "HealthBar":
			child.position *= Vector2(sprite_size, sprite_size)

func death():
	if is_dead == false:
		is_dead = true
		frag_spawn(4)
		Config.add_money(tier * Global.massive_v)
		LevelManager.add_enemy(-1)
		queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Normal/Tank/tank_0.tscn")
func frag_spawn(frag_count):
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.call_deferred("add_child", enemy)
		if Config.pierce_to_frag == true:
			enemy.hp_left -= damage_to_frag * tier
			enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
		enemy.position = self.position + Vector2(8 * frag, 0)
