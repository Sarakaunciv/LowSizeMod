extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 200 * tier #
	hp_left = 200 * tier #
	attack_damage = 50 * tier #
	move_speed = 30 #
	knockback_distance = 30 #
	stop_percent = 1 #
	
	fuse_id = 1
	sprite_distance = 8
	ready0()
	ready1()

func ready_delay():
	is_fuse = false
	timer_delay_ready.queue_free()

func death():
	Config.add_money(tier * Global.basic_v)
	LevelManager.add_enemy(-1)
	queue_free()

func fuse_scale_sprite():
	fuse_scale = float(fuse_count) / 40.0 + 3.0
	if fuse_scale > 8:
		fuse_scale = 8
	sprite_2d.scale = Vector2(fuse_scale, fuse_scale)
