extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 200 * tier #
	hp_left = 200 * tier #
	attack_damage = 50 * tier #
	move_speed = 30 #
	knockback_distance = 30 #
	stop_percent = 1 #
	
	fuse_id = 1
	sprite_distance = 8
	ready0()
	ready1()
	ready_fuse()
	fuse_area_collision = self.get_node("Fuse/CollisionShape2D")

func ready_delay():
	is_fuse = false
	fuse_area_collision.disabled = false
	timer_delay_ready.queue_free()

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.basic_v * (fuse_count ** 0.85))
		LevelManager.add_enemy(-1)
		queue_free()
func death_fuse():
	if is_dead == false:
		is_dead = true
		LevelManager.add_enemy(-1)
		queue_free()

func fuse_scale_sprite():
	if fuse_count >= 10240:
		fuse_scale = 6.0
	elif fuse_count >= 2560 and fuse_count < 10240:
		fuse_scale = float(fuse_count - 2560.0) / 7680.0 + 5.0
	elif fuse_count >= 640 and fuse_count < 2560:
		fuse_scale = float(fuse_count - 640.0) / 1920.0 + 4.0
	elif fuse_count >= 160 and fuse_count < 640:
		fuse_scale = float(fuse_count - 160.0) / 480.0 + 3.0
	elif fuse_count >= 40 and fuse_count < 160:
		fuse_scale = float(fuse_count - 40.0) / 120.0 + 2.0
	elif fuse_count >= 10 and fuse_count < 40:
		fuse_scale = float(fuse_count - 10.0) / 30.0 + 1.0
	else:
		fuse_scale = float(fuse_count - 0.0) / 10.0 + 0.0
	sprite_2d.scale = Vector2(fuse_scale + 4.0, fuse_scale + 4.0)
