extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 400 * tier
	hp_left = 400 * tier
	attack_damage = 100 * tier
	move_speed = 60
	knockback_distance = 32
	stop_percent = 0.8
	
	if LevelManager.weak_awake == true:
		atk_multiplier = 40
		dmg_reduction = 15
		move_speed = 120
		knockback_distance = 64
		stop_percent = 0.05
	
	sprite_distance = 24
	ready0()
	is_fuse = false

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.fast_v)
		LevelManager.add_enemy(-1)
		queue_free()
