extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1, "0f")
	hp_max = 400 * tier
	hp_left = 400 * tier
	attack_damage = 100 * tier
	move_speed = 60
	knockback_distance = 32
	stop_percent = 0.8
	
	sprite_distance = 24
	ready0()
	is_fuse = false

func death():
	Config.add_money(tier * Global.fast_v)
	LevelManager.add_enemy(-1, "0f")
	queue_free()
