extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 30000 * tier
	hp_left = 30000 * tier
	attack_damage = 16000 * tier
	move_speed = 90
	knockback_distance = 48
	stop_percent = 0.05
	
	if LevelManager.weak_awake == true:
		atk_multiplier = 15
		dmg_reduction = 3
		move_speed = 40
		knockback_distance = 80
		stop_percent = 0.05
	
	damage_to_frag_percent = 0.2
	sprite_distance = 8
	ready0()
	is_fuse = false
	sprite_size = 3
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= sprite_size
		if child.name == "HealthBar":
			child.position *= Vector2(sprite_size, sprite_size)

func death():
	if is_dead == false:
		is_dead = true
		frag_spawn(4)
		Config.add_money(tier * Global.giga_v)
		LevelManager.add_enemy(-1)
		queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Normal/Massive/massive_0.tscn")
func frag_spawn(frag_count):
	var enemy = frag_enemy.instantiate()
	enemy.tier = tier
	enemy.fuse_count = fuse_count * frag_count #fuse
	if Config.pierce_to_frag == true:
		enemy.damage_to_frag_to_apply = damage_to_frag * tier * fuse_count
		enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
	spawner.call_deferred("add_child", enemy)
	enemy.position = self.position
