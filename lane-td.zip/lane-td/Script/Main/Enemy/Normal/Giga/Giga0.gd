extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1, "0g")
	hp_max = 30000 * tier
	hp_left = 30000 * tier
	attack_damage = 16000 * tier
	move_speed = 90
	knockback_distance = 48
	stop_percent = 0.05
	
	damage_to_frag_percent = 0.2
	sprite_distance = 8
	ready0()
	is_fuse = false
	sprite_size = 3
	for child in sprite_2d.find_children("*"):
		if child.name != "Flash":
			child.scale *= sprite_size
		if child.name == "HealthBar":
			child.position *= Vector2(sprite_size, sprite_size)

func death():
	frag_spawn(4)
	Config.add_money(tier * Global.giga_v)
	LevelManager.add_enemy(-1, "0g")
	queue_free()

var frag_enemy = load("res://Script/Main/Enemy/Normal/Massive/massive_0.tscn")
func frag_spawn(frag_count):
	for frag in range(frag_count):
		var enemy = frag_enemy.instantiate()
		enemy.tier = tier
		spawner.add_child(enemy)
		if Config.pierce_to_frag == true:
			enemy.hp_left -= damage_to_frag * tier
			enemy.damage_to_frag += damage_to_frag * enemy.damage_to_frag_percent
		enemy.health_bar.update_health_bar()
		if enemy.hp_left <= 0:
			enemy.death()
		else:
			enemy.global_position = self.global_position + Vector2(8 * frag, 0)
			if enemy.global_position.x > 1920:
				enemy.global_position.x = 1920
