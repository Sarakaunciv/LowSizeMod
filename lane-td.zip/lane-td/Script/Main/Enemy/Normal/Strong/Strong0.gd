extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 1800 * tier
	hp_left = 1800 * tier
	attack_damage = 200 * tier
	move_speed = 25
	knockback_distance = 20
	stop_percent = 0.5
	
	if LevelManager.weak_awake == true:
		atk_multiplier = 20
		dmg_reduction = 50
		move_speed = 40
		knockback_distance = 80
		stop_percent = 0.05
	
	sprite_distance = 24
	ready0()
	is_fuse = false

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.strong_v)
		LevelManager.add_enemy(-1)
		queue_free()
