extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 1800 * tier
	hp_left = 1800 * tier
	attack_damage = 200 * tier
	move_speed = 25
	knockback_distance = 20
	stop_percent = 0.5
	ready0()
	sprite_2d.global_position.y += randi_range(-24, 24)

func death():
	Config.add_money(tier * Global.strong_v)
	LevelManager.add_enemy(-1)
	queue_free()
