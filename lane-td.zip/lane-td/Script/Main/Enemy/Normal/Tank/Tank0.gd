extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1, "0t")
	hp_max = 3000 * tier
	hp_left = 3000 * tier
	attack_damage = 4000 * tier
	move_speed = 40
	knockback_distance = 24
	stop_percent = 0.2
	sprite_distance = 16
	ready0()
	is_fuse = false

func death():
	Config.add_money(tier * Global.tank_v)
	LevelManager.add_enemy(-1, "0t")
	queue_free()
