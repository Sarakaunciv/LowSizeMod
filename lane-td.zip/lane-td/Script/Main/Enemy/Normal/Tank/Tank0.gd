extends EnemyBase

func _ready():
	update_tier()
	LevelManager.add_enemy(1)
	hp_max = 3000 * tier
	hp_left = 3000 * tier
	attack_damage = 4000 * tier
	move_speed = 40
	knockback_distance = 24
	stop_percent = 0.2
	
	if LevelManager.weak_awake == true:
		atk_multiplier = 4
		dmg_reduction = 10
		move_speed = 60
		knockback_distance = 32
		stop_percent = 0.05
	
	sprite_distance = 8
	ready0()
	ready_fuse()
	is_fuse = false

func death():
	if is_dead == false:
		is_dead = true
		Config.add_money(tier * Global.tank_v)
		LevelManager.add_enemy(-1)
		queue_free()

func fuse_scale_sprite():
	if fuse_count == 16:
		fuse_scale = 4.0
	elif fuse_count == 4:
		fuse_scale = 2.0
	else:
		fuse_scale = 0
	fuse_scale += 6.0
	sprite_2d.scale = Vector2(fuse_scale, fuse_scale)
