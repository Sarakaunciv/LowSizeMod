class_name TurretBase
extends Node2D

var hp_max: int = 300
var hp_left: int = 300
var hp_regen_hp: int = 30
var hp_regen_time: float = 10.0

var attack_damage_multiplier: int = 1
var attack_damage: int = 20
var attack_count: int = 1

var attack_burst_distance: int = 16
var attack_delay: float = 1.5

var tier: int = 1
var dmg_reduction: int = 1

var bullet_size: float = 1.0
var sprite_z_index: int = 3

#Function
var turret_tile
func get_turret_tile():
	turret_tile = get_node("..")
	sprite_2d = get_node("Sprite2D")
	self.z_index = sprite_z_index

var sprite_2d
var health_bar
var timer_regen_hp
func ready0() -> void:
	health_bar = get_node("HealthBar")
	timer_regen_hp = get_node("TimerRegenHp")
	health_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()
	for dmg_r in range(Config.wall_upgrade_level):
		dmg_reduction *= 2

func take_damage(enemy_damage):
	hp_left -= enemy_damage / dmg_reduction
	health_bar.update_health_bar()
	if hp_left <= 0:
		turret_tile.kill_turret()

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	health_bar.update_health_bar()

# Energizer Attacker Wall

#func update_tier():
	#tier += 1
	#sprite_2d.region_rect.position.x += 8
	#match tier:
		#2:
			#LevelManager.add_energy(Global.BaseBaseBase2_Cost)
			#tier_common_0()
		#3:
			#LevelManager.add_energy(Global.BaseBaseBase3_Cost)
			#tier_common_0()
		#4:
			#LevelManager.add_energy(Global.BaseBaseBase4_Cost)
			#tier_common_0()
		#5:
			#LevelManager.add_energy(Global.BaseBaseBase5_Cost)
			#tier_common_0()
		#6:
			#LevelManager.add_energy(Global.BaseBaseBase6_Cost)
			#tier_common_0()
	#hp_regen_hp = hp_max / 10
	#hp_regen()
#func tier_common_0():
	#hp_left += hp_max * 1
	#hp_max *= 2
