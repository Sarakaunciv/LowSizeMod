extends TurretBase

@onready var timer_regen_hp: Timer = $TimerRegenHp

func _ready():
	hp_max = 4000
	hp_left = 4000
	hp_regen_hp = 400
	health_bar = get_node("HealthBar")
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	health_bar.update_health_bar()

@onready var sprite_2d: Sprite2D = $Sprite2D
func update_tier():
	tier += 1
	sprite_2d.region_rect.position.x += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Energizer2_Cost)
			tier_common_0()
		3:
			LevelManager.add_energy(Global.Energizer3_Cost)
			tier_common_0()
		4:
			LevelManager.add_energy(Global.Energizer4_Cost)
			tier_common_1()
		5:
			LevelManager.add_energy(Global.Energizer5_Cost)
			tier_common_1()
		6:
			LevelManager.add_energy(Global.Energizer6_Cost)
			tier_common_1()
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 3
	hp_max *= 4
func tier_common_1():
	hp_left += hp_max * 4
	hp_max *= 5
