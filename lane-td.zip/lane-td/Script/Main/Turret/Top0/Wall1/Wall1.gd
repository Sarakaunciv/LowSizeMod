extends TurretBase

func _ready():
	get_turret_tile()
	hp_max = 4000
	hp_left = 4000
	hp_regen_hp = 400
	match Config.wall_upgrade_level:
		1:
			pass
		2:
			hp_max *= 2
			hp_left *= 2
		3:
			hp_max *= 4
			hp_left *= 4
		4:
			hp_max *= 8
			hp_left *= 8
		5:
			hp_max *= 16
			hp_left *= 16
		6:
			hp_max *= 32
			hp_left *= 32
		7:
			hp_max *= 64
			hp_left *= 64
		8:
			hp_max *= 128
			hp_left *= 128
		9:
			hp_max *= 256
			hp_left *= 256
	hp_regen_hp = hp_max / 10
	ready0()

@onready var sprite_2d: Sprite2D = $Sprite2D
func update_tier():
	tier += 1
	sprite_2d.region_rect.position.x += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Wall2_Cost)
			tier_common_0()
		3:
			LevelManager.add_energy(Global.Wall3_Cost)
			tier_common_0()
		4:
			LevelManager.add_energy(Global.Wall4_Cost)
			tier_common_1()
		5:
			LevelManager.add_energy(Global.Wall5_Cost)
			tier_common_1()
		6:
			LevelManager.add_energy(Global.Wall6_Cost)
			tier_common_1()
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 3
	hp_max *= 4
func tier_common_1():
	hp_left += hp_max * 4
	hp_max *= 5
