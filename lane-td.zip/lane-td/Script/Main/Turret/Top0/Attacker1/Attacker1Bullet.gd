extends BulletBase

var turret
@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready() -> void:
	turret = get_node("..")
	bullet_damage = turret.attack_damage
	sprite_2d.scale *= turret.bullet_size
	var del_position_y = randf_range(-16, 16)
	sprite_2d.global_position += Vector2(0, del_position_y)
	sprite_2d.z_index = sprite_z_index

func _physics_process(delta: float):
	position.x += bullet_speed * delta

func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()

func _on_area_2d_area_entered(area: Area2D) -> void:
	if is_hit == true:
		return
	else:
		enemy = area.get_node("..")
		if enemy.hp_left <= 0:
			return
		else:
			is_hit = true
			enemy.flash()
			enemy.hp_left -= bullet_damage
			health_bar = enemy.get_node("Sprite2D/HealthBar")
			health_bar.update_health_bar()
			if enemy.hp_left <= 0:
				enemy.death()
			queue_free()
