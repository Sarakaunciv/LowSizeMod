extends BulletBase

var energy_value_in_unit: int = 0
@onready var timer: Timer = $Timer
var timer_delay: float = 0.04
@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready() -> void:
	var parent = get_node("..")
	energy_value_in_unit = parent.energy_value
	var del_position_x = randf_range(-30, 30)
	var del_position_y = randf_range(-30, 30)
	self.global_position += Vector2(del_position_x, del_position_y)
	timer.wait_time = timer_delay
	timer.timeout.connect(time_out)
	timer.start()
	sprite_2d.z_index = sprite_z_index

func mouse_in_range() -> void:
	LevelManager.add_energy(energy_value_in_unit)
	queue_free()

var mouse_position
var distance_to_mouse
var is_y: bool = false
func time_out():
	mouse_position = get_global_mouse_position()
	distance_to_mouse = self.global_position.distance_to(mouse_position)
	if distance_to_mouse < 80:
		mouse_in_range()
	else:
		match Config.energy_move_mode:
			0:
				return
			1:
				if self.global_position.y > 240:
					self.global_position.y -= 80
			2:
				if self.global_position.y > 240:
					self.global_position.y -= 80
				elif self.global_position.x > 960:
					self.global_position.x -= 80
				elif self.global_position.x < 880:
					self.global_position.x += 80
			3:
				match is_y:
					true:
						is_y = false
						if self.global_position.y > mouse_position.y:
							self.global_position.y -= 80
						else:
							self.global_position.y += 80
					false:
						is_y = true
						if self.global_position.x > mouse_position.x:
							self.global_position.x -= 80
						else:
							self.global_position.x += 80
