extends TurretBase

var energy_value: int = 10
var time_generation: float = 16.0
var time_generation_first: float = 3.0
var total_energizer_max: int = 16
var time_when_max: int = 5

@onready var timer_generation: Timer = $TimerGeneration
@onready var timer_generation_first: Timer = $TimerGenerationFirst

func _ready():
	get_turret_tile()
	timer_generation.wait_time = time_generation
	timer_generation.timeout.connect(generate_energy)
	timer_generation.start()
	if LevelManager.total_energizer >= total_energizer_max:
		timer_generation_first.wait_time = time_generation_first + time_when_max
	elif  LevelManager.total_energizer > 0:
		timer_generation_first.wait_time = time_generation_first + time_when_max * LevelManager.total_energizer / total_energizer_max
	elif LevelManager.total_energizer == 0:
		timer_generation_first.wait_time = time_generation_first
	timer_generation_first.timeout.connect(generate_energy)
	timer_generation_first.start()
	LevelManager.total_energizer += 1
	ready0()

var energy0 = load("res://Script/Main/Turret/Top0/Energizer1/energy.tscn")
var energy
func generate_energy():
	energy = energy0.instantiate()
	call_deferred("add_child", energy)

func update_tier():
	tier += 1
	sprite_2d.region_rect.position.x += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Energizer2_Cost)
			tier_common_0()
			energy_value = 40
		3:
			LevelManager.add_energy(Global.Energizer3_Cost)
			tier_common_0()
			energy_value = 155
		4:
			LevelManager.add_energy(Global.Energizer4_Cost)
			tier_common_1()
			energy_value = 625
		5:
			LevelManager.add_energy(Global.Energizer5_Cost)
			tier_common_1()
			energy_value = 2500
		6:
			LevelManager.add_energy(Global.Energizer6_Cost)
			tier_common_1()
			energy_value = 10000
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 3
	hp_max *= 4
func tier_common_1():
	hp_left += hp_max * 4
	hp_max *= 5
