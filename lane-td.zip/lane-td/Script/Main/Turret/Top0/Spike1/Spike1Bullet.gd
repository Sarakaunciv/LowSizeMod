extends BulletBase

@onready var timer: Timer = $Timer
var timer_delay: float = 0.6
func _ready() -> void:
	get_turret_tile()
	bullet_damage = turret.attack_damage
	timer.wait_time = timer_delay
	timer.timeout.connect(time_out)
	timer.start()

func time_out():
	queue_free()

func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	if enemy.hp_left <= 0:
		return
	else:
		enemy.damage_to_frag += bullet_damage * enemy.damage_to_frag_percent
		enemy.take_damage(bullet_damage * enemy.tier)
		LevelManager.spike_damage += bullet_damage * enemy.tier
