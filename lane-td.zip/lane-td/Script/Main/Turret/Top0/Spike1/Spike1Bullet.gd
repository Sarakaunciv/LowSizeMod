extends BulletBase

var turret
@onready var timer: Timer = $Timer
var timer_delay: float = 0.6
func _ready() -> void:
	turret = get_node("..")
	bullet_damage = turret.attack_damage
	timer.wait_time = timer_delay
	timer.timeout.connect(time_out)
	timer.start()

func time_out():
	queue_free()

func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	if enemy.hp_left <= 0:
		return
	else:
		enemy.flash()
		enemy.hp_left -= bullet_damage * enemy.tier
		enemy.damage_to_frag += bullet_damage * enemy.damage_to_frag_percent
		health_bar = enemy.get_node("Sprite2D/HealthBar")
		health_bar.update_health_bar()
		if enemy.hp_left <= 0:
			enemy.death()
