extends TurretBase

@onready var timer_regen_hp: Timer = $TimerRegenHp
@onready var timer_attack: Timer = $TimerAttack
func _ready():
	attack_damage = 4
	attack_delay = 0.6
	health_bar = get_node("HealthBar")
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()
	timer_attack.wait_time = attack_delay
	timer_attack.timeout.connect(attack)
	timer_attack.start()

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	health_bar.update_health_bar()

var bullet0 = load("res://Script/Main/Turret/Top0/Spike1/spike1bullet.tscn")
var bullet

func attack():
	bullet = bullet0.instantiate()
	add_child(bullet)

@onready var sprite_2d: Sprite2D = $Sprite2D
func update_tier():
	tier += 1
	sprite_2d.region_rect.position.x += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Spike2_Cost)
			tier_common_0()
			attack_count = 8
		3:
			LevelManager.add_energy(Global.Spike3_Cost)
			tier_common_0()
			attack_count = 12
		4:
			LevelManager.add_energy(Global.Spike4_Cost)
			tier_common_0()
			attack_damage = 24
		5:
			LevelManager.add_energy(Global.Spike5_Cost)
			tier_common_0()
			attack_damage = 48
		6:
			LevelManager.add_energy(Global.Spike6_Cost)
			tier_common_0()
			attack_damage = 160
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 1
	hp_max *= 2
