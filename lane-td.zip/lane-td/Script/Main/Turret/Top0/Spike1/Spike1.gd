extends TurretBase

@onready var timer_attack: Timer = $TimerAttack
func _ready():
	get_turret_tile()
	attack_damage = 4
	attack_delay = 0.6
	timer_attack.wait_time = attack_delay
	timer_attack.timeout.connect(attack)
	timer_attack.start()
	ready0()

var bullet0 = load("res://Script/Main/Turret/Top0/Spike1/spike1bullet.tscn")
var bullet

func attack():
	bullet = bullet0.instantiate()
	call_deferred("add_child", bullet)

func update_tier():
	tier += 1
	sprite_2d.region_rect.position.x += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Spike2_Cost)
			tier_common_0()
			attack_damage = 8
		3:
			LevelManager.add_energy(Global.Spike3_Cost)
			tier_common_0()
			attack_damage = 12
		4:
			LevelManager.add_energy(Global.Spike4_Cost)
			tier_common_0()
			attack_damage = 24
		5:
			LevelManager.add_energy(Global.Spike5_Cost)
			tier_common_0()
			attack_damage = 48
		6:
			LevelManager.add_energy(Global.Spike6_Cost)
			tier_common_0()
			attack_damage = 160
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 1
	hp_max *= 2
