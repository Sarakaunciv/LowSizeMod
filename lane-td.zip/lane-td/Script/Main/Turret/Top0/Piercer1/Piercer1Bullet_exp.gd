extends BulletBase

@onready var sprite_2d: Sprite2D = $Sprite2D
@onready var timer: Timer = $Timer
func _ready() -> void:
	get_turret_tile()
	bullet_damage = turret.attack_damage
	match Config.piercer_upgrade_level:
		1:
			scale *= 1
		2:
			scale *= 3
		3:
			scale *= 5
	sprite_2d.modulate = Color(1, 1, 1, 0.25)
	z_as_relative = false
	timer.wait_time = 0.3
	timer.timeout.connect(time_out)
	timer.start()

func time_out():
	queue_free()

func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	if enemy.hp_left <= 0:
		return
	else:
		enemy.damage_to_frag += bullet_damage * enemy.damage_to_frag_percent
		enemy.take_damage(bullet_damage * enemy.tier * enemy.fuse_count)
		LevelManager.piercer_damage += bullet_damage * enemy.tier * enemy.fuse_count
	queue_free()
