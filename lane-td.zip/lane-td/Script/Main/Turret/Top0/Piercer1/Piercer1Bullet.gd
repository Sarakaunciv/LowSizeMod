extends BulletBase

@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready() -> void:
	get_turret_tile()
	bullet_damage = turret.attack_damage
	sprite_2d.scale *= turret.bullet_size * 1.5
	var del_position_y = randf_range(-16, 16)
	sprite_2d.global_position += Vector2(0, del_position_y)
	sprite_2d.z_index = sprite_z_index

func _physics_process(delta: float):
	position.x += bullet_speed * delta

func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()

func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	if enemy.hp_left <= 0:
		return
	else:
		enemy.damage_to_frag += bullet_damage * enemy.damage_to_frag_percent
		enemy.take_damage(bullet_damage * enemy.tier * enemy.fuse_count)
		LevelManager.piercer_damage += bullet_damage * enemy.tier * enemy.fuse_count
