extends TurretBase

@onready var timer_attack: Timer = $TimerAttack
func _ready():
	get_turret_tile()
	hp_max = 30000
	hp_left = 30000
	hp_regen_hp = 3000
	bullet_size = 2.0
	timer_attack.wait_time = attack_delay
	timer_attack.timeout.connect(attack)
	timer_attack.start()
	ready0()

var bullet0 = load("res://Script/Main/Turret/Top0/Piercer1/piercer1bullet.tscn")
var bullet
func attack():
	for del in range(attack_count):
		bullet = bullet0.instantiate()
		call_deferred("add_child", bullet)
		bullet.position.x += attack_burst_distance * del

func update_tier():
	tier += 1
	sprite_2d.region_rect.position.x += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Piercer2_Cost)
			tier_common_0()
			attack_count = 2
		3:
			LevelManager.add_energy(Global.Piercer3_Cost)
			tier_common_0()
			attack_count = 3
		4:
			LevelManager.add_energy(Global.Piercer4_Cost)
			tier_common_0()
			attack_damage = 40
			bullet_size = 2.5
		5:
			LevelManager.add_energy(Global.Piercer5_Cost)
			tier_common_0()
			attack_damage = 80
			bullet_size = 3.0
		6:
			LevelManager.add_energy(Global.Piercer6_Cost)
			tier_common_0()
			attack_count = 4
			attack_damage = 200
			bullet_size = 4.0
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 1
	hp_max *= 2
