class_name BulletBase
extends Node2D

var bullet_speed: int = 450
var bullet_damage: int = 0

var enemy
var health_bar

var is_hit: bool = false
func _on_area_2d_area_entered(area: Area2D) -> void:
	if is_hit == true:
		return
	else:
		enemy = area.get_node("..")
		if enemy.hp_left <= 0:
			return
		else:
			is_hit = true
			enemy.flash()
			enemy.hp_left -= bullet_damage
			health_bar = enemy.get_node("Sprite2D/HealthBar")
			health_bar.update_health_bar()
			if enemy.hp_left <= 0:
				enemy.death()
			queue_free()

var sprite_z_index: int = 4
