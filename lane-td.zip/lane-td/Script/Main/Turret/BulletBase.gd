class_name BulletBase
extends Node2D

var bullet_speed: int = 450
var bullet_damage: int = 0

var enemy
var health_bar

var is_hit: bool = false

var sprite_z_index: int = 1

var turret_tile
var turret
func get_turret_tile():
	turret_tile = get_node("../..")
	turret = get_node("..")
