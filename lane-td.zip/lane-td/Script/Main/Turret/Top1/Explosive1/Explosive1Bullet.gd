extends BulletBase

@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready() -> void:
	get_turret_tile()
	bullet_damage = turret.attack_damage
	match turret.tier:
		1:
			scale *= 3
		2:
			sprite_2d.region_rect.position.y += 8
			scale *= 5
		3:
			sprite_2d.region_rect.position.y += 16
			scale *= 9
	sprite_2d.modulate = Color(1, 1, 1, 0.25)
	sprite_2d.z_index = sprite_z_index

func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	if enemy.hp_left <= 0:
		return
	else:
		enemy.damage_to_frag += bullet_damage * enemy.damage_to_frag_percent
		enemy.take_damage(bullet_damage * enemy.tier)
		LevelManager.explosive_damage += bullet_damage * enemy.tier
		turret_tile.kill_explosive()
