extends TurretBase

@onready var timer_attack: Timer = $TimerAttack
@onready var timer: Timer = $Timer
var timer_delay: float = 0.3
func _ready():
	get_turret_tile()
	attack_delay = 0.6
	attack_damage = 450
	top1_upgrade()
	timer_attack.timeout.connect(attack)
	timer_attack.wait_time = attack_delay
	timer_attack.start()
	timer.wait_time = timer_delay
	timer.timeout.connect(time_out)
	self.z_index += 1

var bullet0 = load("res://Script/Main/Turret/Top1/Explosive1/explosive1bullet.tscn")
var bullet
func attack():
	bullet = bullet0.instantiate()
	call_deferred("add_child", bullet)
	timer.start()
	sprite_2d.visible = false

func time_out():
	if tier == 3:
		LevelManager.add_energy(Global.Explosive3_Cost * -1)
	if tier >= 2:
		LevelManager.add_energy(Global.Explosive2_Cost * -1)
	if tier >= 1:
		LevelManager.add_energy(Global.Explosive1_Cost * -1)
	turret_tile.kill_explosive()

func update_tier():
	tier += 1
	sprite_2d.region_rect.position.y += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Explosive2_Cost)
			attack_damage = 1800
		3:
			LevelManager.add_energy(Global.Explosive3_Cost)
			attack_damage = 9000
