extends TurretBase

@onready var timer_regen_hp: Timer = $TimerRegenHp
func _ready():
	attack_damage = 450
	
	health_bar = get_node("HealthBar")
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	health_bar.update_health_bar()

@onready var sprite_2d: Sprite2D = $Sprite2D
func update_tier():
	tier += 1
	sprite_2d.region_rect.position.y += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Mine2_Cost)
			hp_max += 300
			hp_left += 300
			hp_regen_hp += 30
			
			attack_damage = 1800
		3:
			LevelManager.add_energy(Global.Mine3_Cost)
			hp_max += 600
			hp_left += 600
			hp_regen_hp += 600
			
			attack_damage = 9000
	hp_regen()

var parent
var is_hit
var enemy
var health_bar_enemy
func _on_area_2d_area_entered(area: Area2D) -> void:
	if is_hit == true:
		return
	else:
		enemy = area.get_node("..")
		if enemy.hp_left <= 0:
			return
		else:
			is_hit = true
			enemy.flash()
			enemy.hp_left -= attack_damage
			health_bar_enemy = enemy.get_node("Sprite2D/HealthBar")
			health_bar_enemy.update_health_bar()
			if enemy.hp_left <= 0:
				enemy.death()
			parent = get_node("..")
			parent.kill_node()
