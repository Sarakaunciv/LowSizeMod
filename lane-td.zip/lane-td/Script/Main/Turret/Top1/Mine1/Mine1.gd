extends TurretBase

func _ready():
	get_turret_tile()
	attack_damage = 450
	ready0()

@onready var sprite_2d: Sprite2D = $Sprite2D
func update_tier():
	tier += 1
	sprite_2d.region_rect.position.y += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Mine2_Cost)
			hp_max += 300
			hp_left += 300
			hp_regen_hp += 30
			
			attack_damage = 1800
		3:
			LevelManager.add_energy(Global.Mine3_Cost)
			hp_max += 600
			hp_left += 600
			hp_regen_hp += 600
			
			attack_damage = 9000
	hp_regen()

var is_hit
var enemy
var health_bar_enemy
func _on_area_2d_area_entered(area: Area2D) -> void:
	if is_hit == true:
		return
	else:
		enemy = area.get_node("..")
		if enemy.hp_left <= 0:
			return
		else:
			is_hit = true
			enemy.take_damage(attack_damage)
			LevelManager.mine_damage += attack_damage
			turret_tile = get_node("..")
			turret_tile.kill_node()
