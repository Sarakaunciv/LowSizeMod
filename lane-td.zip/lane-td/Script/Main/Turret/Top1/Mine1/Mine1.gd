extends TurretBase

func _ready():
	get_turret_tile()
	attack_damage = 450
	top1_upgrade()
	ready0()

func update_tier():
	tier += 1
	sprite_2d.region_rect.position.y += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Mine2_Cost)
			hp_max += 300
			hp_left += 300
			hp_regen_hp += 30
			
			attack_damage = 1800
		3:
			LevelManager.add_energy(Global.Mine3_Cost)
			hp_max += 600
			hp_left += 600
			hp_regen_hp += 600
			
			attack_damage = 2250
	hp_regen()

var is_hit
var enemy
var mine_resist_value: int = 100
var damage_to_enemy: int = 0
func _on_area_2d_area_entered(area: Area2D) -> void:
	if is_hit == true:
		return
	else:
		enemy = area.get_node("..")
		if enemy.hp_left <= 0:
			return
		else:
			is_hit = true
			mine_resist_value = enemy.mine_resist_level
			damage_to_enemy = enemy.hp_left - (attack_damage / mine_resist_value)
			if tier == 3 and damage_to_enemy > 0:
				LevelManager.add_energy(-10 * (damage_to_enemy / 225) * mine_resist_value)
				enemy.take_damage((attack_damage / mine_resist_value) + damage_to_enemy)
				LevelManager.mine_damage += (attack_damage / mine_resist_value) + damage_to_enemy
			else:
				enemy.take_damage(attack_damage / mine_resist_value)
				LevelManager.mine_damage += attack_damage / mine_resist_value
			turret_tile = get_node("..")
			turret_tile.kill_turret()
