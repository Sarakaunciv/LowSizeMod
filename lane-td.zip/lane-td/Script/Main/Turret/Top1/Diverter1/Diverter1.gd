extends TurretBase

@onready var timer_regen_hp: Timer = $TimerRegenHp
@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready():
	hp_max = 1000
	hp_left = 1000
	hp_regen_hp = 100
	if global_position.y == 280:
		attack_damage = 1
	elif global_position.y == 840:
		sprite_2d.region_rect.position.y += 8
		attack_damage = -1
	elif LevelManager.hold_diverter_type == 1:
		attack_damage = 1
	else:
		sprite_2d.region_rect.position.y += 8
		attack_damage = -1
	
	health_bar = get_node("HealthBar")
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	health_bar.update_health_bar()

func update_tier():
	tier += 1
	match tier:
		2:
			LevelManager.add_energy(Global.Diverter2_Cost)
			tier_common_0()
			sprite_2d.modulate = Global.Diverter2_Color
		3:
			LevelManager.add_energy(Global.Diverter3_Cost)
			tier_common_0()
			sprite_2d.modulate = Global.Diverter3_Color
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 39
	hp_max *= 40

var parent
var is_hit
var enemy
var health_bar_enemy
func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	enemy.flash()
	if hp_left < enemy.attack_damage:
		hp_left = 0
	else:
		enemy.global_position += Vector2(8 + Engine.time_scale, 80 * attack_damage)
		hp_left -= enemy.attack_damage
	health_bar.update_health_bar()
	if hp_left <= 0:
		parent = get_node("..")
		parent.kill_node()
