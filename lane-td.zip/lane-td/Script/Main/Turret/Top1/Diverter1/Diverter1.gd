extends TurretBase

func _ready():
	get_turret_tile()
	hp_max = 20000
	hp_left = 20000
	hp_regen_hp = 2000
	if global_position.y == 280:
		attack_damage = 1
	elif global_position.y == 840:
		sprite_2d.region_rect.position.y += 8
		attack_damage = -1
	elif LevelManager.hold_diverter_type == 1:
		attack_damage = 1
	else:
		sprite_2d.region_rect.position.y += 8
		attack_damage = -1
	top1_upgrade()
	ready0()

func update_tier():
	tier += 1
	match tier:
		2:
			LevelManager.add_energy(Global.Diverter2_Cost)
			tier_common_0()
			sprite_2d.modulate = Global.Diverter2_Color
		3:
			LevelManager.add_energy(Global.Diverter3_Cost)
			tier_common_0()
			sprite_2d.modulate = Global.Diverter3_Color
	hp_regen_hp = hp_max / 10
	hp_regen()
func tier_common_0():
	hp_left += hp_max * 19
	hp_max *= 20

var is_hit
var enemy
var health_bar_enemy
func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	if enemy.is_divert_immune == false:
		enemy.flash()
		take_damage(enemy.attack_damage)
		if hp_left < 0:
			turret_tile.kill_turret()
		else:
			enemy.global_position += Vector2(4 * (Engine.time_scale + 1), 80 * attack_damage)
		health_bar.update_health_bar()

var bullet
func _on_bullet_area_entered(area: Area2D) -> void:
	bullet = area.get_node("..")
	bullet.global_position += Vector2(-8 * (Engine.time_scale + 1), 80 * attack_damage)
