extends TurretBase

@onready var timer_attack: Timer = $TimerAttack
@onready var timer: Timer = $Timer
var timer_delay: float = 0.3
func _ready():
	get_turret_tile()
	attack_delay = 0.6
	attack_damage = 15
	timer_attack.timeout.connect(attack)
	timer_attack.wait_time = attack_delay
	timer_attack.start()
	timer.wait_time = timer_delay
	timer.timeout.connect(time_out)
	self.z_index += 1

var bullet0 = load("res://Script/Main/Turret/Top1/Stop1/stop1bullet.tscn")
var bullet
func attack():
	bullet = bullet0.instantiate()
	add_child(bullet)
	timer.start()
	sprite_2d.visible = false

func time_out():
	if tier == 3:
		LevelManager.add_energy(Global.Stop3_Cost * -1)
	if tier >= 2:
		LevelManager.add_energy(Global.Stop2_Cost * -1)
	if tier >= 1:
		LevelManager.add_energy(Global.Stop1_Cost * -1)
	turret_tile.kill_stop()

func update_tier():
	tier += 1
	sprite_2d.region_rect.position.y += 8
	match tier:
		2:
			LevelManager.add_energy(Global.Stop2_Cost)
			attack_damage = 60
		3:
			LevelManager.add_energy(Global.Stop3_Cost)
			attack_damage = 300
