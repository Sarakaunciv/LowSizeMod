extends BulletBase

var parent
var turret
@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready() -> void:
	parent = get_node("../..")
	turret = get_node("..")
	bullet_damage = turret.attack_damage
	match turret.tier:
		1:
			scale *= Vector2(5, 5)
		2:
			sprite_2d.region_rect.position.y += 8
			scale *= Vector2(9, 9)
		3:
			sprite_2d.region_rect.position.y += 16
			scale *= Vector2(15, 15)
	sprite_2d.modulate = Color(1, 1, 1, 0.25)
	sprite_2d.z_index = sprite_z_index

func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	enemy.flash()
	enemy.stop(bullet_damage)
	parent.kill_stop()
