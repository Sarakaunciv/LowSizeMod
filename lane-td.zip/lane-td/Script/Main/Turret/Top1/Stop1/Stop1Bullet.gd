extends BulletBase

@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready() -> void:
	get_turret_tile()
	bullet_damage = turret.attack_damage
	scale *= Config.stop_upgrade_level
	match turret.tier:
		2:
			sprite_2d.region_rect.position.y += 8
		3:
			sprite_2d.region_rect.position.y += 16
	sprite_2d.modulate = Color(1, 1, 1, 0.25)
	sprite_2d.z_index = sprite_z_index

func _on_area_2d_area_entered(area: Area2D) -> void:
	enemy = area.get_node("..")
	enemy.flash()
	enemy.stop(bullet_damage)
	turret_tile.kill_stop()
