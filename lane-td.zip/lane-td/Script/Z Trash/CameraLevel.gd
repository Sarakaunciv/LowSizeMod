extends Camera2D

@onready var label: Label = $Button/Label
var cam: int = 0
func _on_button_pressed() -> void:
	if cam == 0:
		label.text = str("<")
		self.global_position.x += 1600
		cam = 1
	else:
		label.text = str(">")
		self.global_position.x -= 1600
		cam = 0
