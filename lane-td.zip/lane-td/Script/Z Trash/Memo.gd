extends Camera2D

func make_new_turret():
	var new_turret
	var Global
	var new_turret_ui
	var new_cursor
	var new_turret_tile
	
	var new_enemy
	var new_enemy_spawn

# Debug Tile
@onready var timer: Timer = $Debug/Timer
@onready var label: Label = $Debug/Label
var timer_delay: float = 1
func _ready() -> void:
	timer.wait_time = timer_delay
	timer.timeout.connect(time_out)
	timer.start()
func time_out():
	if occupy == false:
		label.text = str("0 ", type, " ", turret_tier)
	else:
		label.text = str("1 ", type, " ", turret_tier)
